<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
// Route::get('/', function () {
//     return view('welcome');
// });
 
//测试
Route::any('workindex','home\ExerciseController@index');




//后台登录路由
Route::post('admin/login','admin\LoginController@dologin');
Route::get('admin/login','admin\LoginController@index');
Route::get('admin/logout','admin\LoginController@logout');
// 后台路由群组
Route::group(['prefix'=>'admin','middleware' => 'checkUser'],function(){
	Route::get('/logout','admin\LoginController@logout');
	Route::get('/','admin\IndexController@index');
	//后台用户资源路由
	Route::resource('/userlist','admin\UserController');
	// 前台用户资源管理路由
	Route::resource('/homelist','admin\HomeuserController');	
	
	//商品板块路由
	Route::resource('/good','admin\GoodsController');
	Route::get('/createSon/{id}','admin\GoodsController@createSon');
	Route::post('/createSon','admin\GoodsController@storeSon');
	Route::get('/sonClass/{id}','admin\GoodsController@sonClass');
	Route::get('/sonPut/{id}','admin\GoodsController@sonPutrecycler');
	
	//商品详情路由
	Route::get('/gdetail/{id}','admin\GdetailController@index');
	Route::post('/gdetail','admin\GdetailController@insert');

	
	//网站商品详情
	Route::get('/gdetail/{goods_id}','admin\GdetailController@index');
	Route::post('/gdetail/{goods_id}','admin\GdetailController@insert');
	Route::get('/showdetail/{goods_id}','admin\ShowdetailController@index');
	Route::post('/showdetail/{goods_detail_id}','admin\ShowdetailController@update');
	Route::get('/gdimage/{goods_id}','admin\GdimageController@index');
	Route::post('/gdimage/{goods_id}','admin\GdimageController@upload');
	
	
	
	//回收站
	Route::get('/re','admin\RecController@index');
	Route::get('/re/go/{id}','admin\RecController@gohome');
	Route::get('/re/del/{id}','admin\RecController@del');
	
	//订单列表路由
	Route::get('/odlist/{id}','admin\OrderController@index');
	Route::get('/dd','admin\DdController@index');
	Route::get('/df','admin\DdController@daifukuan');
	Route::get('/daifahuo','admin\DdController@dfh');
	Route::get('/ds','admin\DdController@dsh');
	Route::get('/fahuo/{id}','admin\OrderController@fahuo');

	Route::get('/dh','admin\DdController@dh');


	//评论列表
	Route::get('/commentlist','admin\CommentController@index');
	Route::get('/comment/{id}','admin\CommentController@delete');

	//网站配置
	Route::get('/config','admin\ConfigController@index');
	Route::post('/config','admin\ConfigController@update');
	
	//友情链接
	Route::resource('/link','admin\LinkController');


	//代金券
	Route::get('/gotbonus','admin\StoreController@store');
	//删除代金券
	Route::get('/del/{id}','admin\StoreController@delete');
	//已使用代金劵
	Route::get('/yiyong','admin\StoreController@yiyong');
	//未使用代金券
	Route::get('/weiyong','admin\StoreController@weiyong');
	//给用户添加代金券
	Route::get('/storeadd/{id}','admin\StoreaddController@index');
	Route::post('/storeinsert','admin\StoreaddController@store');


	
});


Route::get('/','home\IndexController@index');
//前台登录路由
Route::post('home/dologin','home\LoginController@dologin');
Route::get('home/login','home\LoginController@index');
Route::get('home/zhuce','home\ZhuceController@index');
Route::post('home/zhuce','home\ZhuceController@tolog');
Route::group(['prefix'=>'home'],function(){
	//验证码
	Route::get('/capch/{tmp}','home\ZhuceController@capch');
	
	//前台商品详情路由
	Route::get('/gde/{id}','home\GdtController@index');
	
	//购买页路由
	Route::get('/buy/{goods_id}','home\BuyController@index');
	
	//购物车路由
	Route::post('/buycar','home\BuycarController@index');
	//确认订单页路由
	Route::get('/check/{id}','home\CheckController@index');
	Route::post('/check','home\CheckController@select');
	
	//地址路由
	Route::post('/address','home\AddressController@index');
	Route::post('/updateaddress/{address_id}','home\AddressController@update');
	Route::post('/defaultadd','home\AddressController@defaultadd');
	Route::post('/deleteadd','home\AddressController@deleteadd');
	Route::get('/myaddress','home\AddressController@myaddress');


	//结算页路由
	Route::get('/pay/{id}','home\PayController@index');
	Route::post('/orderstatus','home\PayController@status');


	//收藏路由
	Route::post('/collect','home\CollectController@index');
	Route::get('/store','home\CollectController@store');


	//代金券
	Route::get('/stor','home\StoreController@index');
	Route::get('/state/{id}','home\StoreController@state');


});

//个人信息
Route::resource('home/myself','home\FormeController');
//个人信息头像上传
Route::get('home/touphoto','home\TouphonoController@form');
Route::post('home/touphoto','home\TouphonoController@update');
Route::get('home/out','home\TouphonoController@out');
//购物车
Route::get('/cart','home\CartController@index');
//购物车添加商品数路由
Route::post('/cartadd','home\CartController@add');
//购物车减少商品数路由
Route::post('/cartjian','home\CartController@jian');
//购物车删除商品路由
Route::post('/cartdel','home\CartController@del');
//购物车结算商品路由
Route::post('/goorder','home\CartController@goorder');
//购物车input商品数路由
Route::post('/cartinput','home\CartController@input');

//前台订单
Route::get('home/order/{id}','home\OrderController@index');
Route::get('home/del/{id}','home\OrderController@del');
Route::get('home/delgood/{id}','home\OrderController@delgood');
Route::get('home/pingjia/{id}','home\OrderController@pingjia');
Route::get('home/dingdan','home\DingdanController@index');
Route::get('home/dfk','home\DingdanController@daifukuan');
Route::get('home/dfh','home\DingdanController@dfh');
Route::get('home/dsh','home\DingdanController@dsh');
Route::get('home/look/{id}','home\OrderController@look');
Route::get('home/shanchu/{id}','home\OrderController@shanchu');
Route::get('home/sure/{id}','home\OrderController@sure');

//评论路由
Route::get('home/pj/{statu}','home\OrderController@pingjialist');
Route::post('home/fabiao','home\OrderController@fabiao');
