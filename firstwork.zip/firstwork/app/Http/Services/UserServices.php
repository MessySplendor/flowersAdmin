<?php 
namespace App\Http\Services;/**
* 
*/
use App\Models\Work;

class UserServices
{
	protected $work = null;
	public function __construct(Work $work){
		$this->Work = $work;
	}
	public function index()
	{
		$a = $this->Work->select();
		return $a;
	}
}

 ?>