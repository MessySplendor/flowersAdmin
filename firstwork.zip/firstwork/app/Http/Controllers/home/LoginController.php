<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Models\Work;

class LoginController extends Controller
{
    /**
     * 登录页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
    	return view('home.login.login');
    }

    /**处理登录页面
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function dologin(Request $request)
    {
        // $work = new Work();
        // $res = $work->select();
        // print_r($res);die;
    	$log = $request->only('name','pass');
        if (empty($log['name'])) {
            return back()->with('mg','账号不能为空');
        }
        if (empty($log['pass'])) {
            return back()->with('m','密码不能为空');
        }
    	// $log['pass'] = md5($log['pass']);
        $user_is_exit = DB::table('home_user')->where('name', $log['name'])->where('pass', $log['pass'])->where('status','1')->first();
        if($user_is_exit){
            $uid =$user_is_exit->id;
            $user_detail = DB::table('user_detail')->where('det_uid',$uid)->first();
            //将用户昵称信息写入session
             session(['homeuser'=>$user_detail]);
             return redirect('/');
        }else{
        	return back()->with('msg','登录失败：账号或者密码错误');
        }
        
    }
}
