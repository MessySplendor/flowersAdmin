<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class IndexController extends Controller
{
    public function index()
    {
        //导航栏处列表
        $data=DB::table('goods')
            ->where('goods_pid','=','0')
            ->where('statu','=','1')
            ->get();
       //左侧列表栏处列表
//        $list=DB::table('goods as c1')
//            ->join('goods as c2','c1.goods_id','=','c2.goods_pid')
//            ->select('c1.*')
//            ->where('c1.statu','=','1')
//			->limit(0,6)
//            ->get();
//        dd($list);
        //下部部分商品展示
        $list=DB::table('goods as c1')
            ->join('goods as c2','c1.goods_pid','=','c2.goods_id')
            ->select('c1.*')
            ->where('c1.statu','=','1')
            ->get();
//        dd($list);

//        dd($data);
//        dd($list);
//        dd($list2);
        return view('home.index',['data'=>$data,'list'=>$list]);
            
    }

}
