<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;



class CartController extends Controller
 {
//显示用户购物车里的商品
   public function index()
   {
       // dd($id);
        $user = session('homeuser');
        //dd($user);
        if(empty($user)){
            return view('home.cart.cartkong');
        }
        $uid = session('homeuser')->det_uid;
        
        $cart = DB::table('goods_car')
              ->join('goods','goods.goods_id','=','goods_car.car_gid')
              ->where('car_uid',$uid)->get();
        //dd($cart);
        $data = DB::table('goods_car')->where('car_uid',$uid)->select('goods_car.car_pic')->get();
        //dd($data);
        $list="";
        foreach($data as $v){
          $li=explode('/',$v->car_pic);
          $pic=$li[count($li)-1];
          $list=$pic;
          // dd($pic);
        }
        //dd($list);
        return view('home.cart.cartlist',['cart'=>$cart,'list'=>$list]);
   }

//减少商品的数量
   public function add(Request $request )
   {
        $id = $request->input('id');
        $num = DB::table('goods_car')->where('car_id',$id)->first();
        $add = $num->car_number;
        $add++;
        $ob= DB::table('goods_car')->where('car_id',$id)->update(['car_number'=>$add]);

        return $ob;
   }
//增加商品的数量
   public function jian(Request $request )
   {
        $id = $request->input('id');
        $num = DB::table('goods_car')->where('car_id',$id)->first();
        $jian = $num->car_number;
        if($jian>1){
            $jian--;
            $ob= DB::table('goods_car')->where('car_id',$id)->update(['car_number'=>$jian]);
            return $ob;
        }
   }

//input更改商品数
    public function input(Request $request )
   {
        $id = $request->input('id');
        $num = $request->input('num');
         
        $ob= DB::table('goods_car')->where('car_id',$id)->update(['car_number'=>$num]);
        if ($ob > 0) {
           return $ob;
        }
        
       
   }
//删除商品
   public function del(Request $request)
   {
        $id = $request->input('id');
        $del = DB::table('goods_car')->where('car_id',$id)->delete();
        return $del;
   }

//把用户选中的商品去结算
   public function goorder(Request $request)
   {
      //购物车的选中的id    
      $id = $request->input('id'); 
      //生成时间戳
      $time = time();
      //生成订单的随机数
      $ordernumber = rand(10000000,99999999);
      //用户的ID
      $uid = session('homeuser')->det_uid;
      foreach ($id as $k => $v) {
        $num = DB::table('goods_car')->where('car_id',$v)->first();
        //商品的数量
        $number = $num->car_number;
        //商品的单价
        $price = $num->car_price;
        //商品的总价
        $gid = $num->car_gid;
        $zj = $number*$price;
        //向订单列表中插入商品详细信息
        $order = DB::table('orderlist')->insertGetId(
          ['gid'=>$gid,'goods_pirce'=>$price,'goods_sum'=>$zj,'goods_num'=>$number,'ordernumber'=>$ordernumber,'carid'=>$v,'uid'=>$uid
        ]);
      }
      //插入订单号中的订单号
      $ddh = DB::table('ddh')->insertGetId(['dtime'=>$time,'ordernumber'=>$ordernumber,'uid'=>$uid]);
      if ($ddh>0) {
        return $ddh;
      }
    
    
   }

   
}




