<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class CheckController extends Controller
{
    public function index($id)
    {
        //dd($id);
        $uid = session('homeuser')->det_uid;
        $address=DB::table('goods_address')->where([['uid',$uid],['status','2']])->first();
        //dd($address);
    	$list=DB::table('goods_address')->where('uid',$uid)->get();
    	//dd($list);
        
         //获得订单号
        $ordernumber=DB::table('ddh')->where('id',$id)->value('ordernumber');
        
        $order=DB::table('orderlist')
                ->join('goods','goods.goods_id','=','gid')
                ->join('goods_car','goods_car.car_id','=','orderlist.carid')
                ->select('goods.image','goods.goods_name','goods_car.*','orderlist.*')
                ->where('ordernumber',$ordernumber)
                ->get();
        // dd($order);
        //计算商品总数
        $goods_count="";
        foreach($order as $v){
            //$goods_count+=$v->goods_num;
            $goods_count=$v->goods_num;
        }
        //dd($goods_count);
        //计算商品总价
        $price_count="";
         foreach($order as $v){
            $price_count=$v->goods_sum;
        }
        $ob = DB::table("store_gotbonus")
               ->join('home_user','home_user.id','=','uid')
               ->where('uid',$uid)
               ->get();
        
        // $arr = DB::select("select * from store_gotbonus where uid = '$uid'");
        // $aa = json_encode($arr);
        // $bb = json_decode($aa,true);
        // $starttime = $bb[0]['startti'];
        // $stime = date("Y-m-d H:i:s",$starttime);
        // $starttime=date("Y-m-d H:i:s",$arr->startti);
        // print_r($stime);die;


        // dd($price_count);
    	return view('home.check',['id'=>$id,'list'=>$list,'address'=>$address,'order'=>$order,'goods_count'=>$goods_count,'price_count'=>$price_count,'ob'=>$ob]);
    }

    public function select(Request $request)
    {
    	$upid=$request->only('upid');
    	$data=DB::table('address')->where('upid','=',$upid)->get();
    	//dd($data);
    	echo json_encode($data);
    }

}
