<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class OrderController extends Controller
{
    
    public function index($id)
    {
        //dd($id);
         $data=DB::table('orderlist')
                ->join('goods','gid','=','goods_id')
                ->join('ddh','orderlist.ordernumber','=','ddh.ordernumber')
                ->where('orderlist.commentstatu','=','0')
                ->where('orderlist.ordernumber',$id)
                ->get();
            //dd($data);
        return view('home.order.myorder',['data'=>$data]);     
    }


   public function del($id)
    {
       ///dd($id);
       $m=DB::table('ddh')->where('ordernumber',$id)->delete();
       if($m>0){
            DB::table('orderlist')->where('ordernumber',$id)->delete();
            return redirect('home/dingdan');
       }else{
            return redirect('home/dingdan');
       }
        
    }

    public function delgood($id)
    {
       $m=DB::table('orderlist')->where('orderlist_id',$id)->delete();
       if($m>0){
            
            return back();
       }else{
            return back();
       }
        
    }
   
    //评价晒单 同样根据不同的状态进行显示 commentstatu=0待评价 1已评价
    public function pingjialist($statu)
    {
        switch ($statu) {
            case '0':
                $uid=session('homeuser')->det_uid;
                $data=DB::table('goods_comment')
                    ->join('goods','goods.goods_id','comment_gid')
                    ->where('goods_comment.comment_uid',$uid)
                    ->where('goods_comment.comstatue',0)
                    ->get();
                 return view('home.order.pingjialist',['data'=>$data]);
            break;
            
            case '1':
                $uid=session('homeuser')->det_uid;
                $data=DB::table('goods_comment')
                    ->join('goods','goods.goods_id','comment_gid')
                    ->where('goods_comment.comment_uid',$uid)
                    ->where('goods_comment.comstatue',1)
                    ->get();
                 return view('home.order.pingjialist',['data'=>$data]);
            break;
        }
       
        //dd($data);
       
    }
    //评价页面
    public function pingjia($id)
    {
        
         $data=DB::table('orderlist')
            ->join('ddh','ddh.ordernumber','=','orderlist.ordernumber')
            ->join('goods','gid','=','goods_id')
            ->where('orderlist_id','=',$id)
            ->first();
        //dd($data);
        return view('home.order.pingjia',['data'=>$data]);
    }
    //进行评价
    public function fabiao(Request $request)
    {
        //dd($request);
        $data=$request->except('_token','id');
        $comment_time=date(time()) ;
        $data['comment_time']=$comment_time;
        $m=DB::table('goods_comment')->insertGetId($data);
        if($m>=0){
            $id=DB::table('orderlist')->where('orderlist_id',$request->id)->update(['commentstatu'=>'1']);
            DB::table('goods_comment')->where('comment_id',$m)->update(['comstatue'=>1]);
            if($id>=0){
                return redirect('home/pj/1');
            }else{
                return back();
            }
              return redirect('home/pj/0');
        }else{
            return redirect('home/pj/1');
        }
    }


    public function look($id)
    {
      $uid=session('homeuser')->det_uid;
      $data=DB::table('goods_comment')
          ->join('goods','goods.goods_id','=','goods_comment.comment_gid')
          ->where('comment_uid',$uid)
          ->where('comment_id',$id)
          ->get();
     //dd($data);
      return view('home.order.look',['data'=>$data]);
    }


    public function shanchu($id)
    {
      $m=DB::table('goods_comment')->where('comment_id',$id)->delete();
      if($m>0){
        return back();
      }else{
        return back();
      }
    }
    //确认收货
    public function sure($id)
    {
        $m=DB::table('ddh')->where('ordernumber',$id)->update(['statues'=>4]);
        if($m>0){
          return back();
        }else{
          return back();
        }
    }
}
