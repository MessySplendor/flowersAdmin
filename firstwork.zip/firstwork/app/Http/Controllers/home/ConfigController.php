<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class ConfigController extends Controller
{
    public function index()
    {
    	$list=DB::table('system_config')->get()->first();
    	//dd($list);
    	return view('home.index',['list'=>$list]);
    }
}
