<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
// use session; 
class FormeController extends Controller
{
    /**
     * 个人中心展示页面
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
    	return view('home.login.myself');
    }


    /**
     * 个人中心处修改个人信息
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit($id)
    {
        $user_info = DB::table('user_detail')->where('det_id',$id)->first();
        return view('home.login.forme',['user_info'=>$user_info]);
    } 

     public function update($id,Request $request)
    {


        $abc = $request->only('det_nicheng','det_email','det_sex','det_card','det_phone');
       
        $row = DB::table('user_detail')->where('det_id',$id)->update($abc);
        $css = DB::table('user_detail')->where('det_id',$id)->first();
       //dd($css);
        if ($row>0) {
             // session()->forget('homeuser');
            session(['homeuser'=>$css]);
            return redirect('home');
        }else{
                return back()->with('msg','修改失败：请重新填写');
        }
    }   
   
}
