<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

//验证码的类
use Gregwar\Captcha\CaptchaBuilder;

class ZhuceController extends Controller
{
    //
    public function index()
    {
    	return view('home.login.zhuce');
    }


     public function tolog(Request $request)
    {
        
        $data = $request->except('_token');
        //dd($data);


        if (empty($data['pass']) || empty($data['password']) || empty($data['name'] || empty($data['icode']))) {
            return back()->with('msg','不能为空！');

            }
        if ($data['pass'] != $data['password']) {
        	return back()->with('msg','两次密码输入的不一致!');
        }
      	$mycode = session()->get('milkcaptcha');
        
        if($mycode != $data['icode']){
            return back()->with('msg','验证码错误！');
        }
        //dd($data);

        $zhuce = $request->only('name','pass');
        // dd($zhuce);
        $zhuce['pass'] = md5($zhuce['pass']);
        //dd($zhuce);
        //获取上一条sql语句的id
        $m = DB::table('home_user')->insertGetId($zhuce);
        // dd($m);
        if ($m>0) {
            // dd($zhuce['name']);
            $user =  DB::table('user_detail')->insert(
                ['det_uid' => $m,'det_nicheng' => $zhuce['name']]
                );
            // dd($user);
          
                return redirect('home/login');
              
        }
       
        
    }

     public function capch($tmp)
    {
        //生成验证码图片的Builder对象，配置相应属性
        $builder = new CaptchaBuilder;
        //可以设置图片宽高及字体
        $builder->build($width = 150, $height = 60, $font = 'simhei.ttf');
        //获取验证码的内容
        $phrase = $builder->getPhrase();
        //把内容存入session
        session()->flash('milkcaptcha', $phrase);
        
        return response($builder->output())->header('content-type','image/jpeg');
    }

}




