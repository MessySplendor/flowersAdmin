<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Services\UserServices;
//练习 controller
class ExerciseController extends Controller
{
	public $userservices = null;
    public function __construct(UserServices $userservices){
    	$this->UserServices=$userservices;
    }

    public function index(){
    	$a=$this->UserServices->index();
    	print_r($a);

    }
}
