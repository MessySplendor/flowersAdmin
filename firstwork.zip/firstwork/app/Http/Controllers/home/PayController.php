<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class PayController extends Controller
{
    public function index($id)
    {
    	// dd($id);
    	$address=DB::table('goods_address')->where('status','2')->first();
    	// dd($address);
    	$ordernumber=DB::table('ddh')->where('id',$id)->value('ordernumber');
    	$order=DB::table('orderlist')
                ->join('goods','goods.goods_id','=','gid')
                ->join('goods_car','goods_car.car_id','=','orderlist.carid')
                ->select('goods.image','goods.goods_name','goods_car.*','orderlist.*')
                ->where('ordernumber',$ordernumber)
                ->get();
        // dd($order);
        //计算商品总价
        $price_count="";
         foreach($order as $v){
            $price_count=$v->goods_sum;
        }
    	return view('home.pay',['id'=>$id,'ordernumber'=>$ordernumber,'order'=>$order,'price_count'=>$price_count,'address'=>$address]);
    }

    public function status(Request $request)
    {
    	$id=$request->input('id');
        DB::table('ddh')->where('id',$id)->update(['statues'=>2]);
    	return json_encode($id);
    	
    }
}
