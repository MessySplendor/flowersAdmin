<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

//验证码的类
use Gregwar\Captcha\CaptchaBuilder;

class StoreController extends Controller
{
   
    public function index()
    {
        $uid = session('homeuser')->det_uid;
        //dd($uid);
        $store = DB::table('store_gotbonus')->where('state',0)->where('uid',$uid)->get();
    	return view('home.store.store',['store'=>$store]);
    }

    public function state($id)
    {
        dd($id);
    }

}




