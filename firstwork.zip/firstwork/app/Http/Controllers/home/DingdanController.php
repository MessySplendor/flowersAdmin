<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;
class DingdanController extends Controller
{
   public function index()
   {
         $uid = session('homeuser')->det_uid;
      //dd($uid);
   		$data=DB::table('ddh')->where('uid',$uid)->get();
         // print_r($data);die;
         // dd($data);          
        return view('home.order.dingdan',['data'=>$data]);
   }

   public function daifukuan()
   {     $uid = session('homeuser')->det_uid;
   		$data=DB::table('ddh')->where('uid',$uid)->where('statues','1')->get();
   		return view('home.order.dfk',['data'=>$data]);
   }

   public function dfh()
   {     $uid = session('homeuser')->det_uid;
   		$data=DB::table('ddh')->where('uid',$uid)->where('statues','2')->get();
   		return view('home.order.dfh',['data'=>$data]);
   }

   public function dsh()
   {     $uid = session('homeuser')->det_uid;
   		$data=DB::table('ddh')->where('uid',$uid)->where('statues','3')->get();
   		return view('home.order.dsh',['data'=>$data]);
   }
}
