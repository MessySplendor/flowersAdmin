<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class BuycarController extends Controller
{
    public function index(Request $request)
    {
        //dd($request);
    	$data=$request->except('_token','goods_id');
    	
    	$goods_id=$request->input('goods_id');
    	
    	$data['car_gid']=$goods_id;
    	$id = session('homeuser')->det_uid;
    	$data['car_uid']=$id;
    	DB::table('goods_car')->insert($data);


    	
    }
}
