<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class CollectController extends Controller
{
    public function index(Request $request)
    {
        //dd($request);
    	$data=$request->except('_token','goods_id');
    	
    	$goods_id=$request->input('goods_id');
    	
    	$data['gid']=$goods_id;
    	$id = session('homeuser')->det_uid;
    	$data['uid']=$id;
    	DB::table('collect')->insert($data);
    	return json_encode($data);
    	
    }

    public function store()
    {
    	$uid = session('homeuser')->det_uid;
    	$gid=DB::table('collect')->where('uid',$uid)->value('gid');
    	$data=DB::table('collect')
    		->join('goods','goods_id','=','collect.gid')
    		->where('uid',$uid)
    		->select('goods.goods_name','goods.image','goods.goods_id','collect.*')
    		->get();
    	// dd($data);
    	return view('home.collect',['data'=>$data]);
    }
}
