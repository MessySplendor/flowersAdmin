<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class BuyController extends Controller
{
    public function index($goods_id)
    {
		//dd($goods_id);
    	$list=DB::table('goods_detail')
    		->join('goods','goods.goods_id','=','goods_detail.gid')
    		->join('goods_image','goods_image.gid','=','goods.goods_id')
    		->select('goods.*','goods_detail.*','goods_image.*')
    		->get();
            // print_r($list);die;
    	$sessions =session()->all();
    	//dd($sessions);
    	//dd($list);
    	$introduction=explode('#',$list[0]->introduction);
    	$configone=explode('#',$list[0]->configone);//不能写成$list['configone'],每一条信息都是对象，不是数组
    	$configtwo=explode('#',$list[0]->configtwo);
    	$configthree=explode('#',$list[0]->configthree);
    	$electricize=explode('#',$list[0]->electricize);
    	$size_weight=explode('#',$list[0]->size_weight);
    	$camera=explode('#',$list[0]->camera);
    	$screen=explode('#',$list[0]->screen);
        $operator=explode('#',$list[0]->operator);
    	$type_price=explode('#',$list[0]->type_price);
    	// dd($type_price);
    	return view('home.buy',['introduction'=>$introduction,'configone'=>$configone,'configtwo'=>$configtwo,
    		'configthree'=>$configthree,'size_weight'=>$size_weight,'electricize'=>$electricize,'goods_id'=>$goods_id,
    		'camera'=>$camera,'screen'=>$screen,'operator'=>$operator,'type_price'=>$type_price,'list'=>$list]);
    }
}
