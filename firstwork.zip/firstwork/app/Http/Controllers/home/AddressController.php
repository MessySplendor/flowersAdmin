<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class AddressController extends Controller
{
//---------------- 存入地址---------------------//
    public function index(Request $request)
    {
        echo "11";die;
    	$uid = session('homeuser')->det_uid;
    	//dd($uid);
    	
    	//dd($request);
    	$address=$request->input('address');//用->only打印出来是一个二维数组，用input是一维数组
    	//dd($address);
    	$add="";
    	$data="";
    	$data['uid'] = $uid;
    	foreach ($address as $k=>$v){
    		$add.=DB::table('address')->where('id',$v)->value('name');
    	}
        //dd($add);
    	$data['address'] = $add;
    	//dd($data);
    	$list=$request->except('_token','address');
    	// dd($list);
    	foreach($list as $k=>$v){
    		$data[$k]=$v;
    	}
    	// dd($data);
    	$row=DB::table('goods_address')->insertGetId($data);
    	if($row>0){
            return back();
        }
    }
//---------------- 修改地址---------------------//
    public function update($address_id,Request $request)
    {
    	// dd($request);
    	// dd($address_id);
    	$list=$request->except("_token");
    	// dd($list);
    	$row=DB::table('goods_address')->where('address_id',$address_id)->update($list);
    	// dd($row);
    	if($row){
    		return back();
    	}
    }
//-----------------修改默认地址--------------------//
    public function defaultadd(Request $request)
    {
    	//json_encode($request);
    	$address_id=$request->input('address_id');
    	DB::table('goods_address')->update(['status'=>'1']);
    	DB::table('goods_address')->where('address_id',$address_id)->update(['status'=>'2']);
    }
//-----------------删除地址--------------------//  
    public function deleteadd(Request $request)
    {
        $address_id=$request->input('address_id');
        DB::table('goods_address')->where('address_id',$address_id)->delete();
        return json_encode($request);
    } 
//------------------个人中心地址管理--------------------------//
    public function myaddress()
    {
        $uid = session('homeuser')->det_uid;
        $list=DB::table('goods_address')->where('uid',$uid)->get();

        // dd($list);
        return view('home.myaddress',['list'=>$list]);
    }

}
