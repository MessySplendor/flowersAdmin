<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;



class TouphonoController extends Controller
{
    /**
     * 修改头像方法
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function form()
    {
        return view('home.login.touphono');
    }

    /**
     * 修改用户头像
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request)
    {
        //设置允许上传的图片类型
        $allow_ext = array('jpeg','jpg','png','gif');
        if($request->hasFile('mypic')){
           $file = $request->file('mypic');
           $ext  = $file->getClientOriginalExtension();
           if(!in_array($ext,$allow_ext)){
               return back()->with('msg','上传文件类型错误,请重新上传');
           }
           //重命名文件
           $filename = time().rand(1000,9999).'.'.$ext;
           $move     = $file->move('./uploads/hphoto',$filename);
            if($move){
                $data['det_photo'] = $filename;
            }else{
                $data['det_photo'] = 'tphoto.jpg';
            }
        }else{
            //判断上传过程中的错误处理
            $error = $request->file('mypic')->getError();
            switch ($error){
                case 1:
                    $msg = '上传文件大小超出了配置文件中的最大值,请重新上传';
                    break;
                case 2:
                    $msg = '上传文件超过了html中form表单设置的最大值';
                    break;
                case 3:
                    $msg = '部分文件上传';
                    break;
                case 4:
                    $msg = '没有文件上传';
                    break;
                case 6:
                    $msg = '找不到临时文件夹';
                    break;
                case 7:
                    $msg = '文件写入失败';
                    break;
            }
            session(['msg'=>$msg]);
            return back()->with('msg',$msg);
        }
        $user_id =  session('homeuser')->det_id;
        $res = DB::table('user_detail')->where('det_id',$user_id)->update($data);
        if ($res) {
            session(['hphoto'=>$filename]);
           return redirect('home/myself');
        }else{
            return back()->with('msg','头像修改失败,请重新操作');
        }
       
    }
    /**
     * 用户退出登录
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public  function out()
    {
        session()->forget('homeuser');
        return redirect('/');
    }

}




