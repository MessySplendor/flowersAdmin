<?php

namespace App\Http\Controllers\home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class GdtController extends Controller
{
    public function index($id)
	{
		// dd($id);
		$list=DB::table('goods_detail')
			-> join('goods','goods_detail.gid','=','goods.goods_id')
			-> join('goods_image','goods_image.gid','=','goods_detail.gid')
			->select('goods_detail.*','goods.*','goods_image.image','goods_image.flag')
			->get(); 
		
		// $list=DB::table('goods_detail')
		// 	->join('goods','goods.goods_id','=','goods_detail.gid')
		// 	->join('goods_image','goods_image.gid','=','goods_detail.gid')
		// 	->where('goods_detail.gid',$id)
		// 	->get();
		
		// dd($list); 
		$introduction=explode('#',$list[0]->introduction);
		
    	$configone=explode('#',$list[0]->configone);//不能写成$list['configone'],每一条信息都是对象，不是数组
    	 
		$configtwo=explode('#',$list[0]->configtwo);
		//dd($configtwo);
    	$configthree=explode('#',$list[0]->configthree);
    	$electricize=explode('#',$list[0]->electricize);
    	$size_weight=explode('#',$list[0]->size_weight);
    	$camera=explode('#',$list[0]->camera);
    	$screen=explode('#',$list[0]->screen);
        $operator=explode('#',$list[0]->operator);
		
		return view('home.gdetail',['introduction'=>$introduction,'configone'=>$configone,'configtwo'=>$configtwo,
    		'configthree'=>$configthree,'size_weight'=>$size_weight,'electricize'=>$electricize,
    		'camera'=>$camera,'screen'=>$screen,'operator'=>$operator,'list'=>$list]);
		
	}
}
