<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB; 


class UserController extends Controller
{
   // 后台登录页面
    public function index()
    {

      $list = DB::table('admin_user')->get();
    	return view('admin.ad_user.userlist',['list'=>$list]);
		  
    } 

    public function destroy($id)
    {
        $row = DB::table('admin_user')->where('admin_id',$id)->delete();
        //dd($row);
        if(!empty($row)){
           
            return redirect('admin/userlist');
        }else{
            return redirect('admin/userlist');
        }
    }
    
    public function edit($id)
    {

        $ob = DB::table('admin_user')->where('admin_id',$id)->first();
        return view('admin.ad_user.useredit',['ob'=>$ob]);
        // dd($ob);
    }	
    	
     public function update($id,Request $request)
    {


        $data = $request->only('admin_name','admin_pass');
        $data['admin_pass'] = md5($data['admin_pass']);

        $row = DB::table('admin_user')->where('admin_id',$id)->update($data);
        if ($row>0) {
           return redirect('admin/userlist');
        }else{
            return back()->with('msg','登录失败：账号或者密码错误');
        }
    } 

    public function create()
    {
        return view('admin.ad_user.useradd');
    }

    public function store(Request $request)
    {
        
        $data = $request->except('_token');
        $data['admin_pass'] = md5($data['admin_pass']);
        $m = DB::table('admin_user')->insertGetId($data);
        if ($m>0) {
           return redirect('admin/userlist');
        }
        
    }
}
