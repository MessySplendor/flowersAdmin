<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class StoreaddController extends Controller
{
	//显示添加用户代金券页
	public function index($id)
	{
		//用户ID
		$ob = DB::table('home_user')->where('id',$id)->first();
		//dd($uid);
		//呈现的视图
		return view('admin.store.storeadd',['ob' =>$ob]);
	}

	public function store(Request $request)
	{

		$data = $request->except('_token');
		$d = $data['val'];
		$uid=$data['uid'];
		//dd($d);
		$stopti = time();
		$startti = time() + (30 * 24 * 60 * 60);
		//dd($startti);
		$pdo = DB::table('store_gotbonus')->insert(['uid'=>$uid,'stopti'=>$stopti,'startti'=>$startti,'val'=>$d]);
		if ($pdo>0) {
			return redirect('admin/gotbonus');
		};
	}
}