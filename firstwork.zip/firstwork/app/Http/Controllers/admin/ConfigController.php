<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class ConfigController extends Controller
{
    public function index()
    {
    	$list=DB::table('system_config')->get()->first();
    	//dd($list);
    	return view('admin.config',['list'=>$list]);
    }
     public function update(Request $request)
    {
        // dd($request);
        $data = $request -> except('_token');
        //dd($data);  
        // 处理上传头像
            if($request->hasFile('config_photo'))
            {
                if ($request->file('config_photo')->isValid()){
                    //
                    $suffix = $request -> file('config_photo') -> getClientOriginalExtension();
                    $fileName = time().mt_rand(100000,999999) . '.' . $suffix;
                    //$tem = '1' . $suffix;

                    // 移动
                    if(!file_exists('./uploads/logo'))
                    {
                        mkdir('./uploads/logo', true, '777');
                    }
                    $move = $request -> file('config_photo') -> move('./uploads/logo/', $fileName);
                   if($move)
                    {
                        $data['config_photo'] = $fileName;
                    }else
                    {
                        $data['config_photo'] = 'mi.jpg';
                    }
                }else
                {
                    $data['config_photo'] = 'mi.jpg';
                }
            }else
            {
                $data['config_photo'] = 'mi.jpg';
            }
            // dd($data);
        // 执行修改
        $res = DB::table('system_config')-> update($data);
        if($res)
        {
            return redirect('/admin/config') -> with('msg', '修改成功');
        }else
        {
            return back() -> with('msg', '修改失败');
        }
    }
  
}
