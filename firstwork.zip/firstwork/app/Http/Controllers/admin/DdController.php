<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;
class DdController extends Controller
{
    public function index()
   {
   		$data=DB::table('ddh')
          ->join('home_user','ddh.uid','=','home_user.id')
          ->paginate(10);
      //dd($data);   
      return view('admin.order.dingdan',['data'=>$data]);
   }

   public function daifukuan()
   {
   		$data=DB::table('ddh')
        ->join('home_user','ddh.uid','=','home_user.id')
        ->where('statues','1')
        ->get();
   		return view('admin.order.dfk',['data'=>$data]);
   }

   public function dfh()
   {
   		$data=DB::table('ddh')
          ->join('home_user','ddh.uid','=','home_user.id')
          ->where('statues','2')->get();
   		return view('admin.order.dfh',['data'=>$data]);
   }

   public function dsh()
   {
   		$data=DB::table('ddh')
          ->join('home_user','ddh.uid','=','home_user.id')
          ->where('statues','3')->get();
   		return view('admin.order.dsh',['data'=>$data]);
   }

   public function dh()
   {
      $data=DB::table('ddh')
          ->join('home_user','ddh.uid','=','home_user.id')
          ->where('statues','4')->get();
      return view('admin.order.dh',['data'=>$data]);
   }
}
