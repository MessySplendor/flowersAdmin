<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class StoreController extends Controller
{
	//查询代金券
	public function store()
	{
		$uid = session('homeuser')->det_uid;
		//$ob = DB::table('store_gotbonus')->get();
		$ob = DB::select("select * from store_gotbonus,home_user where store_gotbonus.uid=home_user.id");
        // $aa = json_encode($arr);
        // $bb = json_decode($aa,true);
        // $starttime = $bb[0]['startti'];
        // $stime = date("Y-m-d H:i:s",$starttime);
        // $starttime=date("Y-m-d H:i:s",$arr->startti);
        // print_r($stime);die;
		return view('admin.store.storelist',['store'=>$ob]);
	}
	//删除代金券
	public function delete($id)
	{
		$del = DB::table('store_gotbonus')->where('store_id',$id)->delete();
		if ($del > 0 ) {
			return redirect('/admin/gotbonus');
		}
	}	
	//已用代金券查询
	public function yiyong()
	{ 
		$state = 1;
		$yiyong = DB::table('store_gotbonus')->where('state',$state)->get();
		return view('admin.store.yiyonglist',['yiyong'=>$yiyong]);
	}
	//未用代金券查询
	public function weiyong()
	{ 
		$state = 0;
		$weiyong = DB::table('store_gotbonus')->where('state',$state)->get();
		return view('admin.store.weiyonglist',['weiyong'=>$weiyong]);
	}

}