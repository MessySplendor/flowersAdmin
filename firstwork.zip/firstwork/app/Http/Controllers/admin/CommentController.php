<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class CommentController extends Controller
{

	public function index()
	{
		$comment = DB::table('goods_comment')
		->join('goods','comment_gid','=','goods_id')
		->join('home_user','comment_uid','=','id')
		->paginate(6);
		return view('admin.comment.commentlist',['comment'=>$comment]);
	}

	//删除评论
	public function delete($id)
	{
		$del =DB::table('goods_comment')->where('comment_id',$id)->delete();
		if ($del>0) {
			
			return redirect('/admin/commentlist');
		}
		
	}


}