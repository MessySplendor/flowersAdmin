<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB; 


class HomeuserController extends Controller
{
   //用户
    public function index(Request $request)
    {
        //保存搜索条件
        $where = [];
        //实例化要操作的表
        $db = DB::table('home_user');
        //判断有没有搜索name字段的值
        if($request->has('name')){
            // 获取要搜索的name字段的值
            $name = $request->input('name');
            //添加where模糊匹配条件
            $db->where('name','like',"%{$name}%");
            $where['name'] = $name;
        }
        //分页
        $list = $db->paginate(10);
    	return view('admin.hm_user.userlist',['list'=>$list,'where'=>$where]);
		  
    } 

    public function show($id)
    {
        $lt = DB::table('home_user')->where('id',$id)->first();
        $geren = DB::table('user_detail')->where('det_uid',$id)->first();
        return view('admin.hm_user.geren',['geren'=> $geren ,'lt'=> $lt]);  
    }
    
    
}