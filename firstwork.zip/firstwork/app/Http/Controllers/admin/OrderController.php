<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class OrderController extends Controller
{
    //所有订单列表包括待付款，待发货，待收货，待评价等状态的订单
    public function index($id)
    {
        //dd($id);
    	$data=DB::table('orderlist')
            ->join('goods','gid','=','goods_id')
            ->join('ddh','orderlist.ordernumber','=','ddh.ordernumber')
            ->where('orderlist.commentstatu','=','0')
            ->where('orderlist.ordernumber',$id)
            ->get();
       
    	return view('admin.order.orderlist',['data'=>$data]);
    }
    //去发货  此处会将订单状态有待发货改为待收货状态
    public function fahuo($id)
    {
        //dd($id);
        $data=DB::table('ddh')->where('ordernumber',$id)->update(['statues'=>3]);
        if($data>0){
            return redirect('admin/dd');
        }
    }
}
