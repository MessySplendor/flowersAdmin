<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class GdimageController extends Controller
{
    public function index($goods_id)
    {
    	// dd($goods_id);
    	return view('admin.gdimage',['goods_id'=>$goods_id]);
    }

    public function upload($goods_id,Request $request)
    {
//    	 dd($goods_id);
//    	 dd($request);
    	$data=$request->except('_token');
    	$data['gid']=$goods_id;
//    	 dd($data);
    	 if($request->hasFile('image'))
            {
                if ($request->file('image')->isValid()){
                    //
                    $suffix = $request -> file('image') -> getClientOriginalExtension();
                    $fileName = time().mt_rand(100000,999999) . '.' . $suffix;
//                   	 dd($fileName);
                    if(!file_exists('./uploads/gdimage'))
                    {
                        mkdir('./uploads/gdimage', true, '777');
                    }
                    $move = $request -> file('image') -> move('./uploads/gdimage/', $fileName);
                   if($move)
                    {
                        $data['image'] = $fileName;
                    }
                }
            }
//         dd($data);
        $row=DB::table('goods_image')->insertGetId($data);
        if($row>0){
        	return back();
        }else{
        	return back();
        }
    }
}
