<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class GdetailController extends Controller
{
    public function index($goods_id)
    {
        //dd($goods_id);
    	return view('admin.gdetail',['goods_id'=>$goods_id]);
    }

    public function insert($goods_id,Request $request)
    {
        //dd($goods_id);
        //dd($request);
        //$list['gid']=$goods_id;//这一步不能写上面，这种书写形式是往数组里添加值
        // dd($list);
    	$list=$request->except('_token');
        $list['gid']=$goods_id;//应该写到上一步后面
    	//dd($list);
    	$row=DB::table('goods_detail')->insertGetId($list);
    	//dd($row);
    	if($row>0){
    		return redirect('admin/gdetail/'.$goods_id.'');
    	}else{
    		return redirect('admin/gdetail'.$goods_id.'')->with('msg',"添加详情失败，请重新添加");
    	}
    }
}
