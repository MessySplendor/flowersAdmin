<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
class ShowdetailController extends Controller
{
     public function index($goods_id)
    {
        // var_dump($goods_id);
    	$data=DB::table('goods_detail')->where('gid',$goods_id)->first();
    	// dd($data);
    	return view('admin.showdetail',['data'=>$data]);
    } 

    public function update($goods_detail_id,Request $request)
    {
    	// dd($request);
    	//dd($goods_detail_id);
    	$list=$request->except('_token');
    	// dd($list);
    	$row=DB::table('goods_detail')->where('goods_detail_id',$goods_detail_id)->update($list);
    	if($row>0){
    		return back();
    	}else{
    		return back()->with('修改失败');
    	}
    }
}
