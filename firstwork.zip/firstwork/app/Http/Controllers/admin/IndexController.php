<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class IndexController extends Controller
{
   //后台主页面
    public function index()
    {
    	return view('admin.index');
		
    }

}
