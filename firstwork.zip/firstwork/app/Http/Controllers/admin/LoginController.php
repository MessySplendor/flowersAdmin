<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB; 
//引用一个类来判断用户是否存在
use App\models\User;

class LoginController extends Controller
{
   // 后台登录页面
    public function index()
    {
    	return view('admin.login');
		
    } 

    public function dologin( Request $request)
    {
    	//实例化一个模型
      //dd($request);
      $user = new User();
        //调用模型中的验证用户方法
      $ob = $user->checkUser($request);
      //dd($ob);
      //根据验证结果处理
      if($ob){
        //如果都能通过，则把用户信息存储到session中
      session(['adminuser'=>$ob]);
      //重定向到后台页面
      return redirect('admin');
      }else{
      return back()->with('msg','登录失败：账号或者密码错误');
      }
    }
      //退出登录
     public function logout()
    {
        // 销毁session
        session()->forget('adminuser');
        return redirect('admin/login');
    }
   
}