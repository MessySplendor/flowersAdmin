<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class GoodsController extends Controller
{
    public function index()
    {
        //后台商品查询排序展示
    	$list=DB::table('goods')
            ->select('*',DB::raw("concat(goods_path,goods_id) as pathid"))
            ->orderBy('pathid')
            ->where([
                ['goods_pid','0'],
                ['statu','=','1'],
                ])
            ->get();
    	return view('admin.good.list',['list'=>$list]);
    }
    public function create()
    {
    	return view('admin.good.add');
    }

    //添加商品分类

    public function store(Request $request)
    {

        $data=$request->only('goods_name','goods_pid','goods_path');
       
        $row=DB::table('goods')->insertGetId($data);
        if($row>0){
            return redirect('/admin/good');
        }else{
            echo "添加失败";
        }

    }

    //编辑修改商品分类名称
    public function edit($id)
    {
        $data=DB::table('goods')->where('goods_id',$id)->first();
        return view('admin.good.edit',['data'=>$data]);
         
    }

    public function update($id,Request $request)
    {

        $data=$request->except('_token','_method');
        
        $m=DB::table('goods')->where('goods_id',$id)->update($data);
        if($m>0){
           return redirect('/admin/good');
        }else{
            return redirect('/admin/good');
        }
        
    }

    //删除商品
    public function destroy($id)
    {
        $m=DB::table('goods')->where('goods_id',$id)->delete();
        if($m>0){
            return redirect('admin/good');
         }
       
    }
    //添加子类别
    public function createSon($id)
    {
        
        $data=DB::table('goods')->where('goods_id',$id)->first();
        return view('admin.good.addSon',['data'=>$data]);
    }

    //添加子分类
    public function storeSon(Request $request)
    {
        $data=$request->except('_token');
        //图片上传
        //hasFile确认上传的图片是否存在
        if($request->hasFile('image')){
             //设置允许上传的图片类型
             $allow_ext = array('jpg','jpeg','png','gif');
             $file      = $request->file('image');
             //获取文件后缀名
             $ext       = $file->getClientOriginalExtension();
             if(!in_array($ext,$allow_ext)){
                 return back()->with('msg','上传文件类型错误,重新上传');
             }
             //重命名文件
             $fileName  = time().mt_rand(100000,999999).'.'.$ext;
             if(!file_exists('./uploads/goods')){
                 mkdir('./uploads/goods', true, '777');
             }
             $move      = $file -> move('./uploads/goods/', $fileName);
             if($move){
                 $data['image'] = $fileName;
             }else{
                 $data['image'] = 'letv.jpg';
             }
        }else{
            //判断上传过程中的错误处理
            $error = $request->file('image')->getError();
            switch ($error){
                case 1:
                    $msg = '上传文件大小超出了配置文件中的最大值,请重新上传';
                    break;
                case 2:
                    $msg = '上传文件超过了html中form表单设置的最大值';
                    break;
                case 3:
                    $msg = '部分文件上传';
                    break;
                case 4:
                    $msg = '没有文件上传';
                    break;
                case 6:
                    $msg = '找不到临时文件夹';
                    break;
                case 7:
                    $msg = '文件写入失败';
                    break;
            }
            session(['msg'=>$msg]);
            return back()->with('msg',$msg);
        }
        $n=DB::table('goods')->insertGetId($data);
        if($n>0){
            return redirect('/admin/good');
        }
    }

    public function sonClass($id)
    {
        $list=DB::table('goods')
            ->where([
                ['goods_pid',$id],
                ['statu','1'],
                ])
            ->get();
        return view('admin.good.sonlist',['list'=>$list]);
    }

    //将商品放回回收站
    public function sonPutrecycler($id)
    {

        $row=DB::table('goods')->where('goods_id',$id)->update(['statu'=>'2']);
        if($row>0){
            return back();
        }else{
            return back();
        }
    }
}
