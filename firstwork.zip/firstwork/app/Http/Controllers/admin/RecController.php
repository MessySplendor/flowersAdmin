<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;
class RecController extends Controller
{
    public function index()
    {
    	$list=DB::table('goods')
    		->where('statu','=','2')
    		->get();
        //dd($list);
    	return view('admin.recycler.relist',['list'=>$list]);
    }

     public function gohome($id)
    {
    	$row=DB::table('goods')->where('goods_id',$id)->update(['statu'=>'1']);
    	if($row>0){
    		return redirect('admin/re');
    	}else{
    		return redirect('admin/re');
    	}
    }

    public function del($id)
    {
    	$m=DB::table('goods')->where('goods_id',$id)->delete();
    	if($m>0){
    		return redirect('admin/re');
    	}else{
    		return redirect('admin/re');
    	}
    }

}
