<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class LinkController extends Controller
{
    //友情链接列表
    public function index()
    {
    	$list=DB::table('link')->paginate(2);
    	return view('admin.link.list',['list'=>$list]);
    }
    public function create()
    {
    	return view('admin.link.add');
    }

    //添加友情链接
    public function store(Request $request)
    {
    	
        $data=$request->only('name','url');
        $row=DB::table('link')->insertGetId($data);

        if($row>0){
            return redirect('admin/link');
        }else{
            echo "添加失败";
        }

    }

    //编辑友情链接
    public function edit($id)
    {
        $data=DB::table('link')->where('id',$id)->first();
        return view('admin.link.edit',['data'=>$data]);
         
    }

    public function update($id,Request $request)
    {

        $data=$request->except('_token','_method');
        
        $m=DB::table('link')->where('id',$id)->update($data);
        if($m>0){
           return redirect('/admin/link');
        }else{
            return redirect('/admin/link');
        }
        
    }

    //删除友情链接
    public function destroy($id)
    {

        $m=DB::table('link')->where('id',$id)->delete();
        if($m>0){
            return redirect('admin/link');
        }
    }
}
