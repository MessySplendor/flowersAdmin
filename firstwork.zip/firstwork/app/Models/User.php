<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    
    protected $table = 'admin_user';		//指定绑定的表为user,否则默认绑定users表

    public function checkUser($request)
    {
    	//获取用户登录的用户名
    	$name = $request->input('admin_name');
    	//通过用户名查询数据库有没有这个用户名
    	$ob = $this->where('admin_name',$name)->first();
    	// 如果通过这个用户名能查出数据
        
    	if($ob){
    		//则判断用户输入的密码和通过用户名查到的数据中的密码是否匹配
    		//if(md5($request->input('admin_pass')) == $ob->admin_pass){
            if($request->input('admin_pass')== $ob->admin_pass){
    			return $ob;
    		}
    	}else{
    		return null;
    	}
    }	
}
