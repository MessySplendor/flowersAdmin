<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
class Work extends Model
{
	public $table="home_user";
    public function select(){
    	$res = $this->where('id',73)->first();
    	return $res;
    }
}
