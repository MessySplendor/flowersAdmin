@extends('admin.base.index')

@section('content')

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span>评论列表</h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped mb-none" id="datatable-editable">
					
					<thead>
						<tr>
							<th>编号</th>
							<th>商品名称</th>
							<th>评论时间</th>
							<th>评论内容</th>
							<th>用户</th>
							<th>操作</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($comment as $v)
						<tr class="gradeX">
							<td>{{ $v->comment_id}}</td>
							<td>{{ $v->goods_name}}</td>
							<td>{{ date('Y-m-d H:i:s',$v->comment_time)}}</td>
							<td>{{ $v->comment_content }}</td>
							<td>{{ $v->name }}</td>
							<td>
								<a href="{{ url('admin/comment/'.$v->comment_id.'')}}">删除</a>
							</td>
							
						</tr>
						@endforeach
					</tbody>

					
				</table>
				{{$comment->links()}}
			</div>
		</div>
	</div>
</div>	
@stop				 