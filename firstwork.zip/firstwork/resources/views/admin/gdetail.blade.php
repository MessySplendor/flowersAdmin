
@extends('admin.base.index')
	
@section('content')
	<!-- @if(session('msg'))
		{{session('msg')}}
	@endif -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading bk-bg-white">
					<h6><i class="fa fa-indent red"></i>添加商品详情</h6>						
					<div class="panel-actions">
						<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>					
				<div class="panel-body">
					<form class="form-horizontal" role="form" method="post" action="{{url('admin/gdetail/'.$goods_id.'')}}">
						<input type="hidden" name="_token" value="{{csrf_token()}}">
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">简介信息</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="introduction">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">版本与价格</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="type_price">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">处理器与内存版本一</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="configone">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">处理器与内存版本二</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="configtwo">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">处理器与内存版本三</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="configthree">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">尺寸与重量</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="size_weight">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">摄像与拍照</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="camera">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">续航与闪充</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="electricize">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">屏幕</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="screen">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">运营商</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="operator">
							</div>
						</div>
						<div class="form-group">
							<div class="col-lg-10 col-md-10">
								<div class="row">
									<label class="col-lg-2 col-md-2 col-sm-12 control-label"></label>
									<div class="col-lg-10 col-md-10 ">
										<button type="submit" class="bk-margin-5 btn btn-info">添加</button>
										<button type="reset" class="bk-margin-5 btn btn-default">重置</button>
									</div>
								</div>
							</div>	
						</div>
					</form>
				</div>							
			</div>
		</div>
	</div>
@stop