@extends('admin.base.index')

@section('content')


<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-indent red"></i>添加管理员</h6>							
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<form action="/admin/userlist" method="post" class="form-horizontal ">
		<input type='hidden' name='_token' value='{{ csrf_token() }}'>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-small">账号</label>
			<div class="col-sm-6">
				<input type="text" id="input-small" name="admin_name" class="form-control input-sm" placeholder="账号" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">密码</label>
			<div class="col-sm-6">
				<input type="password" id="input-normal" name="admin_pass" class="form-control" placeholder="密码" />
			</div>
			</div>
			<div class="form-group">
				<div class="col-sm-6">
				</div>
				<div class="col-sm-2">
					<input type="submit"    value="确认添加" />
				</div>
			</div>
		</form>
	</div>					
</div>
				

@stop