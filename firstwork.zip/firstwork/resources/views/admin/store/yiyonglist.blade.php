@extends('admin.base.index')

@section('content')

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span>代金券列表</h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped mb-none" id="datatable-editable">
					
					<thead>
						<tr>
							<th>编号</th>
							<th>用户</th>
							<th>或得时间</th>
							<th>截止时间</th>
							<th>面值</th>
							<th>是否使用</th>
							<th>操作</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($yiyong as $v)
						<tr class="gradeX">
							<td>{{ $v->store_id }}</td>
							<td>{{ $v->uid}}</td>
							<td>{{ $v->startti }}</td>
							<td>{{ $v->stopti }}</td>
							<td>{{ $v->val }}元</td>
							<td>{{ ($v->state =='1')?'已使用':'未使用' }}</td>
							<td>
								<a href="{{ url('admin/del/'.$v->store_id.'')}}">删除</a>
							</td>
							
						</tr>
						@endforeach
					</tbody>
					
				</table>
			</div>
		</div>
	</div>
</div>	
@stop				 