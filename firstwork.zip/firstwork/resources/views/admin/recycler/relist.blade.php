@extends('admin.base.index')
@section('content')
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span><a href="{{ url('admin/re')}}">回收站</a></h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped" id="datatable-default">
					<thead>
						<tr>
							<th>序号</th>
							<th>所属分类</th>
							<th>图片</th>
							<th>操作</th>
						</tr>
					</thead>
					<tbody>
						@foreach($list as $v)
						<tr class="gradeX">
							<td>{{$v->goods_id}}</td>
							<td>{{$v->goods_name}}</td>
							<td>
							<div style="border:1px solid red;">
								<center><img src="{{ asset('/uploads/goods/'.$v->image.'')}}" alt="letv.jpg" width="60px" height="60px" /></center>
							</div>
							
							</td>
							<td>
								<div class="bk-margin-5 btn-group">
									<a href="{{ url('/admin/re/go/'.$v->goods_id.'')}}"><input type="submit" class="btn btn-info" value="还原"></a>
									<a href="{{ url('/admin/re/del/'.$v->goods_id.'')}}"><input type="submit" class="btn btn-danger" value="删除"></a>
								</div>
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>		
@stop