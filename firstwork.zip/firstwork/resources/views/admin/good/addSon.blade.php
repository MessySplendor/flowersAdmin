@extends('admin.base.index')

@section('content')
<div class="row">
<div class="col-lg ">
	<form id="form" action="/admin/createSon" class="form-horizontal" method="post" enctype="multipart/form-data">
		<input type="hidden" name="_token" value="{{csrf_token()}}">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6><i class="fa  fa-check-circle-o bk-fg-warning"></i><a href="/admin/good">添加子板块</a></h6>									
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<div class="form-group">
					<label class="col-sm-3 control-label">父板块名<span class="">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="" class="form-control" value="{{$data->goods_name}}" disabled/>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">添加子板块名 <span class="">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="goods_name" class="form-control" value="" />
					</div>
				</div>
				<div class="form-group">
					<!-- <label class="col-sm-3 control-label">子板块的pid <span class="">*</span></label> -->
					<div class="col-sm-9">
						<input type="hidden" name="goods_pid" class="form-control" value="{{$data->goods_id}}" />
					</div>
				</div>
				<div class="form-group">
					<!-- <label class="col-sm-3 control-label">子path<span class="">*</span></label> -->
					<div class="col-sm-9">
						<input type="hidden" name="goods_path" class="form-control" value="{{$data->goods_path.$data->goods_id.','}}" />
					</div>
				</div>
				 <label class="col-sm-3 control-label">上传图片<span class="">*</span></label>
				<div class="col-sm-9">
					<input type="file" name="image" />
				</div>
				<div class="row">
					<div class="col-sm-9 col-sm-offset-3">
						<button class="bk-margin-5 btn btn-info">添加子板块</button>
						<button type="reset" class="bk-margin-5 btn btn-default">重置</button>
					</div>
				</div>
			</div>									
		</div>
	</form>
	@if(session('msg'))
		<div style="font-size: 16px;color: red;">{{session('msg')}}</div>
	@endif
</div>
</div>
@stop