@extends('admin.base.index')

@section('content')
<div class="col-lg-12">
<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-table"></i><span class="break"></span><a href="/admin/good"><b>商品分类列表</b></a></h6>
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<div class="table-responsive">	
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
				<thead>
					<tr>
						<th>商品编号</th>
						<th>商品名称</th>
						<th>图片</th>
						<th>父板块</th>
						<!-- <th>父板块path</th> -->
						<th>操作</th>
						<th>查看</th>
					</tr>
				</thead>   
				<tbody>	
				@foreach($list as $v)							
					<tr>
						<td>{{$v->goods_id}}</td>
						<td>{{$v->goods_name}}</td>
						
						<td>
							<div style="border:1px solid red;">
								<center><img src="{{ asset('/uploads/goods/'.$v->image.'')}}" alt="letv.jpg" width="80px" height="80px" /></center>
							</div>	
						</td>
						<td>{{$v->goods_pid}}</td>
						<!-- <td>{{$v->goods_path}}</td> -->
						<td>
							<a class="btn btn-primary" href="/admin/createSon/{{$v->goods_id}}">
								<i class="fa fa-search-plus ">添加子分类</i>                                            
							</a>
							<a class="btn btn-info" href="/admin/good/{{$v->goods_id}}/edit">
								<i class="fa fa-edit ">修改</i>                                            
							</a>
							<a class="btn btn-info" href="{{ url('/admin/sonPut/'.$v->goods_id.'')}}">
								<i class="fa fa-edit ">放入回收站</i>                                            
							</a>
						</td>
						<td>
							<a class="btn btn-warning" href="/admin/gdetail/{{$v->goods_id}}">添加商品详情</a>
							<a class="btn btn-primary btn-large" href="/admin/showdetail/{{$v->goods_id}}">查看商品详情</a>
							<a class="btn btn-success" href="{{url('/admin/sonClass/'.$v->goods_id.'')}}">
								<i class="fa fa-search-plus ">查看子分类</i>                                            
							</a>
							<a class="btn btn-success" href="{{url('/admin/gdimage/'.$v->goods_id.'')}}">
								<i class="fa fa-search-plus ">添加图片</i>                                            
							</a>
						</td>
					</tr>

				@endforeach
				</tbody>
			</table>
		</div>
	</div>
</div>
</div>					
</div>
@stop