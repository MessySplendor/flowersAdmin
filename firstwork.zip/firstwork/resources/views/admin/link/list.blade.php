@extends('admin.base.index')

@section('content')
<div class="col-lg-12">
<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-table"></i><span class="break"></span>友情链接</h6>
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<div class="table-responsive">	
			<form action="/admin/link" method="post" name="myform">
				<input type="hidden" name="_token" value="{{csrf_token()}}">
				<input type="hidden" name="_method" value="DELETE">
			</form>
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
				<thead>
					<tr>
						<th>链接编号</th>
						<th>链接名称</th>
						<th>链接地址</th>
						<th>操作</th>
					</tr>
				</thead>   
				<tbody>	
				@foreach($list as $v)							
					<tr>
						<td>{{$v->id}}</td>
						<td>{{$v->name}}</td>
						<td>{{$v->url}}</td>
						<td>
							<a class="btn btn-info" href="/admin/link/{{$v->id}}/edit">
								<i class="fa fa-edit ">修改</i>                                            
							</a>
							<a class="btn btn-danger" href="javascript:doDel({{$v->id}})">
								<i class="fa fa-trash-o ">删除</i> 
							
						</td>
					</tr>

				@endforeach
				</tbody>
			</table>
			{{$list->links()}}
			<script type="text/javascript">
				function doDel(id)
				{
					if(confirm("你确定要删除吗？")){
					var form=document.myform;
					//alert($id);
					form.action='/admin/link/'+id;
					form.submit();
					}
				}
			</script>
		</div>
	</div>
</div>
</div>					
</div>
@stop