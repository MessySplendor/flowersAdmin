@extends('admin.base.index')

@section('content')
<div class="row">
<div class="col-lg ">
	<form id="form" action="/admin/link/{{$data->id}}" class="form-horizontal" method="post">
		<input type="hidden" name="_token" value="{{csrf_token()}}">
		<input type="hidden" name="_method" value="put">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6><i class="fa  fa-check-circle-o bk-fg-warning"></i>修改链接</h6>									
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<div class="form-group">
					<label class="col-sm-3 control-label">链接名称<span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="name" class="form-control" placeholder="您要添加的板块名" value="{{$data->name}}"/>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">链接地址 <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="url" class="form-control" value="{{$data->url}}" />
					</div>
				</div>
				<!-- <div class="form-group">
					<label class="col-sm-3 control-label">父板块path <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="goods_path" class="form-control" value='0,' />
					</div>
				</div> -->
				
				<div class="row">
					<div class="col-sm-9 col-sm-offset-3">
						<button class="bk-margin-5 btn btn-info">修改</button>
						<button type="reset" class="bk-margin-5 btn btn-default">取消修改</button>
					</div>
				</div>
			</div>									
		</div>
	</form>
</div>
</div>
@stop