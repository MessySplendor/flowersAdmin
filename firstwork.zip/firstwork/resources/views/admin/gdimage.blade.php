
@extends('admin.base.index')
	
@section('content')
	<!-- @if(session('msg'))
		{{session('msg')}}
	@endif -->
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading bk-bg-white">
					<h6><i class="fa fa-indent red"></i>添加商品图片</h6>						
					<div class="panel-actions">
						<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>					
				<div class="panel-body">
					<form class="form-horizontal" role="form" method="post" enctype="multipart/form-data" action="{{url('admin/gdimage/'.$goods_id.'')}}">
						<input type="hidden" name="_token" value="{{csrf_token()}}">
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">选择上传图片</label>
							<div class="col-lg-10 col-md-10">
								<input  type="file" name="image">
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">图片标识</label>
							<div class="col-lg-10 col-md-10">
								<input class="form-control" type="text" name="flag">
							</div>
						</div>
					
						<div class="form-group">
							<div class="col-lg-10 col-md-10">
								<div class="row">
									<label class="col-lg-2 col-md-2 col-sm-12 control-label"></label>
									<div class="col-lg-10 col-md-10 ">
										<button type="submit" class="bk-margin-5 btn btn-info">添加</button>
										<button type="reset" class="bk-margin-5 btn btn-default">重置</button>
									</div>
								</div>
							</div>	
						</div>
					</form>
				</div>							
			</div>
		</div>
	</div>
@stop