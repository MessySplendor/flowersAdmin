@extends('admin.base.index')

@section('content')
	<!-- End Page Header -->
	<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="panel panel-default bk-bg-white">
								<div class="panel-heading bk-bg-white">
									<h6><i class="fa fa-table red"></i><span class="break"></span>用户列表</h6>							
									<div class="panel-actions">
										<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
										<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
									</div>
								</div>
								<div class="panel-body">
									<form action="{{ url('admin/homelist')}}" method='post' >
				                        <input type='hidden' name='_token' value='{{ csrf_token() }}'>
				                        <input type='hidden' name='_method' value='DELETE'>
				                    </form>
				                    <form action="{{ url('admin/homelist')}}" method='get'>
										<tr>
											<th>搜索内容:</th>
											<th><input type="text" name="name"></th>
											<th><input type="submit" value="搜索"><br></th>
										</tr>
									</form>
									<br>
									<table class="table table-bordered table-striped" id="datatable-default">
										<thead>
											<tr>
												<th>序号</th>
												<th>用户账号</th>
												<th>状态</th>
												<th class="hidden-phone">权限</th>
												<th class="hidden-phone">操作</th>
											</tr>
										</thead>
										<tbody>
										@foreach($list as $v)
											<tr class="gradeX">
												<td>{{ $v->id }}</td>
												<td>{{ $v->name }}</td>
												<td>{{ $v->status ==1?'正常':'冻结'}}</td>
												<td class="center hidden-phone">用户</td>
												<td class="center hidden-phone">
												<a href="{{ url('admin/homelist/'.$v->id.'') }}">查看用户信息</a>&nbsp;&nbsp;|&nbsp;&nbsp;
												<a href="{{ url('admin/storeadd/'.$v->id.'') }}">送代金券</a>
												
												</td>
											</tr>
										@endforeach
										</tbody>
									</table>
								</div>
							</div>
						</div>	
					<!-- 显示分页，并带上附加搜索参数 -->
                    {{ $list->appends($where)->links() }}	
@stop

<!-- <script src="{{ asset('admins/assets/js/pages/table-advanced.js') }}"></script> -->
 