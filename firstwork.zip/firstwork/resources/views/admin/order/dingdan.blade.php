@extends('admin.base.index')
@section('content')
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span><a href="{{ url('admin/dd')}}">订单列表</a></h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped mb-none" id="datatable-editable">
					
					<thead>
						<tr style="background-color:#eaf8ff">
							<th>订单编号</th>
							<th>下单时间</th>
							<th>用户名</th>
							<th>订单状态</th>
							<th colspan="2" style="text-align:center;">操作</th>
						</tr>
					</thead>
					<tbody>
						@foreach ($data as $v)
						<tr class="gradeX">
							<td>{{$v->ordernumber}}</td>
							<td>{{date("Y-m-d H:i:s",$v->dtime)}}</td>
							<td>{{$v->name}}</td>
							<td style="color:red;">
								@if($v->statues==1)
									待付款
								@elseif($v->statues==2)
									待发货
								@elseif($v->statues==3)
									待收货
								@elseif($v->statues==4)
									交易已完成
								@endif
							</td>
							<td>
								<a href="{{url('admin/odlist/'.$v->ordernumber.'')}}">查看订单</a>
							</td>
							<td>
								@if($v->statues==1)
								<a class="btn btn-info" href="">待付款</a>
								@elseif($v->statues==2)
								<a class="btn btn-info" href="{{ url('admin/fahuo/'.$v->ordernumber.'')}}">去发货</a>
								@elseif($v->statues==3)
								<a class="btn btn-info" href="">等待收货</a>
								@elseif($v->statues==4)
								<a class="btn btn-info" href="">交易成功</a>
								@endif

							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
				{{$data->links()}}
			</div>
		</div>
	</div>
</div>	
@stop				 