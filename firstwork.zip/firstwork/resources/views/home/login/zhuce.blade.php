﻿<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>小米帐号 - 注册</title>
    <script type="text/javascript" src='{{ asset("js/jquery-1.8.3.min.js") }}'></script>
    <link type="text/css" rel="stylesheet" href="{{ asset('homes/Css/reset.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('homes/Css/layout.css') }}">
    <link type="text/css" rel="stylesheet" href="{{ asset('homes/Css/registerpwd.css') }}">
    <style>
    .code{
      margin-top:15px;
      margin-left:0px;
    }
    .facebook_area{
      display:none!important;
    }
    </style>
    <script type="text/javascript">
      msg = document.getElementsByTagName('msg');
      msg.style.color="red";
    </script>
    
  </head>
  <body class="zh_CN">
      
      <div class="layout">
       <div class="n-frame device-frame reg_frame" id="main_container">
        <div class="external_logo_area"><a class="milogo" href="javascript:void(0)"></a></div>
        <div class="title-item t_c">
          <h4 class="title_big30">注册小米帐号</h4>          
        </div>  
      <div><div class="regbox">
       <div class="phone_step1">
        <div class="listwrap" id="select-cycode" _region="CN" _def_method="PH">
			<form action="{{ asset('home/zhuce')}}" method="post" class="form-horizontal" >
			  <input type='hidden' name='_token' value='{{ csrf_token() }}'>
			  <div class="inputbg">
				<label class="labelbox" for="">
				<input name="name" data-type="PH" placeholder="请输入账号" type="tel"required >
				</label>
			  </div>
			  <div class="inputbg">
				<label class="labelbox" for="">
				<input name="pass" data-type="PH" placeholder="请输入密码" type="password" required >
				</label>
			  </div>
			  <div class="inputbg">
				<label class="labelbox" for="">
				<input name="password" data-type="PH" placeholder="请输入确认密码" type="password" required >
				</label>
			  </div>
        <div class="inputbg">
  			  @if (session('msg'))
            {{ session('msg') }}
          @else
                                          
          @endif
        </div>
			  <div class="inputbg inputcode">
				<label class="labelbox" for="">
				<input class="code" name="icode" autocomplete="off" placeholder="图片验证码" type="text" id="code" required>
				</label>
				<img  id="code" src="{{ url('home/capch/'.time()) }}" onclick="this.src='{{ url('home/capch') }}/'+Math.random()" width='120' height='38'>
			 
        </div>
			  
			  
			  <div class="fixed_bot mar_phone_dis1">
				<input class="btn332 btn_reg_1 submit-step" data-to="phone-step2" value="立即注册" type="submit" >
				<img style="display:none;" src="{{ asset('homes/Images/tick.png') }}">
				
			  </div>
			</form>
		  </div>
		</div>
      </div>
      
      </div>
      </div>
      </div>
      <div class="n-footer">
        <div class="nf-link-area clearfix">
        <ul class="lang-select-list">
        <li><a class="lang-select-li current" href="javascript:void(0)" data-lang="zh_CN">简体</a>|</li>
        <li><a class="lang-select-li" href="javascript:void(0)" data-lang="zh_TW">繁体</a>|</li>
        <li><a class="lang-select-li" href="javascript:void(0)" data-lang="en">English</a></li>
        
          |<li><a class="a_critical" href="http://static.account.xiaomi.com/html/faq/faqList.html" target="_blank"><em></em>常见问题</a></li>
        
        </ul>
        </div>
        <p class="nf-intro">
        <span>小米公司版权所有-京ICP备10046444-
          <a class="beianlink beian-record-link" target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134">
            <span><img src="{{ asset('homes/Images/ghs.png') }}"></span>京公网安备11010802020134号</a>-京ICP证110507号</span></p>
      </div>
      
  </body>
</html>

