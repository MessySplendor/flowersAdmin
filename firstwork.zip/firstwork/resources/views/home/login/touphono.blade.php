<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta charset='utf-8'>
	</head>
	<body>
		<h3>文件上传</h3>
		<form action="/home/touphoto" method="POST" enctype="multipart/form-data">
			<input type='hidden' name='_token' value='{{ csrf_token() }}'>
			文件：<input type='file' name='mypic'>
			<input type='submit' value='上传'>
		</form>
		@if(session('msg'))
			<div style="font-size: 16px;color: red;">{{session('msg')}}</div>
		@endif
	</body>
</html>