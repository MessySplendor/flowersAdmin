<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta charset="UTF-8">
        <title>我的购物车-小米商城</title>
        <meta name="viewport" content="width=1226">
    <!-- <link rel="shortcut icon" href="" type="image/x-icon"> -->
        <link rel="icon" href="" type="image/x-icon">
        <link rel="stylesheet" href="{{ asset('homes/cart/base.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('homes/cart/cart.css') }}">
        
    </head>
    <body>
        <div class="site-header site-mini-header">
            <div class="container">
                <div class="header-logo">
                    <a class="logo ir" href="" title="小米官网" data-stat-id="f4006c1551f77f22" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-f4006c1551f77f22', 'pcpid']);">小米官网</a>
                </div>
                <div class="header-title has-more" id="J_miniHeaderTitle"><h2>我的购物车</h2><p>温馨提示：产品是否购买成功，以最终下单为准哦，请尽快结算</p>
    			</div>
            @if(session('homeuser') != null)
                <div class="topbar-info" id="J_userInfo">
                <span class="user"><a rel="nofollow" class="user-name" href="{{ url('home/myself') }}" onclick="_msq.push"><span class="name">{{ session('homeuser')->det_nicheng }}</span><i class="iconfont"></i></a><ul class="user-menu" style="display: none;"><li><a rel="nofollow" href="http://my.mi.com/portal" target="_blank" data-stat-id="e0b9e1d1fa8052a2" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-e0b9e1d1fa8052a2', '//my.mi.com/portal', 'pcpid']);">个人中心</a></li><li><a rel="nofollow" href="http://order.mi.com/user/comment" target="_blank" data-stat-id="6d05445058873c2c" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-6d05445058873c2c', '//order.mi.com/user/comment', 'pcpid']);">评价晒单</a></li><li><a rel="nofollow" href="http://order.mi.com/user/favorite" target="_blank" data-stat-id="32e2967e9a749d3d" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-32e2967e9a749d3d', '//order.mi.com/user/favorite', 'pcpid']);">我的喜欢</a></li><li><a rel="nofollow" href="" target="_blank" data-stat-id="6c2aba14bc7f649a" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-6c2aba14bc7f649a', 'http://account.xiaomi.com/', 'pcpid']);">小米账户</a></li><li><a rel="nofollow" href="" data-stat-id="770a31519c713b11" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-770a31519c713b11', '//order.mi.com/site/logout', 'pcpid']);">退出登录</a></li></ul></span>
                <span class="sep">|</span><a rel="nofollow" class="link link-order" href="{{ url('/home/dingdan')}}" data-stat-id="a9e9205e73f0742c" onclick="_msq.push">我的订单</a>
    		</div>
                @else
                <div id="J_userInfo" class="topbar-info">
                    <a class="link" href="" data-needlogin="true" data-stat-id="bf3aa4c80c0ac789" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-bf3aa4c80c0ac789', '//order.mi.com/site/login', 'pcpid']);">登录</a>
                    <span class="sep">|</span>
                    <a class="link" href=""  >注册</a>
                </div>
                @endif
            </div>
        </div>
    
        <div class="page-main">
    		<div class="container">
                <div class="cart-loading loading hide" id="J_cartLoading">
                    <div class="loader"></div>
                </div>
                <div class="cart-empty hide" id="J_cartEmpty">
                    <h2>您的购物车还是空的！</h2>
                    <p class="login-desc">登录后将显示您之前加入的商品</p>
                    <a href="#" class="btn btn-primary btn-login" id="J_loginBtn" data-stat-id="7874490dbcbc1e60" onclick="_msq.push">立即登录</a>
                    <a href="" class="btn btn-primary btn-shoping J_goShoping" data-stat-id="4658a7dfd89505fc" onclick="_msq.push">马上去购物</a>
                </div>

                <div id="J_cartBox" class="">
                    <div class="cart-goods-list">
                        <div class="list-head clearfix">
                            <div class="col col-check" id ="www"><i class="iconfont icon-checkbox " id="J_selectAll">√</i>全选</div>
                            <div class="col col-img">&nbsp;</div>
                            <div class="col col-name">商品名称</div>

                            <div class="col col-price">单价</div>
                            <div class="col col-num">数量</div>
                            <div class="col col-total">小计</div>
                            <div class="col col-action">操作</div>
                        </div>
                        @for($i=0;$i<count($cart);$i++)
                        <div class="list-body" id="J_cartListBody">   
                            
                            <div class="item-box"> 
                                <div class="item-table J_cartGoods" data-info="{ commodity_id:'1153900039', gettype:'buy', itemid:'2153900026_0_buy', num:'1'} ">
                                    <div class="item-row clearfix"> 
                                        <div class="col col-check sunzi" >
                                            <i id="www" class="iconfont icon-checkbox icon-checkbox  J_itemCheckbox" good_id="{{ $cart[$i]->car_id }}" >√</i>
                                        </div>
                                        <div class="col col-img">
                                            <div style="display:none" id="carid">{{ $cart[$i]->car_id }}</div>
                                            <a href="{{ url('home/gdetail/'.$cart[$i]->car_gid.'')}}" target="_blank">
                                                
                                                <img alt="" src="{{asset('uploads/gdimage/'.$list[$i].'')}}" width="80" height="80">
                                                
                                            </a>
                                        </div>
                                        <div class="col col-name">
                                            <div class="tags">
    										</div> 
                                            <h3 class="name">  <a href="{{ url('home/gdetail/'.$cart[$i]->car_gid.'')}}" target="_blank"> {{ $cart[$i]->goods_name.' '.$cart[$i]->car_type.' '.$cart[$i]->car_color}}</a>  </h3>
    									</div>
                                        <div class="col col-price" id="yuan"> {{ $cart[$i]->car_price }}元 </div>
                                        <div class="col col-num">  
    										<div class="change-goods-num clearfix J_changeGoodsNum"> 
    											<a  class="J_minusJ_minus" onclick="dojian(this,'{{ $cart[$i]->car_price }}',{{ $cart[$i]->car_id }})">
                                                     <i class="iconfont">-</i>
                                                </a>
    											<input tyep="text" name="cartnumber" value="{{ $cart[$i]->car_number }}"  data-buylimit="20" autocomplete="off" class="goods-num J_goodsNum"   onclick="inpt(this,'{{$cart[$i]->car_price}}',{{$cart[$i]->car_id}})">
                                                <a  class="J_plus" onclick="doadd(this,'{{$cart[$i]->car_price}}',{{$cart[$i]->car_id}})"><i class="iconfont">+</i></a>
                                             </div>
                                        </div>
                                        <div class="col col-total" id="xj">{{ ($cart[$i]->car_price)* ($cart[$i]->car_number)  }}元</div>
                                        <div class="col col-action">
    										<a id="2153900026_0_buy" data-msg="确定删除吗？" href="javascript:void(0)" title="删除" class="del J_delGoods" onclick="dodel(this,{{$cart[$i]->car_id}})"><i class="iconfont"></i></a> 
                                        </div>
    								</div> 
    							</div>
    						</div>  
    					</div>
                        @endfor
                  </div>
    		</div>
    	</div>
                <!-- 加价购 -->
                <div class="raise-buy-box" id="J_raiseBuyBox"> </div>

                <div class="cart-bar clearfix" id="J_cartBar">
                    <div class="section-left">
                        <a class="back-shopping J_goShoping" data-stat-id="3d1e5bdd191768c8" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-3d1e5bdd191768c8', '#', 'pcpid']);">继续购物</a>
                        <!-- <span class="cart-total">共 <i id="J_cartTotalNum">2</i> 件商品，已选择 <i id="J_selTotalNum">0</i> 件</span> -->
                        
                    </div>
                    
                    <span class="total-price">
                        合计（不含运费）：<em id="J_cartTotalPrice" class="hj">0</em>元
                    </span>
                    <a href="javascript:void(0);" class="btn btn-a btn btn-disabled" id="J_goCheckout" data-stat-id="f975aeb3e19f0f37" onclick="goorder()">去结算</a>
                </div>
        </div>
        <div class="cart-recommend hide" id="J_historyRecommend"></div>    
    </div>
</div>
<script type="text/javascript" src="{{ asset('js/jquery-1.8.3.min.js') }}"></script>
<script type="text/javascript">
//商品数量的增加
    function doadd(bt,p,id){
        var a=$(bt).prev('input');
        var b=a.val();
        $.ajax({
            url: '{{ url("/cartadd") }}',
            type: 'post',
            dataType: "json",
            data: {id:id,_token:'{{csrf_token()}}',},

            success:function(data){
                if(data==1){
                   var num=++b;
                    a.val(num);
                    var c=num*p;
                    $(bt).parent().parent().next().html(c+'元');
                    if($(bt).parent().parent().parent().children('div').eq(0).children().eq(0).attr('id') =='ppp'){
                       var aa = $('.hj').html();
                       var bb = parseInt(aa);
                       var pp = parseInt(p)
                       var sd = bb+pp;
                       $('.hj').html(sd);
                    }
                    
                }
              
            },
        })  
    }
//商品数量减少
    function dojian(bt,p,id){
        var a=$(bt).next('input');
        var b=a.val();
        
        $.ajax({
            url: '{{ url("/cartjian") }}',
            type: 'post',
            dataType: "json",
            data: {id:id,_token:'{{csrf_token()}}',},

            success:function(data){
                if(b >1){
                    if(data==1){
                       var num=--b;
                        a.val(num);
                        var c=num*p;
                        $(bt).parent().parent().next().html(c+'元'); 
                        if($(bt).parent().parent().parent().children('div').eq(0).children().eq(0).attr('id') =='ppp'){
                           var aa = $('.hj').html();
                           var bb = parseInt(aa);
                           var pp = parseInt(p)
                           var sd = bb-pp;
                           $('.hj').html(sd);
                        }

                    }
                }
            },
        })
    }
//input添加商品数
   
    function inpt(bt,p,id){
        $(bt).blur(function() {
            var input = $(bt).val();
            $.ajax({
            url: '{{ url("/cartinput") }}',
            type: 'post',
            dataType: "json",
            data: {id:id,num:input,_token:'{{csrf_token()}}',},

            success:function(data){
                if (data > 0) {
                    var hj = input * p;
                    $(bt).parent().parent().next().html(hj+'元');
                    if($(bt).parent().parent().parent().children('div').eq(0).children().eq(0).attr('id') =='ppp'){
                            //var xj = $('').html();
                            //alert(hj);
                           
                           //$('.hj').html(xj);
                        }           
                };
            },
            
            });
        });
    }

//删除商品  
    function dodel(bt,id){
         //alert(t);
         //confirm(t)
        if(confirm("你确定要删除商品吗？")){
            $.ajax({
                url: '{{ url("/cartdel") }}',
                type: 'post',
                dataType: "json",
                data: {id:id,_token:'{{csrf_token()}}'},

                success:function(data){
                   if(data >0){
                        $(bt).parent().parent().parent().parent().css('display','none');
                   }
                }
            });
        }
    }


//全部选择商品
    var count=0;
    var val=""; 
    $("#J_selectAll").click(
        function() {
        if($(this).parent().attr('id')=='www'){
             //count=0;
            $(this).addClass("icon-checkbox-selected");
            $('.J_itemCheckbox').addClass("icon-checkbox-selected");
            var list=$('.J_itemCheckbox')
            for(var i=0; i<list.length;i++){
                valll=$(list[i])
                val=$(list[i]).parent().next().next().next().next().next('#xj');
                var vall=val.html()
                count =count+ parseInt(vall);
                $(valll).attr("id",'ppp');
               
            }
            $(this).parent().attr('id','ppp')
             $('.hj').html(count);


        }else{
            $(this).removeClass("icon-checkbox-selected");
            count=0
            $('.hj').html(count);
            var list=$('.J_itemCheckbox')
            for(var i=0; i<list.length;i++){
                var val=$(list[i]);
                $(val).removeClass("icon-checkbox-selected");
                $(val).attr("id",'www');
                
                
           }
           $(this).parent().attr('id','www');
        }
        
    });
   
    //单个选择商品
    
       $(".J_itemCheckbox").click(
        function() {
            if($(this).attr('id')=="www"){
                $(this).addClass("icon-checkbox-selected");
                var ss = $(this).parent().next().next().next().next().next('#xj').html();
                //count = $('hj').html();
                //alert(count);
                var hj = parseInt(ss);
                count=count+hj;
                $(this).attr("id",'ppp');
                $('.hj').html(count);
                
            }else{  
                var ss = $(this).parent().next().next().next().next().next('#xj').html();
                var hj = parseInt(ss);
                count = $('.hj').html();
                count= count-hj;
                //alert(count);
                console.log(count);
                $('.hj').html(count);
                $(this).removeClass("icon-checkbox-selected");
                $(this).attr("id",'www');
            }
            $("#J_selectAll").removeClass("icon-checkbox-selected"); 
            $('#J_selectAll').parent().attr('id','www'); 
       });
       $('.hj').html(count);

    //结算商品
    
    function goorder(){
        var box = $('.J_itemCheckbox');
        var good_id=[];
        for(var a=0;a<box.length;a++){
            if($(box[a]).attr('id')=="ppp"){
                  good_id[good_id.length]=$(box[a]).attr('good_id');            } 
        }
                $.ajax({
            url: '{{ url("/goorder") }}',
            type: 'post',
            dataType: "json",
            data: {id:good_id,_token:'{{csrf_token()}}',},

            success:function(data){
                if (data >0) {
                var id=data;
                window.location.href='home/check/'+id;
                };
            },
        });

    }

    


</script>
</body>
</html>