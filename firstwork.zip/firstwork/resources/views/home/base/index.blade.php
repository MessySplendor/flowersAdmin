<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN">
    <head>
        <title>小米商城</title>
        
        <meta charset="UTF-8">
        <meta name="description" content="小米商城直营小米公司旗下所有产品，囊括小米手机系列小米MIX、小米Note 2，红米手机系列红米Note 4、红米4，智能硬件，配件及小米生活周边，同时提供小米客户服务及售后支持。">
        <meta name="keywords" content="小米,小米5s,红米Note4,小米MIX,小米商城">
        <meta name="viewport" content="width=1226">
        <link rel="shortcut icon" href="" type="image/x-icon">
        <link rel="icon" href="" type="image/x-icon">
		<link rel="stylesheet" href="{{ asset('homes/css/base.min.css')}}">
        <link rel="stylesheet" href="{{ asset('homes/css/index.min.css')}}">
        <!-- <link rel="stylesheet" href="{{ asset('homes/goods_detail/base.min.css')}}"> -->
        <link rel="stylesheet" type="text/css" href="{{ asset('homes/goods_detail/specs.css')}}">

        <script type="text/javascript">var _head_over_time = (new Date()).getTime();</script>
        <script src="{{ asset('homes/js/base.js')}}"></script>
		<script type="text/javascript" scr="{{ asset('homes/js/jquery.js')}}"></script>
		<script src="{{ asset('homes/js/home.js')}}"></script>
		<script src="{{ asset('homes/js/xmsg_ti.js')}}"></script>
    </head>
	<body>
		<div class="site-topbar">
			<div class="container">
				<div class="topbar-nav">
					<a href="" onclick="_msq.push">小米商城</a>
						<span class="sep">|</span>
					<a href="" onclick="_msq.push">MIUI</a>
				</div>
				<div class="topbar-cart" id="J_miniCartTrigger">
					<a rel="nofollow" class="cart-mini" id="J_miniCartBtn" href="{{ url('/cart') }}"><i class="iconfont">&#xe60c;</i>购物车
						<span class="cart-mini-num J_cartNum"></span>
					</a>
					<div class="cart-menu" id="J_miniCartMenu">
						<div class="loading"><div class="loader"></div></div>
					</div>
				</div>
				@if(session('homeuser') != null)
        
				<div class="topbar-info" id="J_userInfo">
					 <a  rel="nofollow" class="link" href="{{ url('home/myself') }}" data-needlogin="true">{{ session('homeuser')->det_nicheng }}</a><span class="sep">|</span><a  rel="nofollow" class="link" href="{{ url('home/out') }}" >退出</a><span class="sep">|</span><a href="{{ url('home/dingdan') }}">我的订单</a>
				</div>
				@else
				<div class="topbar-info" id="J_userInfo">
					<a  rel="nofollow" class="link" href="{{ asset('home/login')}}" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="{{ asset('home/zhuce') }}" >注册</a>
				</div>
				@endif
			</div>
		</div>
		
				@yield('content')
		 <div class="site-footer">
			<div class="container">
				<div class="footer-service">
					<ul class="list-service clearfix">
						<li><a rel="nofollow" href="" onclick="_msq.push"><i class="iconfont"></i>预约维修服务</a></li>
						<li><a rel="nofollow" href="" onclick="_msq.push"><i class="iconfont"></i>7天无理由退货</a></li>
						<li><a rel="nofollow" href="" onclick="_msq.push"><i class="iconfont"></i>15天免费换货</a></li>
						<li><a rel="nofollow" href="" onclick="_msq.push"><i class="iconfont"></i>满99元包邮</a></li>
						<li><a rel="nofollow" href="" onclick="_msq.push"><i class="iconfont"></i>520余家售后网点</a></li>
					</ul>
				</div>
				<div class="footer-links clearfix">
					
					<dl class="col-links col-links-first">
						<dt>友情链接</dt>
						
						<dd><a rel="nofollow" href="www.baidu.com" onclick="_msq.push">百度</a></dd>
						
						<dd><a rel="nofollow" href="www.taobao.com" onclick="_msq.push">淘宝</a></dd>
						
						<dd><a rel="nofollow" href="www.tengxun.com" onclick="_msq.push">腾讯</a></dd>                
					</dl>
						
					
					<div class="col-contact">
						<p class="phone">400-100-5678</p>
						<p><span class="J_serviceTime-normal" style="">周一至周日 8:00-18:00</span>
						<span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
						<a rel="nofollow" class="btn btn-line-primary btn-small" href=""  onclick="_msq.push"><i class="iconfont"></i> 24小时在线客服</a>            
					</div>
				</div>
			</div>
		</div>
		<div class="site-info">
			<div class="container">
				<div class="logo ir">小米官网</div>
				<div class="info-text">
					<p class="sites">
						<a rel="nofollow" href=""  onclick="_msq.push">小米商城</a>
							<span class="sep">|</span>
						<a rel="nofollow" href="" onclick="_msq.push">MIUI</a>
					</p>
					<p>©
						<a href="" onclick="_msq.push">mi.com</a> 京ICP证110507号 
						<a href=""  onclick="_msq.push">京ICP备10046444号</a> 
						<a rel="nofollow" href=""  onclick="_msq.push">京公网安备11010802020134号 </a>
						<a rel="nofollow" href="" onclick="_msq.push">京网文[2014]0059-0009号</a>

						<br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试
					</p>
				</div>
				<div class="info-links">
					<a rel="nofollow" href="" onclick="_msq.push">
						<img rel="nofollow" src="" alt="TRUSTe Privacy Certification">
					</a>
					<a rel="nofollow" href="" onclick="_msq.push">
						<img rel="nofollow" src="" alt="诚信网站">
					</a>
					<a rel="nofollow" href="" onclick="_msq.push">
						<img rel="nofollow" src="" alt="可信网站">
					</a>
					<a rel="nofollow" href="" onclick="_msq.push">
						<img rel="nofollow" src="" alt="网上交易保障中心">
					</a>
				</div>
			</div>
			<div class="slogan ir">探索黑科技，小米为发烧而生</div>
		</div>
		<div id="J_modalWeixin" class="modal fade modal-hide modal-weixin" data-width="480" data-height="520">
			<div class="modal-hd">
				<a class="close" onclick="_msq.push"><i class="iconfont"></i></a>
				<span class="title">小米手机官方微信二维码</span>
			</div>
			<div class="modal-bd">
				<p style="margin: 0 0 10px;">打开微信，点击右上角的“+”，选择“扫一扫”功能，<br>对准下方二维码即可。</p>
				<img alt="" src="" width="375" height="375">
			</div>
		</div>
	</body>
</html>