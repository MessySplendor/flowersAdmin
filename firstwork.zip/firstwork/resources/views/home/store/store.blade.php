@extends('home.myslef.myself')

@section('content')

<div class="span16">
	<div class="uc-box uc-main-box">
		<div class="uc-content-box coupon-box">
			<div class="box-hd">
				<h1 class="title">优惠券</h1>
				<div class="more clearfix">
					<br>

				</div>
			</div>
			<div class="box-bd">
				
				<div id="J_couponContainer" class="tab-container">
				<br>
					<table style="border:1px solid #b0b0b0;" width="800" height="50">
						<tr style="background-color:#eaf8ff;">
							<th>面值</th>
							<th>获得时间</th>
							<th>到期时间</th>
							<th>是否使用</th>
						</tr>
						@foreach ($store as $v)
						<tr>
							<td>{{ $v->val }}元</td>
							<td>{{ date('Y-m-d H:i:s',$v->stopti) }}</td>
							<td>{{ date('Y-m-d H:i:s', $v->startti) }}</td>
							<td>
								@if($v->state==0)
									未使用
								@elseif($v->orderstatu==1)
									已使用
								@elseif($v->orderstatu==2)
									已过期
								@endif
							</td>
						</tr>
						@endforeach
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@stop