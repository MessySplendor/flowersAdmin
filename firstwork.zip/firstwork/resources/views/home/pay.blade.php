<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta charset="UTF-8">
<title>选择在线支付方式</title>
<meta name="viewport" content="width=1226">
<link rel="shortcut icon" href="" type="image/x-icon">
<link rel="icon" href="" type="image/x-icon">
<link rel="stylesheet" href="{{asset('homes/pay/base.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('homes/pay/pay-confirm.css')}}">
<script type="text/javascript" async="" src="{{asset('homes/pay/mstr_002.js')}}"></script>
<script type="text/javascript" async="" src="{{asset('homes/pay/unjcV2.js')}}"></script>
<script type="text/javascript" async="" src="{{asset('homes/pay/mstr.js')}}"></script>
<script type="text/javascript" async="" src="{{asset('homes/pay/jquery.js')}}"></script>
<script type="text/javascript" async="" src="{{asset('homes/pay/xmst.js')}}"></script>
</head>
<body>
<div class="site-header site-mini-header">
    <div class="container">
        <div class="header-logo">
            <a class="logo " href="" title="小米官网" data-stat-id="ac576a29202325c4" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ac576a29202325c4', '//www.mi.com/index.html', 'pcpid']);"></a>
        </div>
        <div class="header-title" id="J_miniHeaderTitle"><h2>支付订单</h2></div>
        @if(session('homeuser') != null)
        
                <div class="topbar-info" id="J_userInfo">
                     <a  rel="nofollow" class="link" href="{{ url('home/myself') }}" data-needlogin="true">{{ session('homeuser')->det_nicheng }}</a><span class="sep">|</span><a  rel="nofollow" class="link" href="{{ url('home/out') }}" >退出</a><span class="sep">|</span><a href="{{ url('home/dingdan') }}">我的订单</a>
                </div>
                @else
                <div class="topbar-info" id="J_userInfo">
                    <a  rel="nofollow" class="link" href="{{ asset('home/login')}}" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="{{ asset('home/zhuce') }}" >注册</a>
                </div>
                @endif
    </div>
</div>
<!-- .site-mini-header END -->
<script type="text/javascript">
var _confirmConfig = {
    order_id:'1170108524702511',
    safe_tel:'',
    goods_amount:'1599.00'
};
</script>
<script type="text/javascript" src="{{asset('js/jquery-1.8.3.min.js')}}"></script>
<script type="text/javascript">
    $(function(){
        $('#weixin').mousedown(function(){
        alert('支付成功');
        var id=$(this).attr('did');
        // alert(id);
        $.ajax({
            url:'{{url('home/orderstatus')}}',
            async:true,                
            type:'post',               
            data:{id:id,_token:'{{ csrf_token()}}'},               
            dataType:'json',
            success:function(data)
            {
                if(data){
                    window.location.href='/home';
                }
            }
        });
    });
});  
</script>
<div class="page-main">
    <div class="container confirm-box">
                <form target="_blank" action="#" id="J_payForm" method="post">
            <div class="section section-order">
                <div class="order-info clearfix">
                    <div class="fl">
                        <h2 class="title">订单提交成功！去付款咯～</h2>
                        <p class="order-time" id="J_deliverDesc"></p>
                        <p class="order-time">请在<span class="pay-time-tip">0小时30分</span>内完成支付, 超时后将取消订单</p>
                        <p class="post-info post-info-hide" id="J_postInfo">
                            收货信息：{{$address->name}} {{$address->phone}} &nbsp;&nbsp;{{$address->address}}&nbsp;&nbsp;{{$address->address_detail}}      
                        </p>
                    </div>
                    <div class="fr">
                        <p class="total">
                            应付总额：<span class="money"><em>{{$price_count}}</em>元</span>
                        </p>
                        <a href="javascript:void(0);" class="show-detail" id="J_showDetail" data-stat-id="f6ce11cebe4cd0c7" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-f6ce11cebe4cd0c7', 'javascript:void(0);', 'pcpid']);">订单详情<i class="iconfont"></i></a>
                    </div>
                </div>
                <i class="iconfont icon-right">√</i>
                <div class="order-detail" style="display: block;">
                    <ul>
                        <li class="clearfix">
                            <div class="label">订单号：</div>
                            <div class="content">
                                <span class="order-num">
                                    {{$ordernumber}}                                
                                </span>
                            </div>
                        </li>
                        <li class="clearfix">
                            <div class="label">收货信息：</div>
                            <div class="content">
                            {{$address->name}} {{$address->phone}} &nbsp;&nbsp;{{$address->address}}&nbsp;&nbsp;{{$address->address_detail}}
                        </li>
                        <li class="clearfix">
                            <div class="label">商品名称：</div>
                            @for($i=0;$i<count($order);$i++)
                            @if($i=='0')
                            <div class="content">
                                {{$order[$i]->goods_name}} {{$order[$i]->car_type}} {{$order[$i]->car_color}}                             
                            </div><br>
                            @else
                            <div class="content" style="float:left;margin-left:84px;">
                                {{$order[$i]->goods_name}} {{$order[$i]->car_type}} {{$order[$i]->car_color}}                             
                            </div><br>
                            @endif
                            @endfor
                        </li>
                        <li class="clearfix">
                            <div class="label">配送时间：</div>
                            <div class="content">
                                不限送货时间                            
                            </div>
                        </li>
                        <li class="clearfix">
                            <div class="label">发票信息：</div>
                            <div class="content">
                                个人电子发票                            
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            
            <div class="section section-payment">
                <div class="cash-title" id="J_cashTitle">
                                        选择以下支付方式付款
                                    </div>

                <div class="payment-box ">
                    <div class="payment-header clearfix">
                        <h3 class="title">支付平台</h3>
                        <span class="desc"></span>
                    </div>
                    <div class="payment-body">
                        <ul class="clearfix payment-list J_paymentList J_linksign-customize">
                            <li id="weixin" did='{{$id}}' data-stat-id="ecb19ebff89bfe8d" >
                                <img  src="{{asset('homes/pay/wechat0715.jpg')}}" alt="微信支付" style="margin-left: 0;">
                            </li>
                            <li class="J_bank" data-stat-id="697962cd4871b27e" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-697962cd4871b27e', '', 'pcpid']);">
                                <input name="payOnlineBank" id="alipay" value="alipay" type="radio"> 
                                <img src="{{asset('homes/pay/alipay-0718-1.png')}}" alt="支付宝" style="margin-left: 0;">
                            </li>
                            <li class="J_bank" data-stat-id="f8ac83d702a1fcfd" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-f8ac83d702a1fcfd', '', 'pcpid']);">
                                <input name="payOnlineBank" id="unionpay" value="unionpay" type="radio"> 
                                <img src="{{asset('homes/pay/unionpay.png')}}" alt="银联" style="margin-left: 0;">
                            </li>
                            <li class="J_bank" data-stat-id="c6597ab9a9e0bd00" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c6597ab9a9e0bd00', '', 'pcpid']);">
                                <input name="payOnlineBank" id="cft" value="cft" type="radio">
                                <img src="{{asset('homes/pay/cft.png')}}" alt="财付通" style="margin-left: 0;">
                            </li>
                            <li class="J_bank" data-stat-id="a87f620c78db2b2b" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-a87f620c78db2b2b', '', 'pcpid']);">
                                <input name="payOnlineBank" id="micash" value="micash" type="radio"> 
                                <img src="{{asset('homes/pay/micash.png')}}" alt="小米钱包" style="margin-left: 0;">
                            </li>                        
                        </ul>
                        <div class="event-desc">
                            <p>微信支付：关注小米手机微信公众号，支付成功后可领取3-10元电影票红包。</p><p>支 付 宝：支付宝扫码支付满38元，参与赢取1999元红包</p>                            <a href="" class="more" target="_blank" data-stat-id="e77b22cecb60b77e" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-e77b22cecb60b77e','pcpid']);">了解更多&gt;</a>
                        </div>
                    </div>
                </div>

                <div class="payment-box ">
                    <div class="payment-header clearfix">
                        <h3 class="title">银行借记卡及信用卡</h3>
                    </div>
                    <div class="payment-body">
                        <ul class="clearfix payment-list payment-list-much J_paymentList J_linksign-customize">
                            <li class="J_bank" data-stat-id="ab154aed085947cf" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ab154aed085947cf', '', 'pcpid']);"><input name="payOnlineBank" id="CMB" value="CMB" type="radio"> <img src="{{asset('homes/pay/payOnline_jsyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="06de530039da8b38" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-06de530039da8b38', '', 'pcpid']);"><input name="payOnlineBank" id="COMM" value="COMM" type="radio"> <img src="{{asset('homes/pay/payOnline_youzheng.png')}}" alt=""></li><li class="J_bank" data-stat-id="ab2fd7c15b466ad2" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ab2fd7c15b466ad2', '', 'pcpid']);"><input name="payOnlineBank" id="GDB" value="GDB" type="radio"> <img src="{{asset('homes/pay/payOnline_gfyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="a3c47799e97d470d" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-a3c47799e97d470d', '', 'pcpid']);"><input name="payOnlineBank" id="SPDB" value="SPDB" type="radio"> <img src="{{asset('homes/pay/payOnline_pufa.png')}}" alt=""></li><li class="J_bank" data-stat-id="56565ba582001f90" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-56565ba582001f90', '', 'pcpid']);"><input name="payOnlineBank" id="CEBBANK" value="CEBBANK" type="radio"> <img src="{{asset('homes/pay/payOnline_gdyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="4768ae2336413eb6" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-4768ae2336413eb6', '', 'pcpid']);"><input name="payOnlineBank" id="CIB" value="CIB" type="radio"> <img src="{{asset('homes/pay/payOnline_xyyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="6eef43a83d87cc0b" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6eef43a83d87cc0b', '', 'pcpid']);"><input name="payOnlineBank" id="CMBC" value="CMBC" type="radio"> <img src="{{asset('homes/pay/payOnline_msyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="c7a05519141a406a" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c7a05519141a406a', '', 'pcpid']);"><input name="payOnlineBank" id="CITIC" value="CITIC" type="radio"> <img src="{{asset('homes/pay/payOnline_zxyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="cf61ac1722da02b2" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-cf61ac1722da02b2', '', 'pcpid']);"><input name="payOnlineBank" id="SHBANK" value="SHBANK" type="radio"> <img src="{{asset('homes/pay/payOnline_shyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="97f3869e8b59e807" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-97f3869e8b59e807', '', 'pcpid']);"><input name="payOnlineBank" id="BJRCB" value="BJRCB" type="radio"> <img src="{{asset('homes/pay/payOnline_bjnsyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="182a6540a166f721" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-182a6540a166f721', '', 'pcpid']);"><input name="payOnlineBank" id="NBBANK" value="NBBANK" type="radio"> <img src="{{asset('homes/pay/payOnline_nbyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="0c1fd9edbb2ffdf3" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-0c1fd9edbb2ffdf3', '', 'pcpid']);"><input name="payOnlineBank" id="HZCBB2C" value="HZCBB2C" type="radio"> <img src="{{asset('homes/pay/payOnline_hzyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="e2164be795d58002" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-e2164be795d58002', '', 'pcpid']);"><input name="payOnlineBank" id="SHRCB" value="SHRCB" type="radio"> <img src="{{asset('homes/pay/payOnline_shnsyh.png')}}" alt=""></li><li class="J_bank hide" data-stat-id="ce440019c46271da" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ce440019c46271da', '', 'pcpid']);"><input name="payOnlineBank" id="FDB" value="FDB" type="radio"> <img src="{{asset('homes/pay/payOnline_fcyh.png')}}" alt=""></li>                            <li class="J_showMore" data-stat-id="8b70221d47a030ba" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-8b70221d47a030ba', '', 'pcpid']);">
                                <span class="text">查看更多</span>
                                <span class="text  hide">收起更多</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="payment-box payment-box-last ">
                    <div class="payment-header clearfix">
                        <h3 class="title">快捷支付</h3>
                        <span class="desc">（支持以下各银行信用卡以及部分银行借记卡）</span>
                    </div>
                    <div class="payment-body">
                        <ul class="clearfix payment-list  J_paymentList J_linksign-customize">
                            <li class="J_bank" data-stat-id="cf5c79caebd4ce4d" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-cf5c79caebd4ce4d', '', 'pcpid']);"><input name="payOnlineBank" id="CMB-KQ" value="CMB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_zsyh_002.png')}}" alt=""></li><li class="J_bank" data-stat-id="7659e125813c697e" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-7659e125813c697e', '', 'pcpid']);"><input name="payOnlineBank" id="COMM-KQ" value="COMM-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_jtyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="ac8d246311892220" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ac8d246311892220', '', 'pcpid']);"><input name="payOnlineBank" id="CCB-KQ" value="CCB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_jsyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="ee06952bbd4f4d0a" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ee06952bbd4f4d0a', '', 'pcpid']);"><input name="payOnlineBank" id="ICBCB2C-KQ" value="ICBCB2C-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_gsyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="74411e695cd6624e" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-74411e695cd6624e', '', 'pcpid']);"><input name="payOnlineBank" id="CITIC-KQ" value="CITIC-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_zxyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="6a609f8ffa09ec9d" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6a609f8ffa09ec9d', '', 'pcpid']);"><input name="payOnlineBank" id="CEBBANK-KQ" value="CEBBANK-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_gdyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="3f5bfe4137171a90" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-3f5bfe4137171a90', '', 'pcpid']);"><input name="payOnlineBank" id="BOCB2C-KQ" value="BOCB2C-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_zgyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="b64f8a9b6dd3b75c" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-b64f8a9b6dd3b75c', '', 'pcpid']);"><input name="payOnlineBank" id="SRCB-KQ" value="SRCB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_shncsyyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="729ad1d14eee2a2f" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-729ad1d14eee2a2f', '', 'pcpid']);"><input name="payOnlineBank" id="JSB-KQ" value="JSB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_jiangsshuyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="9aa4813e4a7fd47c" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-9aa4813e4a7fd47c', '', 'pcpid']);"><input name="payOnlineBank" id="CIB-KQ" value="CIB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_xyyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="3420e08efd3d3e67" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-3420e08efd3d3e67', '', 'pcpid']);"><input name="payOnlineBank" id="ABC-KQ" value="ABC-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_nyyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="61c6b46df23af369" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-61c6b46df23af369', '', 'pcpid']);"><input name="payOnlineBank" id="SPABANK-KQ" value="SPABANK-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_payh.png')}}" alt=""></li><li class="J_bank" data-stat-id="b4dc808a450a09da" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-b4dc808a450a09da', '', 'pcpid']);"><input name="payOnlineBank" id="HXB-KQ" value="HXB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_hyyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="5c39e922eb18bc68" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-5c39e922eb18bc68', '', 'pcpid']);"><input name="payOnlineBank" id="GDB-KQ" value="GDB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_gfyh.png')}}" alt=""></li><li class="J_bank" data-stat-id="adc2b0678ca52fb2" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-adc2b0678ca52fb2', '', 'pcpid']);"><input name="payOnlineBank" id="BOB-KQ" value="BOB-KQ" type="radio"> <img src="{{asset('homes/pay/payOnline_bjyh.png')}}" alt=""></li>                        </ul>
                    </div>
                </div>
            </div>
                        <div class="section section-installment" id="J_paymentFenqi">
                <div class="payment-box">
                    <div class="payment-header clearfix">
                        <h3 class="title">分期付款</h3>
                        <span class="desc"></span>
                    </div>
                    <div class="payment-body">
                        <ul class="clearfix payment-list J_paymentList J_linksign-customize J_tabSwitch">
                            <li class="J_bank fenqi" id="J_huabeifenqi" data-isinstalment="true" data-stat-id="51d1f1c2f3929a84" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-51d1f1c2f3929a84', '', 'pcpid']);"><input autocomplete="off" name="payOnlineBank" id="antinstal" value="antinstal" type="radio"> <img src="{{asset('homes/pay/payOnline_ant_huabei.png')}}" alt="蚂蚁花呗分期付款	"></li><li class="J_bank fenqi" data-isinstalment="true" data-stat-id="632ea04d66eb9712" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-632ea04d66eb9712', '', 'pcpid']);"><input autocomplete="off" name="payOnlineBank" id="mifinanceinstal" value="mifinanceinstal" type="radio"> <img src="{{asset('homes/pay/mifinanceinstal.png')}}" alt="分期-小米金融	"></li><li class="J_bank fenqi" data-isinstalment="true" data-stat-id="7b800eee8de964e2" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-7b800eee8de964e2', '', 'pcpid']);"><input autocomplete="off" name="payOnlineBank" id="cmbinstal" value="cmbinstal" type="radio"> <img src="{{asset('homes/pay/payOnline_zsyh.png')}}" alt="分期-招商银行	"></li>                        </ul>
                        <div class="tab-container clearfix isinstalment-box">
                                                        <div class="tab-content  clearfix">
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>545.26元 × 3期</h3>
                                        <p>
                                                                                        手续费 12.26元/期，费率2.3%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_3" value="3" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>278.49元 × 6期</h3>
                                        <p>
                                                                                        手续费 11.99元/期，费率4.5%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_6" value="6" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>143.91元 × 12期</h3>
                                        <p>
                                                                                        手续费 10.66元/期，费率8.0%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_12" value="12" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                
                                <div class="isinstalment-desc">
                                    分期付款说明：<br>
                                                                        1、选择蚂蚁花呗分期后，如更改分期数或切换其他支付方式遇到问题，推荐您使用小米钱包进行支付。<br>
                                    2、每期还款金额是根据你的订单估算得出的金额，实际支付数额请以支付宝账单为准，支付宝有权决定是否接受您的分期付款申请。
                                                                    </div>
                            </div>
                                                        <div class="tab-content  clearfix">
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>544.83元 × 3期</h3>
                                        <p>
                                                                                        手续费 11.83元/期，费率2.22%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_3" value="3" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>276.89元 × 6期</h3>
                                        <p>
                                                                                        手续费 10.39元/期，费率3.9%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_6" value="6" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>142.84元 × 12期</h3>
                                        <p>
                                                                                        手续费 9.59元/期，费率7.2%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_12" value="12" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                
                                <div class="isinstalment-desc">
                                    分期付款说明：<br>
                                                                        
每期还款金额是根据你的订单估算得出的金额，实际支付数额请以小米分期账单为准，小米分期有权决定是否接受您的分期付款申请。
                                                                    </div>
                            </div>
                                                        <div class="tab-content  clearfix">
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>552.19元 × 3期</h3>
                                        <p>
                                                                                        手续费 19.19元/期，费率3.6%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_3" value="3" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>279.29元 × 6期</h3>
                                        <p>
                                                                                        手续费 12.79元/期，费率4.8%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_6" value="6" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                                                <div class="isinstalment-item  clearfix" style="height:150px;">
                                    <div class="item-header">
                                        <h3>142.84元 × 12期</h3>
                                        <p>
                                                                                        手续费 9.59元/期，费率7.2%
                                                                                    </p>
                                    </div>
                                    <br>
                                    <div class="item-footer">
                                        <input name="installments" id="installments_cmbinstal_12" value="12" type="radio">
                                        <a href="javascript:void(0);" class="btn J_installmentConfirmBtn" data-stat-id="6cba2eb189242213" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6cba2eb189242213', 'javascript:void(0);', 'pcpid']);">选择该分期方式</a>
                                                                            </div>
                                </div>
                                
                                <div class="isinstalment-desc">
                                    分期付款说明：<br>
                                                                        
每期还款金额是根据你的订单估算得出的金额，实际支付数额请以银行/支付宝账单为准，银行/支付宝有权决定是否接受您的分期付款申请。
                                                                    </div>
                            </div>
                                                    </div>
                        <div class="isinstalment-desc" id="J_isinstalmentPublicDesc">
                        </div>
                    </div>
                </div>
            </div>
                    </form>
    </div>
</div>

<!--现金账户 提示框-->
<div class="modal  modal-hide modal-balance-pay" id="J_balancePay">
    <div class="modal-header">
        <h3>现金账户安全验证</h3>
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
    </div>
    <div class="modal-body">
        <p>
            为了确保您的购物安全<br>
            已向您当前的联系电话 <span class="num" id="J_cashPayPhone"></span>  发送验证码
        </p>
        <div class="form-section">
            <label class="input-label" for="verifycode">请输入验证码</label>
            <input class="input-text" id="verifycode" name="verifycode" type="text">
            <span class="btn btn-block hide" id="J_sendAgain"></span>
        </div>
        <div class="tip" id="J_checkCodeTip"></div>
    </div>
    <div class="modal-footer">
         <a class="btn btn-gray" data-dismiss="modal" href="javascript:void(0);" data-stat-id="c893774534c6180e" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c893774534c6180e', 'javascript:void(0);', 'pcpid']);">取消</a>
         <a class="btn btn-primary" id="J_checkCodeBtn" href="javascript:void(0);" data-stat-id="aed6a311c6be78e4" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-aed6a311c6be78e4', 'javascript:void(0);', 'pcpid']);">确认</a>
    </div>
</div>

<!-- 支付提示框 -->
<div class="modal fade modal-hide modal-pay-tip" id="J_payTip" aria-hidden="false">
    <div class="modal-header">
        <h3>正在支付...</h3>
        <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="9158bc031b335ac2" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-9158bc031b335ac2', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
    </div>
    <div class="modal-body clearfix">
        <div class="success">
            <h4>支付成功了</h4>
            <p><a href="" data-stat-id="dac6a4074eb8191d" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-dac6a4074eb8191d', 'pcpid']);">立即查看订单详情 &gt;</a></p>
        </div>
        <div class="fail">
            <h4>如果支付失败</h4>
            <p><a href="" target="_blank" data-stat-id="32be0169511c71a5" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-32be0169511c71a5','pcpid']);">查看支付常见问题 &gt;</a></p>
        </div>
    </div>
</div>

<div class="modal modal-hide fade modal-alert" id="J_modalAlert">
    <div class="modal-bd">
        <div class="text">
            <h3 id="J_alertMsg"></h3>
        </div>
        <div class="actions">
            <button class="btn btn-primary" data-dismiss="modal">确定</button>
        </div>
        <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="4ed5101f78c9774d" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-4ed5101f78c9774d', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
    </div>
</div>

<div class="modal modal-hide fade modal-alipay" id="J_modalAlipay">
    <div class="modal-bd">
        <div class="loading"><div class="loader"></div></div>
        <iframe name="alipayQrcodeIframe" scrolling="no" width="100%" height="100%" frameborder="0"></iframe>
    </div>
    <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="c556f3fed6708ea5" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c556f3fed6708ea5', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
</div>

<div class="modal modal-hide fade modal-weixin-pay" id="J_modalWeixinPay">
    <div class="modal-hd">
        <span class="title">微信支付</span>
        <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="e96b3129a7dc6807" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-e96b3129a7dc6807', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
    </div>
    <div class="modal-bd" id="J_showWeixinPayExample">
        <div class="code" id="J_weixinPayCode">
            <div class="loading"><div class="loader"></div></div>
        </div>
        <div class="msg">
            请使用 <span>微信</span> 扫一扫<br>二维码完成支付
        </div>
    </div>
    <div class="example" id="J_weixinPayExample"></div>
</div>

<div class="deliver-beta hide" id="J_deliverBeta">
    <p>预计送达时间功能处于测试阶段，若您在下单时已选择“周末送货”或“工作日送货”，则会顺延至您要求的时间，如果发现预计送达时间不准确，期待您的反馈，我们会及时改进。</p>
    <a href="" target="_blank" data-stat-id="395cf7a4d2fb285b" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-395cf7a4d2fb285b','pcpid']);">问题反馈 &gt;</a>

    <i class="arrow arrow-a"></i>
    <i class="arrow arrow-b"></i>
</div>
<div class="site-footer">
    <div class="container">
        <div class="footer-service">
            <ul class="list-service clearfix">
                            <li><a rel="nofollow" href="" target="_blank" data-stat-id="46873828b7b782f4" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-46873828b7b782f4', '//www.mi.com/static/fast/', 'pcpid']);"><i class="iconfont"></i>预约维修服务</a></li>
                            <li><a rel="nofollow" href="" target="_blank" data-stat-id="78babcae8a619e26" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-78babcae8a619e26', '//www.mi.com/service/exchange#back', 'pcpid']);"><i class="iconfont"></i>7天无理由退货</a></li>
                            <li><a rel="nofollow" href="" target="_blank" data-stat-id="d1745f68f8d2dad7" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-d1745f68f8d2dad7', '//www.mi.com/service/exchange#free', 'pcpid']);"><i class="iconfont"></i>15天免费换货</a></li>
                            <li><a rel="nofollow" href="" target="_blank" data-stat-id="f1b5c2451cf73123" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-f1b5c2451cf73123', '//www.mi.com/service/exchange#mail', 'pcpid']);"><i class="iconfont"></i>满150元包邮</a></li>
                            <li><a rel="nofollow" href="" target="_blank" data-stat-id="b57397dd7ad77a31" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-b57397dd7ad77a31', '//www.mi.com/static/maintainlocation/', 'pcpid']);"><i class="iconfont"></i>520余家售后网点</a></li>
                        </ul>
        </div>
        <div class="footer-links clearfix">
            
              <dl class="col-links col-links-first">
                    <dt>友情链接</dt>
                    
                    <dd><a rel="nofollow" href="www.baidu.com" onclick="_msq.push">百度</a></dd>
                    
                    <dd><a rel="nofollow" href="www.taobao.com" onclick="_msq.push">淘宝</a></dd>
                    
                    <dd><a rel="nofollow" href="www.tengxun.com" onclick="_msq.push">腾讯</a></dd>                
                </dl>
                    
            <div class="col-contact">
                <p class="phone">400-100-5678</p>
<p><span class="J_serviceTime-normal" style="
">周一至周日 8:00-18:00</span>
<span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
<a rel="nofollow" class="btn btn-line-primary btn-small" href="" target="_blank" data-stat-id="a7642f0a3475d686" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-a7642f0a3475d686','pcpid']);"><i class="iconfont"></i> 24小时在线客服</a>            </div>
        </div>
    </div>
</div>
<div class="site-info">
    <div class="container">
        <span class="logo ir">小米官网</span>
        <div class="info-text">
            <p>小米旗下网站：<a href="" target="_blank" data-stat-id="b9017a4e9e9eefe3" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-b9017a4e9e9eefe3','pcpid']);">小米商城</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="ed2a0e25c8b0ca2f" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ed2a0e25c8b0ca2f','pcpid']);">MIUI</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="826b32c1478a98d5" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-826b32c1478a98d5','pcpid']);">米聊</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="c9d2af1ad828a834" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c9d2af1ad828a834','pcpid']);">多看书城</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="96f1a8cecc909af2" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-96f1a8cecc909af2','pcpid']);">小米路由器</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="347f6dd0d8d9fda3" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-347f6dd0d8d9fda3','pcpid']);">视频电话</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="4ad42379062eda19" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-4ad42379062eda19','pcpid']);">小米后院</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="dfe0fac59cfb15d9" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-dfe0fac59cfb15d9','pcpid']);">小米天猫店</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="c2613d0d3b77ddff" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c2613d0d3b77ddff','pcpid']);">小米淘宝直营店</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="2f48f953961c637d" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-2f48f953961c637d','pcpid']);">小米网盟</a><span class="sep">|</span><a href="" target="_blank" data-stat-id="6479cd2d041bcf04" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-6479cd2d041bcf04', '//static.mi.com/feedback/', 'pcpid']);">问题反馈</a><span class="sep">|</span><a href="#J_modal-globalSites" data-toggle="modal" target="_blank" data-stat-id="9db137a8e0d5b3dd" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-9db137a8e0d5b3dd', '#J_modal-globalSites', 'pcpid']);">Select Region</a>            </p>
            <p>©<a href="" target="_blank" title="mi.com" data-stat-id="836cacd9ca5b75dd" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-836cacd9ca5b75dd','pcpid']);">mi.com</a> 京ICP证110507号 <a href="" target="_blank" rel="nofollow" data-stat-id="f96685804376361a" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-f96685804376361a','pcpid']);">京ICP备10046444号</a> <a rel="nofollow" href="" target="_blank" data-stat-id="57efc92272d4336b" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-57efc92272d4336b',">京公网安备11010802020134号 </a><a rel="nofollow" href="" target="_blank" data-stat-id="c5f81675b79eb130" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c5f81675b79eb130', '//c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg', 'pcpid']);">京网文[2014]0059-0009号</a>

<br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</p>
        </div>
        <div class="info-links">
                    <a href="" target="_blank" data-stat-id="de920be99941f792" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-de920be99941f792', '//privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn', 'pcpid']);"><img src="{{asset('homes/pay/seal.png')}}" alt="TRUSTe Privacy Certification"></a>
                    <a href="" target="_blank" data-stat-id="d44905018f8d7096" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-d44905018f8d7096', '//search.szfw.org/cert/l/CX20120926001783002010', 'pcpid']);"><img src="{{asset('homes/pay/v-logo-2.png')}}" alt="诚信网站"></a>
                    <a href="" target="_blank" data-stat-id="3e1533699f264eac" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-3e1533699f264eac',"><img src="{{asset('homes/pay/v-logo-1.png')}}" alt="可信网站"></a>
                    <a href="" target="_blank" data-stat-id="b085e50c7ec83104" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-b085e50c7ec83104','pcpid']);"><img src="{{asset('homes/pay/v-logo-3.png')}}" alt="网上交易保障中心"></a>
        
        </div>
    </div>
    <div class="slogan ir">探索黑科技，小米为发烧而生</div>
</div>

<div id="J_modalWeixin" class="modal fade modal-hide modal-weixin" data-width="480" data-height="520">
        <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="cfd3189b8a874ba4" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-cfd3189b8a874ba4', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">小米手机官方微信二维码</span>
        </div>
        <div class="modal-bd">
            <p style="margin: 0 0 10px;">打开微信，点击右上角的“+”，选择“扫一扫”功能，<br>对准下方二维码即可。</p>
            <img alt="" src="{{asset('homes/pay/qr.png')}}" width="375" height="375">
        </div>
    </div>
<!-- .modal-weixin END -->
<div class="modal modal-hide modal-bigtap-queue" id="J_bigtapQueue">
    <div class="modal-body">
        <span class="close" data-dismiss="modal" aria-hidden="true">退出排队</span>
        <div class="con">
            <div class="title">正在排队，请稍候喔！</div>
            <div class="queue-tip-box">
                <p class="queue-tip">当前人数较多，请您耐心等待，排队期间请不要关闭页面。</p>
                <p class="queue-tip">时常来官网看看，最新产品和活动信息都会在这里发布。</p>
                <p class="queue-tip">下载小米商城 App 玩玩吧！产品开售信息抢先知道。</p>
                <p class="queue-tip">发现了让你眼前一亮的小米产品，别忘了分享给朋友！</p>
                <p class="queue-tip">产品开售前会有预售信息，关注官网首页就不会错过。</p>
            </div>
        </div>

        <div class="queue-posters">
            <div class="poster poster-3"></div>
            <div class="poster poster-2"></div>
            <div class="poster poster-1"></div>
            <div class="poster poster-4"></div>
            <div class="poster poster-5"></div>
        </div>
    </div>
</div>
<!-- .xm-dm-queue END -->
<div id="J_bigtapError" class="modal modal-hide modal-bigtap-error">
    <span class="close" data-dismiss="modal" aria-hidden="true"><i class="iconfont"></i></span>
    <div class="modal-body">
        <h3>抱歉，网络拥堵无法连接服务器</h3>
        <p class="error-tip">由于访问人数太多导致服务器压力山大，请您稍后再重试。</p>
        <p>
            <a class="btn btn-primary" id="J_bigtapRetry" data-stat-id="c148a4197491d5bd" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c148a4197491d5bd', '', 'pcpid']);">重试</a>
        </p>
    </div>
</div>


<div id="J_bigtapModeBox" class="modal fade modal-hide modal-bigtap-mode">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body">
            <h3 class="title">为防黄牛，请您输入下面的验证码</h3>
             <p class="desc">在防黄牛的路上，我们一直在努力，也知道做的还不够。<br>
    所以，这次劳烦您多输一次验证码，我们一起防黄牛。</p>
            <div class="mode-loading" id="J_bigtapModeLoading">
                <img src="{{asset('homes/pay/loading.gif')}}" alt="" width="32" height="32">
                <a id="J_bigtapModeReload" class="reload  hide" href="javascript:void(0);" data-stat-id="ce9e5bb5b994ad55" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-ce9e5bb5b994ad55', 'javascript:void(0);', 'pcpid']);">网络错误，点击重新获取验证码！</a>
            </div>
            <div class="mode-action hide" id="J_bigtapModeAction">
                <div class="mode-con" id="J_bigtapModeContent"></div>
                <input name="bigtapmode" class="input-text" id="J_bigtapModeInput" placeholder="请输入正确的验证码" type="text">
                <p class="tip" id="J_bigtapModeTip"></p>
                <a class="btn  btn-gray" id="J_bigtapModeSubmit" data-stat-id="7f083d6abed714f8" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-7f083d6abed714f8', '', 'pcpid']);">确认</a>
            </div>
        </div>
    </div>

<div id="J_bigtapSoldout" class="modal fade modal-hide modal-bigtap-soldout modal-bigtap-soldout-norec">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body ">
            <div class="content clearfix">
                <span class="mitu"></span>
                <p class="title">很抱歉，人真是太多了<br>您晚了一步...</p>
            </div>

            <div class="bigtap-recomment-goods">
                <div class="hd"><span>这些产品也不错，而且有现货哦！</span></div>
                <ul class="clearfix" id="J_bigtapRecommentList"></ul>
            </div>
        </div>
    </div>
<!-- .xm-dm-error END -->
<div id="J_modal-globalSites" class="modal fade modal-hide modal-globalSites" data-width="640">
       <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="d63900908fde14b1" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-d63900908fde14b1', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">Select Region</span>
        </div>
        <div class="modal-bd">
            <h3>Welcome to Mi.com</h3>
            <p class="modal-globalSites-tips">Please select your country or region</p>
            <p class="modal-globalSites-links clearfix">
                <a href="" data-stat-id="51fe807618ae85f4" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-51fe807618ae85f4', '//www.mi.com/index.html', 'pcpid']);">Mainland China</a>
                <a href="" data-stat-id="d8e4264197de1747" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-d8e4264197de1747','pcpid']);">Hong Kong</a>
                <a href="" data-stat-id="8b54359fb6116e28" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-8b54359fb6116e28','pcpid']);">Taiwan</a>
                <a href="" data-stat-id="e9c0506f7e4e7161" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-e9c0506f7e4e7161','pcpid']);">Singapore</a>
                <a href="" data-stat-id="d6299ad30ec761a8" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-d6299ad30ec761a8','pcpid']);">Malaysia</a>
                <a href="" data-stat-id="22b601cf7b3ada84" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-22b601cf7b3ada84','pcpid']);">Philippines</a>
                <a href="" data-stat-id="441d26d4571e10dc" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-441d26d4571e10dc','pcpid']);">India</a>
                <a href="" data-stat-id="88ccf9755c488ec5" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-88ccf9755c488ec5','pcpid']);">Indonesia</a>
                <a href="" data-stat-id="c41d871bf5ddcd95" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-c41d871bf5ddcd95','pcpid']);">Brasil</a>
                <a href="" data-stat-id="4426c5dac474df5f" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-4426c5dac474df5f','pcpid']);">Global Home</a>
                <a href="" data-stat-id="261bb8cf155fb56b" onclick="_msq.push(['trackEvent', '192fa45feb8511c1-261bb8cf155fb56b','pcpid']);"> MENA</a>
            </p>
        </div>
    </div>
<!-- .modal-globalSites END -->

<script src="{{asset('homes/pay/base.js')}}"></script>
<script>
(function() {
    MI.namespace('GLOBAL_CONFIG');
    MI.GLOBAL_CONFIG = {
        orderSite: 'http://order.mi.com',
        wwwSite: '//www.mi.com',
        cartSite: '//cart.mi.com',
        itemSite: '//item.mi.com',
        assetsSite: '//s01.mifile.cn',
        listSite: '//list.mi.com',
        searchSite: '//search.mi.com',
        mySite: '//my.mi.com',
        damiaoSite: 'https://tp.hd.mi.com/',
        damiaoGoodsId:[],
        logoutUrl: 'http://order.mi.com/site/logout',
        staticSite: '//static.mi.com',
        quickLoginUrl: 'https://account.xiaomi.com/pass/static/login.html'
    };
    MI.setLoginInfo.orderUrl = MI.GLOBAL_CONFIG.orderSite + '/user/order';
    MI.setLoginInfo.logoutUrl = MI.GLOBAL_CONFIG.logoutUrl;
    MI.setLoginInfo.init(MI.GLOBAL_CONFIG);
    MI.miniCart.init();
    //MI.updateMiniCart();
})();
</script>

<script type="text/javascript" src="{{asset('homes/pay/payConfirm.js')}}"></script>

<script>
var _msq = _msq || [];
_msq.push(['setDomainId', 100]);
_msq.push(['trackPageView']);
(function() {
    var ms = document.createElement('script');
    ms.type = 'text/javascript';
    ms.async = true;
    ms.src = '//c1.mifile.cn/f/i/15/stat/js/xmst.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(ms, s);
})();
</script>

</body></html>