<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="mstr.js"></script><script type="text/javascript" async="" src="unjcV2.js"></script><script type="text/javascript" async="" src="mstr_002.js"></script><script type="text/javascript" async="" src="jquery.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta charset="UTF-8">
<title>我的订单</title>
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="viewport" content="width=1226">
<link rel="shortcut icon" href="" type="image/x-icon">
<link rel="icon" href="" type="image/x-icon">
<meta http-equiv="Cache-Control" content="no-transform ">
<link rel="stylesheet" href="{{ asset('homes/order/base.css')}}">
<link rel="stylesheet" href="{{ asset('homes/order/main.css')}}">
</head>
<body>
<div class="site-topbar">
    <div class="container">
        <div class="topbar-nav">
            <a rel="nofollow" href="" data-stat-id="6f0a3b95eadabb0b" onclick="_msq.push">小米商城</a>
                <span class="sep">|</span>
            <a rel="nofollow" href="" data-stat-id="984415c52166fcfe" onclick="_msq.push">MIUI</a>
        </div>
        <div class="topbar-cart topbar-cart-filled" id="J_miniCartTrigger">
            <a rel="nofollow" class="cart-mini" id="J_miniCartBtn" href="{{ url('cart')}}" data-stat-id="3e50a79e9c62dfe7" onclick="_msq.push"><i class="iconfont"></i>购物车<span class="cart-mini-num J_cartNum">（4）</span></a>
            <div class="cart-menu" id="J_miniCartMenu" style="display: none;"><div class="loading"><div class="loader"></div></div></div>
        </div>
        @if(session('homeuser') != null)
        
                <div class="topbar-info" id="J_userInfo">
                     <a  rel="nofollow" class="link" href="{{ url('home/myself') }}" data-needlogin="true">{{ session('homeuser')->det_nicheng }}</a><span class="sep">|</span><a  rel="nofollow" class="link" href="{{ url('home/out') }}" >退出</a><span class="sep">|</span><a href="{{ url('home/dingdan') }}">我的订单</a>
                </div>
                @else
                <div class="topbar-info" id="J_userInfo">
                    <a  rel="nofollow" class="link" href="{{ asset('home/login')}}" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="{{ asset('home/zhuce') }}" >注册</a>
                </div>
                @endif
    </div>
</div>
 <div class="breadcrumbs">
    <div class="container">
        <a href="{{ asset('/home') }}">首页</a><span class="sep">&gt;</span><span>订单中心</span>    </div>
</div> 

<div class="page-main user-main">
    <div class="container">
        <div class="row">
            <div class="span4">
                 <div class="uc-box uc-sub-box">
                   <div class="uc-nav-box">
                        <div class="box-hd">
                            <h3 class="title">订单中心</h3>
                        </div>
                        <div class="box-bd">
                            <ul class="uc-nav-list">
                                <li class="active"><a href="{{ url('home/dingdan') }}">我的订单</a></li>                              
                            </ul>
                            <ul class="uc-nav-list">
                                <li><a href="{{ url('home/pj/0') }}">评价晒单</a></li>                              
                            </ul>
                        </div>
                    </div>
                    <div class="uc-nav-box">
                        <div class="box-hd">
                            <h3 class="title">个人中心</h3>
                        </div>
                        <div class="box-bd">
                            <ul class="uc-nav-list">
                                <li><a href="{{ url('home/myself') }}">我的个人中心</a></li>                                
                                 <li><a href="{{ url('home/stor') }}">代金券</a></li>
                                <li><a href="{{url('home/store')}}">我的收藏</a></li>
                                <li><a href="{{url('home/myaddress')}}">收货地址</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="span16">
                <div class="uc-box uc-main-box">
                    <div class="uc-content-box order-list-box">
                        <div class="box-hd">
                            <h1 class="title">我的订单</h1>
                            <div class="more clearfix">
                                <ul class="filter-list J_orderType">
                                    <li><a href="{{ url('home/dingdan')}}" onclick="_msq.push">全部有效订单</a></li>
                                    <li ><a id="J_unpaidTab" href="{{ url('home/dfk')}}"  onclick="_msq.push ">待支付</a></li>
                                    <li class="active"><a id="J_sendTab" href="{{ url('dfh')}}"  onclick="_msq.push ">待发货</a></li>
                                    <li><a href="{{ url('home/dsh')}}" onclick="_msq.push ">待收货</a></li>
                                </ul>

                                <form id="J_orderSearchForm" class="search-form clearfix" action="#" method="get">
                                    <label for="search" class="hide">站内搜索</label>
                                    <input class="search-text" id="J_orderSearchKeywords" name="keywords" autocomplete="off" placeholder="输入商品名称、商品编号、订单号" type="search">
                                    <input class="search-btn iconfont" value="" type="submit">
                                </form>
                            </div>
                        </div>
                        <div class="box-bd">
                        
                            <div id="J_orderList">
                            
                             <p class="empty">
                                <table border="0" width="850" height="100" cellspacing="0" cellpadding="0">
                                    <thead>
                                        <tr style="background-color:#eaf8ff">
                                            <th>下单时间</th>
                                            <th>订单编号</th>
                                            
                                            <th rowspan="">操作</th>
                                        </tr>
                                    </thead>
                                     @foreach($data as $v)
                                    <tbody>     
                                   
                                        <tr>
                                            <td>{{date("Y-m-d H:i:s",$v->dtime)}}</td>
                                            <td>{{$v->ordernumber}}</td>
                                                
                                            <td> 
                                               <!--  <a class="btn" href=""><i class="fa fa-trash-o ">删除该订单</i> </a> -->
                                                <a class="btn" href="{{url('home/order/'.$v->ordernumber.'')}}"><i class="fa fa-trash-o ">查看订单详情</i> </a>
                                            </td>     
                                        </tr>
                                       
                                    </tbody>
                                      @endforeach  
                                </table>
                               
                                </p>
                              
                            </div>
                            <div id="J_orderListPages"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>







<div class="site-footer">
    <div class="container">
        <div class="footer-service">
            <ul class="list-service clearfix">
                <li><a rel="nofollow" href="http://www.mi.com/static/fast/" target="_blank" data-stat-id="46873828b7b782f4" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-46873828b7b782f4', '//www.mi.com/static/fast/', 'pcpid']);"><i class="iconfont"></i>预约维修服务</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/service/exchange#back" target="_blank" data-stat-id="78babcae8a619e26" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-78babcae8a619e26', '//www.mi.com/service/exchange#back', 'pcpid']);"><i class="iconfont"></i>7天无理由退货</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/service/exchange#free" target="_blank" data-stat-id="d1745f68f8d2dad7" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-d1745f68f8d2dad7', '//www.mi.com/service/exchange#free', 'pcpid']);"><i class="iconfont"></i>15天免费换货</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/service/exchange#mail" target="_blank" data-stat-id="2b5586f1346ce37a" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-2b5586f1346ce37a', '//www.mi.com/service/exchange#mail', 'pcpid']);"><i class="iconfont"></i>满99元包邮</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/static/maintainlocation/" target="_blank" data-stat-id="b57397dd7ad77a31" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-b57397dd7ad77a31', '//www.mi.com/static/maintainlocation/', 'pcpid']);"><i class="iconfont"></i>520余家售后网点</a></li>
            </ul>
        </div>
        <div class="footer-links clearfix">
            
            <<dl class="col-links col-links-first">
                <dt>友情链接</dt>
                
                <dd><a rel="nofollow" href="www.baidu.com" onclick="_msq.push">百度</a></dd>
                
                <dd><a rel="nofollow" href="www.taobao.com" onclick="_msq.push">淘宝</a></dd>
                
                <dd><a rel="nofollow" href="www.tengxun.com" onclick="_msq.push">腾讯</a></dd>                
            </dl>
                
            <div class="col-contact">
                <p class="phone">400-100-5678</p>
<p><span class="J_serviceTime-normal" style="
">周一至周日 8:00-18:00</span>
<span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
<a rel="nofollow" class="btn btn-line-primary btn-small" href="http://www.mi.com/service/contact" target="_blank" data-stat-id="a7642f0a3475d686" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-a7642f0a3475d686', '//www.mi.com/service/contact', 'pcpid']);"><i class="iconfont"></i> 24小时在线客服</a>            </div>
        </div>
    </div>
</div>
<div class="site-info">
    <div class="container">
        <div class="logo ir">小米官网</div>
        <div class="info-text">
            <p class="sites">
                <a rel="nofollow" href="http://www.mi.com/index.html" target="_blank" data-stat-id="b9017a4e9e9eefe3" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-b9017a4e9e9eefe3', '//www.mi.com/index.html', 'pcpid']);">小米商城</a>
                    <span class="sep">|</span>
                <a rel="nofollow" href="http://www.miui.com/" target="_blank" data-stat-id="ed2a0e25c8b0ca2f" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-ed2a0e25c8b0ca2f', 'http://www.miui.com/', 'pcpid']);">MIUI</a>
                
            </p>
            <p>?<a href="http://www.mi.com/" target="_blank" title="mi.com" data-stat-id="836cacd9ca5b75dd" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-836cacd9ca5b75dd', '//www.mi.com/', 'pcpid']);">mi.com</a> 京ICP证110507号 <a href="http://www.miitbeian.gov.cn/" target="_blank" rel="nofollow" data-stat-id="f96685804376361a" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-f96685804376361a', 'http://www.miitbeian.gov.cn/', 'pcpid']);">京ICP备10046444号</a> <a rel="nofollow" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134" target="_blank" data-stat-id="57efc92272d4336b" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-57efc92272d4336b', 'http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134', 'pcpid']);">京公网安备11010802020134号 </a><a rel="nofollow" href="http://c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg" target="_blank" data-stat-id="c5f81675b79eb130" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-c5f81675b79eb130', '//c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg', 'pcpid']);">京网文[2014]0059-0009号</a>

<br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</p>
        </div>
        <div class="info-links">
                    <a rel="nofollow" href="http://privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn" target="_blank" data-stat-id="de920be99941f792" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-de920be99941f792', '//privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn', 'pcpid']);"><img rel="nofollow" src="%E6%88%91%E7%9A%84%E8%AE%A2%E5%8D%95-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/seal.png" alt="TRUSTe Privacy Certification"></a>
                    <a rel="nofollow" href="http://search.szfw.org/cert/l/CX20120926001783002010" target="_blank" data-stat-id="d44905018f8d7096" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-d44905018f8d7096', '//search.szfw.org/cert/l/CX20120926001783002010', 'pcpid']);"><img rel="nofollow" src="%E6%88%91%E7%9A%84%E8%AE%A2%E5%8D%95-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/v-logo-2.png" alt="诚信网站"></a>
                    <a rel="nofollow" href="https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082" target="_blank" data-stat-id="3e1533699f264eac" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-3e1533699f264eac', 'https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082', 'pcpid']);"><img rel="nofollow" src="%E6%88%91%E7%9A%84%E8%AE%A2%E5%8D%95-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/v-logo-1.png" alt="可信网站"></a>
                    <a rel="nofollow" href="http://www.315online.com.cn/member/315140007.html" target="_blank" data-stat-id="b085e50c7ec83104" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-b085e50c7ec83104', 'http://www.315online.com.cn/member/315140007.html', 'pcpid']);"><img rel="nofollow" src="%E6%88%91%E7%9A%84%E8%AE%A2%E5%8D%95-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/v-logo-3.png" alt="网上交易保障中心"></a>
                </div>
    </div>
    <div class="slogan ir">探索黑科技，小米为发烧而生</div>
</div>
<div id="J_modalWeixin" class="modal fade modal-hide modal-weixin" data-width="480" data-height="520">
        <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="cfd3189b8a874ba4" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-cfd3189b8a874ba4', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">小米手机官方微信二维码</span>
        </div>
        <div class="modal-bd">
            <p style="margin: 0 0 10px;">打开微信，点击右上角的“+”，选择“扫一扫”功能，<br>对准下方二维码即可。</p>
            <img alt="" src="qr.png" width="375" height="375">
        </div>
    </div>
<!-- .modal-weixin END -->
<div class="modal modal-hide modal-bigtap-queue" id="J_bigtapQueue">
    <div class="modal-body">
        <span class="close" data-dismiss="modal" aria-hidden="true">退出排队</span>
        <div class="con">
            <div class="title">正在排队，请稍候喔！</div>
            <div class="queue-tip-box">
                <p class="queue-tip">当前人数较多，请您耐心等待，排队期间请不要关闭页面。</p>
                <p class="queue-tip">时常来官网看看，最新产品和活动信息都会在这里发布。</p>
                <p class="queue-tip">下载小米商城 App 玩玩吧！产品开售信息抢先知道。</p>
                <p class="queue-tip">发现了让你眼前一亮的小米产品，别忘了分享给朋友！</p>
                <p class="queue-tip">产品开售前会有预售信息，关注官网首页就不会错过。</p>
            </div>
        </div>

        <div class="queue-posters">
            <div class="poster poster-3"></div>
            <div class="poster poster-2"></div>
            <div class="poster poster-1"></div>
            <div class="poster poster-4"></div>
            <div class="poster poster-5"></div>
        </div>
    </div>
</div>
<!-- .xm-dm-queue END -->
<div id="J_bigtapError" class="modal modal-hide modal-bigtap-error">
    <span class="close" data-dismiss="modal" aria-hidden="true"><i class="iconfont"></i></span>
    <div class="modal-body">
        <h3>抱歉，网络拥堵无法连接服务器</h3>
        <p class="error-tip">由于访问人数太多导致服务器压力山大，请您稍后再重试。</p>
        <p>
            <a class="btn btn-primary" id="J_bigtapRetry" data-stat-id="c148a4197491d5bd" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-c148a4197491d5bd', '', 'pcpid']);">重试</a>
        </p>
    </div>
</div>


<div id="J_bigtapModeBox" class="modal fade modal-hide modal-bigtap-mode">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body">
            <h3 class="title">为防黄牛，请您输入下面的验证码</h3>
             <p class="desc">在防黄牛的路上，我们一直在努力，也知道做的还不够。<br>
    所以，这次劳烦您多输一次验证码，我们一起防黄牛。</p>
            <div class="mode-loading" id="J_bigtapModeLoading">
                <img src="loading.gif" alt="" width="32" height="32">
                <a id="J_bigtapModeReload" class="reload  hide" href="javascript:void(0);" data-stat-id="ce9e5bb5b994ad55" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-ce9e5bb5b994ad55', 'javascript:void(0);', 'pcpid']);">网络错误，点击重新获取验证码！</a>
            </div>
            <div class="mode-action hide" id="J_bigtapModeAction">
                <div class="mode-con" id="J_bigtapModeContent"></div>
                <input name="bigtapmode" class="input-text" id="J_bigtapModeInput" placeholder="请输入正确的验证码" type="text">
                <p class="tip" id="J_bigtapModeTip"></p>
                <a class="btn  btn-gray" id="J_bigtapModeSubmit" data-stat-id="7f083d6abed714f8" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-7f083d6abed714f8', '', 'pcpid']);">确认</a>
            </div>
        </div>
    </div>

<div id="J_bigtapSoldout" class="modal fade modal-hide modal-bigtap-soldout modal-bigtap-soldout-norec">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body ">
            <div class="content clearfix">
                <span class="mitu"></span>
                <p class="title">很抱歉，人真是太多了<br>您晚了一步...</p>
            </div>

            <div class="bigtap-recomment-goods">
                <div class="hd"><span>这些产品也不错，而且有现货哦！</span></div>
                <ul class="clearfix" id="J_bigtapRecommentList"></ul>
            </div>
        </div>
    </div>
<!-- .xm-dm-error END -->
<div id="J_modal-globalSites" class="modal fade modal-hide modal-globalSites" data-width="640">
       <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="d63900908fde14b1" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-d63900908fde14b1', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">Select Region</span>
        </div>
        <div class="modal-bd">
            <h3>Welcome to Mi.com</h3>
            <p class="modal-globalSites-tips">Please select your country or region</p>
            <p class="modal-globalSites-links clearfix">
                <a href="http://www.mi.com/index.html" data-stat-id="51fe807618ae85f4" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-51fe807618ae85f4', '//www.mi.com/index.html', 'pcpid']);">Mainland China</a>
                <a href="http://www.mi.com/hk/" data-stat-id="d8e4264197de1747" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-d8e4264197de1747', 'http://www.mi.com/hk/', 'pcpid']);">Hong Kong</a>
                <a href="http://www.mi.com/tw/" data-stat-id="8b54359fb6116e28" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-8b54359fb6116e28', 'http://www.mi.com/tw/', 'pcpid']);">Taiwan</a>
                <a href="http://www.mi.com/sg/" data-stat-id="e9c0506f7e4e7161" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-e9c0506f7e4e7161', 'http://www.mi.com/sg/', 'pcpid']);">Singapore</a>
                <a href="http://www.mi.com/my/" data-stat-id="d6299ad30ec761a8" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-d6299ad30ec761a8', 'http://www.mi.com/my/', 'pcpid']);">Malaysia</a>
                <a href="http://www.mi.com/ph/" data-stat-id="22b601cf7b3ada84" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-22b601cf7b3ada84', 'http://www.mi.com/ph/', 'pcpid']);">Philippines</a>
                <a href="http://www.mi.com/in/" data-stat-id="441d26d4571e10dc" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-441d26d4571e10dc', 'http://www.mi.com/in/', 'pcpid']);">India</a>
                <a href="http://www.mi.com/id/" data-stat-id="88ccf9755c488ec5" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-88ccf9755c488ec5', 'http://www.mi.com/id/', 'pcpid']);">Indonesia</a>
                <a href="http://br.mi.com/" data-stat-id="c41d871bf5ddcd95" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-c41d871bf5ddcd95', 'http://br.mi.com/', 'pcpid']);">Brasil</a>
                <a href="http://www.mi.com/en/" data-stat-id="4426c5dac474df5f" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-4426c5dac474df5f', 'http://www.mi.com/en/', 'pcpid']);">Global Home</a>
                <a href="http://www.mi.com/mena/" data-stat-id="261bb8cf155fb56b" onclick="_msq.push(['trackEvent', '5eab40056fa03ac0-261bb8cf155fb56b', 'http://www.mi.com/mena/', 'pcpid']);"> MENA</a>
            </p>
        </div>
    </div>
<!-- .modal-globalSites END -->
<script src="base.js"></script>
<script>

</script>
<script src="user.js"></script>
<script src="orderList.js"></script>
<script src="xmsg_ti.js"></script>
<script>

</script>
<!--mae_monitor-->

</body>
</html>