<?php $__env->startSection('content'); ?>


<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-indent red"></i><a href="<?php echo e(url('admin/homelist')); ?>">送用户代金券</a></h6>							
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<form action="<?php echo e(url('/admin/storeinsert')); ?>" method="post" class="form-horizontal ">
		<input type='hidden' name='_token' value='<?php echo e(csrf_token()); ?>'>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-small">用户账号：</label>
			<div class="col-sm-6">
				<input type="hidden" name="uid" class="form-control input-sm"  value="<?php echo e($ob ->id); ?>"/>
				<input type="text" id="input-small" class="form-control input-sm"  disabled value="<?php echo e($ob ->name); ?>"/>
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">代金值</label>
			<div class="col-sm-6">
				<input type="radio" id="input-normal" name="val" value="5" /> 5元 <br />
				<input type="radio" id="input-normal" name="val" value="10" /> 10元
			</div>
			</div>
			<div class="form-group">
				<div class="col-sm-6">
				</div>
				<div class="col-sm-2">
					<input type="submit"    value="确认添加" />
				</div>
			</div>
		</form>
	</div>					
</div>
				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>