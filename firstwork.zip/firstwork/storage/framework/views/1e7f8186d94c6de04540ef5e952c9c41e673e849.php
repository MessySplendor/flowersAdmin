<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span><a href="<?php echo e(url('admin/re')); ?>">回收站</a></h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped" id="datatable-default">
					<thead>
						<tr>
							<th>序号</th>
							<th>所属分类</th>
							<th>图片</th>
							<th>操作</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr class="gradeX">
							<td><?php echo e($v->goods_id); ?></td>
							<td><?php echo e($v->goods_name); ?></td>
							<td>
							<div style="border:1px solid red;">
								<center><img src="<?php echo e(asset('/uploads/goods/'.$v->image.'')); ?>" alt="letv.jpg" width="60px" height="60px" /></center>
							</div>
							
							</td>
							<td>
								<div class="bk-margin-5 btn-group">
									<a href="<?php echo e(url('/admin/re/go/'.$v->goods_id.'')); ?>"><input type="submit" class="btn btn-info" value="还原"></a>
									<a href="<?php echo e(url('/admin/re/del/'.$v->goods_id.'')); ?>"><input type="submit" class="btn btn-danger" value="删除"></a>
								</div>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>