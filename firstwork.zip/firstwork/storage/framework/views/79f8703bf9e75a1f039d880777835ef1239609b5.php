<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta charset="UTF-8">
<title>填写订单信息</title>
<meta name="viewport" content="width=1226">
<link rel="shortcut icon" href="http://s01.mifile.cn/favicon.ico" type="image/x-icon">
<link rel="icon" href="http://s01.mifile.cn/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('homes/check/base.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('homes/check/checkout.css')); ?>">
<!-- 引入bootstrap -->
<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap-theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap-theme.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
<script type="text/javascript" async="" src="<?php echo e(asset('bootstrap/js/bootstrap.js')); ?>"></script>
<script type="text/javascript" async="" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" async="" src="<?php echo e(asset('bootstrap/js/npm.js')); ?>"></script>
</head>
<body>
<div class="site-header site-mini-header">
    <div class="container">
        <div class="header-logo">
            <a class="logo " href="http://www.mi.com/index.html" title="小米官网" data-stat-id="ac576a29202325c4" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-ac576a29202325c4', '//www.mi.com/index.html', 'pcpid']);"></a>
        </div>
        <div class="header-title" id="J_miniHeaderTitle"><h2>确认订单</h2></div>
        <?php if(session('homeuser') != null): ?>
        
                <div class="topbar-info" id="J_userInfo">
                     <a  rel="nofollow" class="link" href="<?php echo e(url('home/myself')); ?>" data-needlogin="true"><?php echo e(session('homeuser')->det_nicheng); ?></a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(url('home/out')); ?>" >退出</a><span class="sep">|</span><a href="<?php echo e(url('home/dingdan')); ?>">我的订单</a>
                </div>
                <?php else: ?>
                <div class="topbar-info" id="J_userInfo">
                    <a  rel="nofollow" class="link" href="<?php echo e(asset('home/login')); ?>" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(asset('home/zhuce')); ?>" >注册</a>
                </div>
                <?php endif; ?>
    </div>
</div>
<!-- .site-mini-header END -->
<script type="text/javascript">
var checkoutConfig={
    addressMatch:'common',
    addressMatchVarName: new Function('return ' + 'data'),
    hasPresales:false,
    hasBigTv:false,
    hasAir:false,
    hasScales:false,
    hasWater:false,
    hasWater2:false,
    hasMobile:true,
    hasEboiler:false,
    hasEvent:false,
    hasGiftcard:false,
    totalPrice:2299.00,
    needPayAmount:2299,
    postage:10,//
    postFree:true,
    bcPrice:150,
    activityDiscountMoney:0.00,//活动优惠
    showCouponBox:0,
    showCaptcha:'0',
    invoice:[{"type":"electron","value":4,"desc":"\u4e2a\u4eba\u7535\u5b50\u53d1\u7968","checked":true},{"type":"personal","value":1,"desc":"\u4e2a\u4eba\u7eb8\u8d28\u53d1\u7968","checked":false},{"type":"company","value":2,"desc":"\u5355\u4f4d\u7eb8\u8d28\u53d1\u7968","checked":false}],
    quickOrder: '0',
    hasBigPro: false,
    onlinePayTips: '支持微信支付、支付宝、银联、财付通、小米钱包等',
    subsidyPrice: 0};
</script>
<div style="position:relative;"  class="page-main">
    <div class="container">
        <div class="checkout-box">
            <div class="section section-address">
                <div class="section-header clearfix">
                    <h3 class="title">收货地址</h3>
                    <div class="more">
                    </div>
                </div>
                <div >
                    <!-- addresslist begin -->
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="border" style="width:245px;height:180px;border:1px solid #E0E0E0;color:#757575;float:left;margin-left:15px;margin-top:10px">
                        <dl style="width:140px;float:left;margin-left:20px;margin-top:15px;">
                            <dd>
                                <span style="font-size:18px;color:black;font-weight:bold;"><?php echo e($v->name); ?></span>
                            </dd><br>
                            <dd>
                                <span><?php echo e($v->phone); ?></span>     
                            </dd>
                            <dd>
                                <span><?php echo e($v->address); ?></span>&nbsp;&nbsp;
                                <span><?php echo e($v->address_detail); ?></span>                           
                            </dd>
                            <dd>
                                邮编：<span><?php echo e($v->postcode); ?></span>    
                            </dd>
                        </dl>
                        <div class="actions">
                            <a class="arise" address_id="<?php echo e($v->address_id); ?>" style="float:right;margin-right:10px;margin-top:150px;"></a>
                            <a class="delete" href="" address_id="<?php echo e($v->address_id); ?>" style="float:right;margin-right:10px;margin-top:150px;"></a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <!-- addresslist end -->
                    <div style="text-align:center;width:245px;height:180px;border:1px solid #E0E0E0;float:left;margin-left:15px;margin-top:10px;">
                        <span style="float:left;margin-top:60px;margin-left:90px"><span class="show" style="font-weight:bold;font-size:30px;">+</span><br>添加新地址</span>
                    </div>
                    <script type="text/javascript" src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
                    <script type="text/javascript">
                        $(function(){
                            $('.show').mousedown(function(){
                                $('.address-box:first').css('display','');
                            });


                            $('.border').mousedown(function(){
                                $('.border').css('border','1px solid #E0E0E0');
                                $(this).css('border','1px solid red');
                                $('.arise').text('');
                                $('.delete').text('');
                                $(this).find('a:eq(0)').text('修改');
                                $(this).find('a:eq(1)').text('删除');
                                $('#J_confirmAddress span:first').text($(this).find('span:first').text());
                                $('#J_confirmAddress span:eq(1)').text($(this).find('span:eq(1)').text());
                                $('#J_confirmAddress span:eq(2)').text($(this).find('dd:eq(2)').text());
                                var address_id=$(this).find('a:eq(0)').attr('address_id');
                                $.ajax({
                                url:'<?php echo e(url('/home/defaultadd')); ?>',
                                async:true,               
                                type:'post',                
                                data:{address_id:address_id,_token:'<?php echo e(csrf_token()); ?>'},              
                                dataType:'json', 
                                
                                });
                               
                            });
//-----------------------删除地址--------------------------//            
                            $('.delete').mousedown(function() {
                                $(this).css('color','red');
                                var address_id=$(this).attr('address_id');
                                $.ajax({
                                url:'<?php echo e(url('/home/deleteadd')); ?>',
                                async:true,               
                                type:'post',                
                                data:{address_id:address_id,_token:'<?php echo e(csrf_token()); ?>'},              
                                dataType:'json', 
                                // error:function()            
                                // {
                                //     alert('ajax请求失败');
                                // },
                                success:function(data)      
                                {
                                    if(data){
                                     alert('删除成功');
                                 }
                                }
                                });
                            });
//----------------------------end---------------------------------//
                            var address_id='';
                            $('.arise').mousedown(function(){
                                $(this).css('color','red');
                                $('.set').css('display','');
                                $('.set input:eq(1)').attr('value',$(this).parent().prev().children('dd:first').children('span').text());
                                $('.set input:eq(2)').attr('value',$(this).parent().prev().children('dd:eq(1)').children('span').text());
                                $('.set input:eq(3)').attr('value',$(this).parent().prev().children('dd:eq(2)').children('span:first').text());
                                $('.set textarea').text($(this).parent().prev().children('dd:eq(2)').children('span:eq(1)').text());
                                $('.set input:eq(4)').attr('value',$(this).parent().prev().children('dd:eq(3)').children('span').text());
                                $('.set form').attr('action','<?php echo e(url('home/updateaddress')); ?>'+'/'+$(this).attr('address_id'));
                            });

                            $('#J_cancel').mousedown(function(){
                                $('.address-box:first').css('display','none');
                            });
                            $('#cancel').mousedown(function(){
                                $('.address-box:eq(1)').css('display','none');
                            });
                            //----------- 配送时间-----------------//
                            $('.time').mousedown(function(){
                                $('.time').attr('class',"J_option time");
                                $(this).attr('class','J_option time selected');
                            });
                            //--------------- 发票-----------------//
                             $('.invoice').mousedown(function(){
                                $('.invoice').attr('class',"J_option invoice");
                                $(this).attr('class','J_option invoice selected');
                            });
// ------------------------------------选择地址ajax----------------------
                            $.ajax({
                                url:'<?php echo e(url('/home/check')); ?>',
                                async:true,               
                                type:'post',                
                                data:{upid:0,_token:'<?php echo e(csrf_token()); ?>'},              
                                dataType:'json',            
                                // error:function()            
                                // {
                                //     alert('ajax请求失败');
                                // },
                                success:function(data)      
                                {
                                    //console.log(data);
                                    for (var i = 0; i < data.length; i++) {
                                        $('#cid').append("<option value='"+data[i].id+"'>"+data[i].name+"</option>");
                                    };
                                }
                            });

                            $("select").live("change",function(){
                                //先清除后面的select(清上一次选择的)，再添加新的select
                                $(this).nextAll("select").remove();
                                //因为下面需要用到当前对象，但是是另一个函数体内，不能用$(this)
                                var ob = $(this);
                                //判断选择的是不是默认的请选择
                                if($(this).val() != '--请选择--'){
                                    var upid = $(this).val();
                                    $.ajax({
                                        url:'<?php echo e(url('/home/check')); ?>',
                                        async:true,                
                                        type:'post',               
                                        data:{upid:upid,_token:'<?php echo e(csrf_token()); ?>'},               
                                        dataType:'json',            
                                        // error:function()            
                                        // {
                                        //     alert('ajax请求失败');
                                        // },
                                        success:function(data)      
                                        {
                                            // console.log(data);
                                            //判断是否还有数据返回，就是判断是否有下一级信息，没有下一级信息上一级下拉框后面则不会添加新的下拉框
                                            if(data.length>0){
                                                //新建一个select标签
                                                var select = $("<select name='address[]'><option>--请选择--</option></select>");
                                                //循环给select标签添加上option
                                                for (var i = 0; i < data.length; i++) {
                                                    //alert(i);
                                                    $(select).append("<option value='"+data[i].id+"'>"+data[i].name+"</option>");
                                                    
                                                };
                                                //追加到前一个select后面
                                                ob.after(select);
                                            }
                                        }
                                    });
                                }
                            });
// -------------------------------选择地址ajax  end----------------------//
                        });
                    </script>
                     <style type="text/css">
                        .input-size{
                            width:80%;
                            margin-left:19px;
                            height:30px;
                        }
                        select{
                            width:80%;
                            margin-left:19px;
                            height:30px;
                            margin-top:10px;
                        }
                        
                     </style>
<!-- ------------------选择地址弹框 -------------------->
               
                    <div class="address-box" style="display:none;position:absolute;left:442px;top:20px;background-color:#FFFFFF;text-align:center;border:1px solid #E0E0E0;width:340px;float:left;">
                        <form action="<?php echo e(url('home/address')); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="box-main">
                            <div class="form-section">
                                <input class="input-size J_addressInput" style="margin-top:10px" id="user_name" name="name" placeholder="收货人姓名" type="text">
                            </div>
                            <div class="form-section">
                                <input class="input-size J_addressInput" id="user_phone" name="phone" placeholder="手机号" type="text">
                            </div>
                            <div class="form-section form-select-2 clearfix">
                                <div >
                                    <div>
                                        <select class="input-size" id="cid" style="margin-left:19px;" name="address[]" ><option >--请选择--</option></select>
                                    </div>
                                </div>
                            </div>
                            <div class="address-supp-tip hide" id="J_addressSuppTip">您的收货地址需要补全街道信息</div>
                            <div class="form-section">
                                <textarea style="width:80%;margin-left:19px;" class=" J_addressInput" type="text" id="user_adress" name="address_detail" placeholder="详细地址"></textarea>
                            </div>
                            <div class="form-section">
                                <input class="input-size J_addressInput" id="user_zipcode" placeholder="邮政编码" name="postcode" type="text">
                            </div>
                        </div>
                        <div class="form-confirm clearfix">
                            <button type="submit" class="btn btn-warning">保存</button>
                            <a class="btn btn-gray" id="J_cancel" data-stat-id="51d8900b7a3585e5" >取消</a>
                        </div>
                        </form>
                    </div>
                
<!-- ------------------选择地址弹框 end-------------------->
<!-- ------------------修改地址弹框-------------------->
                    <div class="address-box set" style="display:none;position:absolute;left:442px;top:20px;background-color:#FFFFFF;text-align:center;border:1px solid #E0E0E0;width:340px;float:left;">
                        <form action="" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="box-main">
                            <div class="form-section">
                                <input class="input-size J_addressInput" style="margin-top:10px" name="name" value="" type="text">
                            </div>
                            <div class="form-section">
                                <input class="input-size J_addressInput"  name="phone" value="" type="text">
                            </div>
                            <div class="form-section">
                                <input class="input-size J_addressInput" name="address" value="" type="text">
                            </div>
                            <div class="form-section">
                                <textarea style="width:80%;margin-left:19px;" class=" J_addressInput" type="text" id="user_adress" name="address_detail" value=""></textarea>
                            </div>
                            <div class="form-section">
                                <input class="input-size J_addressInput" id="user_zipcode" value="" name="postcode" type="text">
                            </div>
                        </div>
                        <div class="form-confirm clearfix">
                            <button type="submit" class="btn btn-warning">修改</button>
                            <a class="btn btn-gray" id="cancel" data-stat-id="51d8900b7a3585e5" >取消</a>
                        </div>
                        </form>
                    </div>
<!-- ------------------修改地址弹框 end-------------------->
                </div>
            </div>

            <div class="section section-options section-payment clearfix" style="clear:both">
                <div class="section-header">
                    <h3 class="title">支付方式</h3>
                </div>
                <div class="section-body clearfix">
                    <ul class="J_optionList options "><li data-type="pay" class="J_option selected" data-value="1">在线支付 <span>（支持微信支付、支付宝、银联、财付通、小米钱包等）</span></li></ul>
                </div>
            </div>

            <div class="section section-options section-shipment clearfix">
                <div class="section-header">
                    <h3 class="title">配送方式</h3>
                </div>
                <div class="section-body clearfix">
                    <ul class="clearfix J_optionList options "><li data-type="shipment" class="J_option selected" data-amount="0" data-value="1">快递配送（免运费）</li></ul>

                    <div class="service-self-tip" id="J_serviceSelfTip" style="display: none;"></div>
                </div>
            </div>

            <div class="section section-options section-time clearfix">
                <div class="section-header">
                    <h3 class="title">配送时间</h3>
                </div>
                <div class="section-body clearfix">
                    <ul class="J_optionList options options-list clearfix">
                        <!-- besttime start -->
                        <li data-type="time" class="J_option time" data-value="1">
                            不限送货时间：<span>周一至周日</span>
                        </li>
                        <li data-type="time" class="J_option time" data-value="2">
                            工作日送货：<span>周一至周五</span>                        
                        </li>
                        <li data-type="time" class="J_option time" data-value="3">
                            双休日、假日送货：<span>周六至周日</span>                        
                        </li>
                        <!-- besttime end -->
                    </ul>
                </div>
            </div>
            <div class="section section-options section-invoice clearfix">
                <div class="section-header">
                    <h3 class="title">发票</h3>
                </div>
                <div class="section-body clearfix">
                    <ul class="J_optionList options options-list  J_tabSwitch clearfix">
                        <li data-type="invoice" data-invoice-type="not_invoice" class="J_option invoice">
                            不开发票
                        </li>
                        <li data-type="invoice" data-invoice-type="electron" class="J_option invoice" data-value="4">
                            电子发票（非纸质）
                        </li>
                        <li class="J_option invoice" id="J_paperInvoice">
                            普通发票（纸质）
                        </li>
                    </ul>

                    <div class="tab-container">
                        <div class="tab-content hide" style="display: none;"></div>
                        <div class="tab-content e-invoice-detail">
                            电子发票法律效力、基本用途及使用规定同纸质发票。不随商品寄送。<a href="javascript:void(0);" id="J_showEinvoiceDetail" data-stat-id="b762af4a94c60517" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-b762af4a94c60517', 'javascript:void(0);', 'pcpid']);">什么是电子发票 <i class="icon-qa">?</i></a>
                            <div class="e-invoice-qa hide" id="J_einvoiceDetail">
                                <ul>
                                    <li>感谢您选择电子发票，电子发票是税局认可的有效付款凭证，其法律效力、基本用户及使用规定同纸质发票，可作为用户维权、保修的有效凭据。如需纸质发票可自行下载打印；</li>
                                    <li>您在订单详情的"发票信息"栏可查看、下载您的电子发票。</li>
                                </ul>
                                <a href="http://bbs.xiaomi.cn/thread/index/tid/9385999" target="_blank" data-stat-id="14af91c0b7aa7105" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-14af91c0b7aa7105', 'http://bbs.xiaomi.cn/thread/index/tid/9385999', 'pcpid']);">了解详情&gt;</a>
                            </div>
                        </div>

                        <div class="tab-content hide paper-invoice-detail" style="display: none;">
                            <ul class="J_optionList options options-list J_tabSwitch clearfix">
                                <li data-type="invoice" data-invoice-type="personal" class="J_option" data-value="1">
                                    个人
                                </li>
                                <li data-type="invoice" data-invoice-type="company" class="J_option" data-value="2">
                                    单位
                                </li>
                            </ul>
                            <div class="tab-container">
                                <div class="tab-content paper-invoice-person">
                                    发票抬头：个人<br>
                                    发票内容：购买商品明细
                                </div>
                                <div class="tab-content hide paper-invoice-company">
                                    <div class="form-section">
                                        <label class="input-label" for="invoice_title">请输入发票抬头</label>
                                        <input class="input-text" id="invoice_title" name="invoice_title" type="text">
                                    </div>
                                    <p>发票内容：购买商品明细</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section section-goods">
                <div class="section-header clearfix">
                    <h3 class="title">商品</h3>
                    <div class="more">
                        <a href="<?php echo e(url('cart')); ?>" data-stat-id="e2cb89a0d7ce0e0b" >返回购物车<i class="iconfont"></i></a>
                    </div>
                </div>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="section-body">
                    <ul class="goods-list" id="J_goodsList">
                        <li class="clearfix">
                            <div class="col col-img">
                                <img src="<?php echo e(asset('uploads/goods/'.$v->image.'')); ?>" width="30" height="30">
                            </div>
                            <div class="col col-name">
                                <a href="" target="_blank" data-stat-id="8edd7f567a4e59c1" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-8edd7f567a4e59c1', '//item.mi.com/1163700032.html', 'pcpid']);">
                                        <?php echo e($v->goods_name); ?> <?php echo e($v->car_type); ?> <?php echo e($v->car_color); ?>                                    
                                    </a>
                            </div>
                            <div class="col col-price">
                                <?php echo e($v->car_price); ?> x <?php echo e($v->goods_num); ?>

                            </div>
                            
                            <div class="col col-total">
                                <?php echo e($v->goods_sum); ?>元
                            </div>
                        </li>
                    </ul>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>

            <div class="section section-count clearfix">
                <div class="count-actions">
                    <!-- 优惠券 -->
                    <div class="coupon-trigger" id="J_useCoupon"><i class="iconfont icon-plus"></i>使用代金券</div>
                    <table>
                        <tr>
                            <td>选择&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>截止时间</td>
                            <td>代金券力度(元)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td>状态</td>
                        </tr>
                        <?php $__currentLoopData = $ob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td><input type="checkbox" class="daijin">&nbsp;&nbsp;&nbsp;</td>
                            <td><?php echo e(date("Y-m-d H:m:s",$v->stopti)); ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td class="dainum"><?php echo e($v->val); ?></td>
                            <td><?php echo e(($v->state =='0')?'可用':'已使用'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </table>






                    <div class="coupon-result hide" id="J_couponResult">
                        <i class="iconfont icon-selected"></i>
                        正在使用：<span class="coupon-title" id="J_couponTitle"></span>
                        <a href="javascript:void(0)" id="J_changeConpon" data-stat-id="7b9283c91a59046e" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-7b9283c91a59046e', 'javascript:void(0)', 'pcpid']);">［修改］</a>
                    </div>
                    <div class="coupon-box hide" id="J_couponBox">
                        <ul class="clearfix tab-switch J_tabSwitch">
                            <li>选择优惠券</li>
                            <li>输入优惠券码</li>
                        </ul>
                        <div class="tab-container">
                                                        <div class="tab-content list-content">
                                <p class="coupon-empty">您暂时没有可用的优惠券</p>
                            </div>
                                                        <div class="tab-content code-content hide">
                                <div class="form-section">
                                    <label class="input-label" for="coupon_code">请输入优惠券码</label>
                                    <input class="input-text" id="coupon_code" name="coupon_code" type="text">
                                </div>
                                <div class="coupon-confirm">
                                    <a href="javascript:void(0);" class="btn btn-primary" id="J_useCouponCode" data-stat-id="297cea4ecec77455" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-297cea4ecec77455', 'javascript:void(0);', 'pcpid']);">立即使用</a>
                                    <a href="javascript:void(0);" class="btn btn-gray J_couponCancel" data-stat-id="6d289142415d37bb" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-6d289142415d37bb', 'javascript:void(0);', 'pcpid']);">不使用优惠券</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 购物卡 -->
                    <div class="ecard-trigger" id="J_useEcard" data-type="normal"><i class="iconfont icon-plus"></i>使用小米礼品卡</div>
                    <div class="ecard-result hide" id="J_ecardResult">
                        <i class="iconfont icon-selected"></i> 已使用礼品卡 <span id="J_ecardVal"></span>
                        <a href="javascript:void(0);" id="J_ecardModify" data-stat-id="c9228a660635ac68" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c9228a660635ac68', 'javascript:void(0);', 'pcpid']);">［修改］</a>
                    </div>
                    <!-- 手机换新券 -->
                    <div class="ecard-trigger hide" id="J_useRecycle" data-type="recycle"><i class="iconfont icon-plus"></i>使用手机换新券</div>
                    <div class="ecard-result hide" id="J_recycleResult">
                        <i class="iconfont icon-selected"></i> 已使用手机换新券 <span id="J_recycleVal"></span>
                        <a href="javascript:void(0);" id="J_recycleModify" data-stat-id="c9228a660635ac68" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c9228a660635ac68', 'javascript:void(0);', 'pcpid']);">［修改］</a>
                    </div>

                    <div class="ecard-box hide" id="J_ecardBox">
                        <ul class="clearfix tab-switch J_tabSwitch">
                            <li>已绑定的礼品卡</li>
                            <li>输入礼品卡以绑定</li>
                        </ul>
                        <div class="tab-container">
                            <!-- 选卡 -->
                            <div class="tab-content ecard-list">
                                <div class="empty hide" id="J_ecardEmpty">
                                    <p>没有发现可用的礼品卡！</p>
                                    <a href="javascript:void(0);" class="btn btn-gray J_ecardCancel" data-stat-id="36d079d30c12a56a" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-36d079d30c12a56a', 'javascript:void(0);', 'pcpid']);">取消</a>
                                </div>
                                <div class="hide">
                                    <div id="J_ecardList">
                                    </div>
                                    <div class="ecard-info" id="J_ecardInfo"></div>
                                    <div class="btns">
                                        <a href="javascript:void(0);" class="btn btn-primary" id="J_useSelEcard" data-stat-id="d5fd21d5e57e6840" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-d5fd21d5e57e6840', 'javascript:void(0);', 'pcpid']);">确认以上选择</a>
                                        <a href="javascript:void(0);" class="btn btn-gray J_ecardCancel" data-stat-id="4c1f4b133dd2305c" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-4c1f4b133dd2305c', 'javascript:void(0);', 'pcpid']);">取消 不使用礼品卡</a>
                                    </div>
                                </div>
                            </div>

                            <!-- 绑卡 -->
                            <div class="tab-content ecard-input hide">
                                <div class="form-section">
                                    <span class="input-title">密码：</span>
                                    <!-- <label class="input-label" for="ecard_password">请输入礼品卡密码</label> -->
                                    <input class="input-text input-card" id="ecard_password" name="ecard_password" placeholder="请输入礼品卡密码" type="text">
                                </div>
                                <div class="form-section clearfix">
                                    <span class="input-title">验证码：</span>
                                    <!-- <label class="input-label" for="ecard_captcha">请输入验证码</label> -->
                                    <input class="input-text input-captcha" id="ecard_captcha" placeholder="请输入验证码" name="ecard_captcha" data-authurl="//captcha.hd.mi.com/captcha/auth?answer={answer}&amp;service=order.mi.com&amp;_ov=1" type="text">
                                    <div class="captcha-img">
                                        <img alt="验证码" title="点击更换验证码" id="J_ecardCaptchaImg">
                                    </div>
                                </div>
                                <div class="form-section form-btns">
                                    <button class="btn btn-primary" id="J_bindEcard">绑定礼品卡</button>
                                    <button class="btn btn-gray J_ecardCancel">取消</button>
                                </div>
                            </div>
                        </div>

                        <div class="recycle-box hide" id="J_recycleBox">
                            <div class="ecard-list recycle-list">
                                <div id="J_recycleList"> <div class="table-wrapper"> <ul class="clearfix"> <li class="col-1">选择</li>  <li class="col-2">券号</li>  <li class="col-3">本次使用（元）</li> <li class="col-4">余额（元）</li>  </ul>  <div>  <table> <tbody>  </tbody> </table> </div> </div></div>
                                <div class="ecard-info" id="J_recycleInfo"></div>
                                <div class="btns">
                                    <a href="javascript:void(0);" class="btn btn-primary" id="J_useSelRecycle" data-stat-id="da30e0a9f75cd8d0" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-da30e0a9f75cd8d0', 'javascript:void(0);', 'pcpid']);">确认以上选择</a>
                                    <a href="javascript:void(0);" class="btn btn-gray J_recycleCancel" data-stat-id="eb0b5ff4954390a0" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-eb0b5ff4954390a0', 'javascript:void(0);', 'pcpid']);">取消 不使用换新券</a>
                                </div>
                            </div>
                        </div>

                        <div class="sms-box hide" id="J_ecardSmsBox">
                            <div class="title">已向您绑定的手机<span id="J_ecardMobile">（135****6910）</span>发送验证码 <i class="icon-qa" id="J_ecardQa">?</i></div>
                            <div class="form-section clearfix">
                                <label class="input-label" for="ecard_sms">请输入验证码</label>
                                <input class="input-text input-ecard" id="ecard_sms" name="ecard_sms" type="text">
                                <span id="J_smsCountdown" class="countdown hide"><i></i>秒后重新发送</span>
                                <a href="javascript:void(0);" class="repeat hide" id="J_repeatSms" data-stat-id="14a950bda2abbe33" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-14a950bda2abbe33', 'javascript:void(0);', 'pcpid']);">重新发送</a>
                            </div>
                            <div class="form-section form-btns">
                                <button class="btn btn-primary" id="J_checkEcardSms">确定</button>
                                <button class="btn btn-gray" id="J_cancelEcardSms">取消</button>
                            </div>
                            <div class="qa-detail hide" id="J_ecardQaDetail">
                                为保证您的资金安全，消费时需通过绑定手机的认证。若您绑定的手机号已变更，可前往小米账号中心修改绑定的手机号，如果原来的手机号已无法使用，可通过申诉的方式更换手机号。<a href="https://account.xiaomi.com/pass/auth/security/home" target="_blank" data-stat-id="23e4550b3720dcde" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-23e4550b3720dcde', 'https://account.xiaomi.com/pass/auth/security/home', 'pcpid']);">前往小米账号中心&gt;</a>
                            </div>
                        </div>

                        <div class="loading hide">
                            <div class="loader"></div>
                        </div>
                    </div>

                    <!-- 加价购 -->
                    <div class="raise-buy-box">
                        <ul id="J_raiseBuyList">
                            
                            <!--S 保障计划 产品选择弹框 -->
                                                                                            <li class="J_showBaoxian " data-parent_itemid="2163700022_0_buy" data-goodsid="2160700041" data-itemid="" data-price="199" data-count="1" data-agreementurl="//cart.mi.com/static/insuranceAgreement.php?type=mi5">
                                    <div class="inner">
                                        
                                        <i class="iconfont icon-plus"></i>意外保障服务<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> <?php echo e($v->goods_name); ?> <?php echo e($v->car_type); ?> <?php echo e($v->car_color); ?><br><?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        
                                    </div>
                                        
                                    <div class="add-cart-result">
                                        <a href="javascript:void(0);" class="J_del del" data-stat-id="fc38649045b0a672" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-fc38649045b0a672', 'javascript:void(0);', 'pcpid']);"><i class="iconfont">×</i></a>
                                        <i class="iconfont icon-selected"></i>已选购：<span>意外保障服务 小米手机 小米手机5s Plus 全网通版 4GB内存 灰色 64GB</span>
                                    </div>
                                </li>
                                                                                        <!--E 保障计划 产品选择弹框 -->
                        </ul>
                    </div>
                </div>

                <div class="money-box" id="J_moneyBox">
                    <ul>
                        <li class="clearfix">
                            <label>商品件数：</label>
                            <span class="val"><?php echo e($goods_count); ?>件</span>
                        </li>
                        <li class="clearfix">
                            <label>金额合计：</label>
                            <span class="val"><?php echo e($price_count); ?>元</span>
                        </li>
                        <li class="clearfix">
                            <label>活动优惠：</label>
                            <span class="val">-0元</span>
                        </li>
                        <li class="clearfix">
                            <label>优惠券抵扣：</label>
                            <span class="val"><i id="J_couponVal">-0</i>元</span>
                        </li>
                                                <li class="clearfix">
                            <label>运费：</label>
                            <span class="val"><i data-id="J_postageVal">0</i>元</span>
                        </li>
                        <li class="clearfix total-price">
                            <label>应付总额：</label>
                            <span class="val zonge"><em data-id="J_totalPrice"><?php echo e($price_count); ?></em>元</span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="section-bar clearfix">
                <div style="float:left;">
                    <?php if($address): ?>
                    <div class="seleced-address" id="J_confirmAddress"><span><?php echo e($address->name); ?></span> <span><?php echo e($address->phone); ?></span><br><span><?php echo e($address->address); ?> <?php echo e($address->address_detail); ?></span></div>
                    <?php endif; ?>
                </div>
                <div  style="float:right;">
                    <a  href="<?php echo e(url('home/pay/'.$id.'')); ?>" class="btn btn-primary" id="J_checkoutToPay" data-stat-id="4773f7ffc10003b8" >去结算</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 大家点缺货提示 -->
<div class="big-pro-tip-pop hide" id="J_popBigProTip"></div>

<!-- 禮品卡提示 S-->
<div class="modal fade modal-hide modal-lipin" id="J_lipinTip">
    <div class="modal-header">
        <h3 class="title">温馨提示</h3>
    </div>
    <div class="modal-body">
        <p>
            为保障您的利益与安全，下单后礼品卡将会被使用，<br>
            且订单信息将不可修改。请确认收货信息：
        </p>
        <ul>
            <li class="clearfix">
                <strong>收&nbsp;&nbsp;货&nbsp;&nbsp;人：</strong>
                <span id="J_lipinUserName"></span>
            </li>
            <li class="clearfix">
                <strong>联系电话：</strong>
                <span id="J_lipinUserPhone"></span>
            </li>
            <li class="clearfix">
                <strong>收货地址：</strong>
                <span id="J_lipinUserAddress"></span>
            </li>
        </ul>
    </div>
    <div class="modal-footer">
        <a href="javascript:void(0);" class="btn btn-primary" id="J_lipinSubmit" data-stat-id="8e19401adef46ba2" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-8e19401adef46ba2', 'javascript:void(0);', 'pcpid']);">确认下单</a>
        <a href="javascript:void(0);" class="btn btn-gray" data-dismiss="modal" data-stat-id="28800888dda4eee0" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-28800888dda4eee0', 'javascript:void(0);', 'pcpid']);">返回修改</a>
    </div>
</div>
<!--  禮品卡提示 E-->

<!-- 预售提示 S-->
<div class="modal fade modal-hide modal-yushou" id="J_yushouTip">
    <div class="modal-header">
        <h3 class="title">请确认收货地址及发货时间</h3>
    </div>
    <div class="modal-body">
        <ul class="content">
            <li>
                <h3>请确认配送地址，提交后不可变更：</h3>
                <p id="J_yushouAddress"> </p>
                <span class="icon icon-1"></span>
            </li>
            <li>
                <h3>支付后发货</h3>
                <p>如您随预售商品一起购买的商品，将与预售商品一起发货</p>
                <span class="icon icon-2"></span>
            </li>
            <li>
                <h3>以支付价格为准</h3>
                <p>如预售产品发生调价，已支付订单价格将不受影响。</p>
                <span class="icon icon-3"></span>
            </li>
        </ul>
    </div>
    <div class="modal-footer">
        <a href="javascript:void(0);" class="btn btn-gray" data-dismiss="modal" data-stat-id="adbbe3abff3f506a" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-adbbe3abff3f506a', 'javascript:void(0);', 'pcpid']);">返回修改地址</a>
        <a href="javascript:void(0);" class="btn btn-primary" id="J_yushouSubmit" data-stat-id="49b440ef95b2b913" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-49b440ef95b2b913', 'javascript:void(0);', 'pcpid']);">确认并继续下单</a>
    </div>
</div>
<!--  预售提示 E-->

<div class="modal fade modal-hide modal-edit-address" id="J_modalEditAddress" style="top: 220px; left: 325px; display: none;" aria-hidden="true">
    <div class="modal-body">
        <iframe allowfullscreen="" width="100%" height="100%" frameborder="0"></iframe>
    </div>
</div>

<div class="modal fade modal-hide fade modal-alert" id="J_modalAlert">
    <div class="modal-bd">
        <div class="text">
            <h3 id="J_alertMsg"></h3>
        </div>
        <div class="actions">
            <button class="btn btn-primary" data-dismiss="modal">确定</button>
        </div>
        <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="b718c74de11bb9a0" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-b718c74de11bb9a0', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
    </div>
</div>

<div class="address-top-bar" id="J_addressTopBar">
    <div class="container">
        <a href="javascript:void(0);" class="btn btn-primary" id="J_addressTopBarBtn" data-stat-id="0263b2497800ada5" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-0263b2497800ada5', 'javascript:void(0);', 'pcpid']);">选择该收货地址</a>
        <div class="content" id="J_addressTopCon">
            <span class="uname">名字</span><span class="utel">名字</span>
        </div>
    </div>
</div>


<div class="modal modal-warning modal-hide" id="warning-bargain-1463">
    <div class="modal-hd">
        <h2 class="title">温馨提示</h2>
        <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="bdb508f1f15790d3" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-bdb508f1f15790d3', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
    </div>
    <div class="modal-bd">
        <p>
            <b>换卡说明：</b>
            <br><br>移动2G / 3G卡升级为移动4G卡
            <br>传统SIM大卡换小米手机适配的micro卡
        </p>
    </div>
</div>

<div class="modal modal-warning modal-hide" id="warning-bargain-1464">
    <div class="modal-hd">
        <h2 class="title">温馨提示</h2>
        <a class="close" data-dismiss="modal" href="javascript:%20void(0);" data-stat-id="bdb508f1f15790d3" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-bdb508f1f15790d3', 'javascript:void(0);', 'pcpid']);"><i class="iconfont"></i></a>
    </div>
    <div class="modal-bd">
        <p>
            <b>换卡说明：</b>
            <br><br>移动2G / 3G卡升级为移动4G卡
            <br>传统SIM大卡换小米手机适配的nano卡
        </p>
    </div>
</div>

<!-- 保险弹窗 -->
<!-- 保险弹窗 -->

<div class="modal in hide modal-baoxian" id="J_baoxian">
    <div class="modal-header">
        <h3>小米意外保障服务/小米意外损坏保险</h3>
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
    </div>
    <div class="modal-body">
        <div class="con-1">
            <h4>购买保障服务/保险的设备在意外受损时可获得免费维修或换新</h4>
            <ul class="icon-list clearfix">
                <li>
                    <span class="icon icon-1"></span>
                    屏幕碎裂免费换新屏
                </li>
                <li>
                    <span class="icon icon-2"></span>
                    进水、摔落免费修
                </li>
                <li>
                    <span class="icon icon-3"></span>
                    修好为止
                </li>
            </ul>
            <dl class="xuzhi">
                <dt>为保障您的权益，购买前请仔细阅读：</dt>
                <dd>· 本保障服务/保险目前仅适用于有限的产品类型，不同产品的保障规则会有所差异，请以详细条款为准；</dd>
                <dd>· 本保障服务/保险自您收到设备起，有效期为一年，若您在收到设备7日内取消保障服务/保险，请连同设备一起申请退货。</dd>
                <dd>· 故意行为导致的设备损坏以及盗窃、抢劫、遗失设备等不在服务保障范围内（具体以详细条款为准）。<br>
                    <a href="http://www.mi.com/service/safe" target="_blank" class="J_baoxianMore" data-stat-id="13d65618f9fdb846" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-13d65618f9fdb846', 'http://www.mi.com/service/safe', 'pcpid']);">阅读详细条款&gt;</a>
                </dd>
            </dl>
        </div>
    </div>
    <div class="modal-footer clearfix">
        <p>
            <span class="J_baoxianAgree"><i class="iconfont icon-checkbox">√</i> 我已经阅读并同意</span>《<a href="http://www.mi.com/service/safe" target="_blank" class="J_baoxianMore" data-stat-id="7013efcb9afc718b" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-7013efcb9afc718b', 'http://www.mi.com/service/safe', 'pcpid']);">详细条款</a>》
        </p>
        <a class="btn btn-primary J_buyBaoxian" data-stat-id="ee4f02aededb8e5a" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-ee4f02aededb8e5a', '', 'pcpid']);"><span class="num"></span>确认并购买</a>
        <a class="btn btn-gray" data-dismiss="modal" aria-hidden="true" data-stat-id="821a98207fa653c1" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-821a98207fa653c1', '', 'pcpid']);">取消</a>
    </div>
</div>



<div class="site-footer">
    <div class="container">
        <div class="footer-service">
            <ul class="list-service clearfix">
                <li><a rel="nofollow" href="http://www.mi.com/static/fast/" target="_blank" data-stat-id="46873828b7b782f4" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-46873828b7b782f4', '//www.mi.com/static/fast/', 'pcpid']);"><i class="iconfont"></i>预约维修服务</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/service/exchange#back" target="_blank" data-stat-id="78babcae8a619e26" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-78babcae8a619e26', '//www.mi.com/service/exchange#back', 'pcpid']);"><i class="iconfont"></i>7天无理由退货</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/service/exchange#free" target="_blank" data-stat-id="d1745f68f8d2dad7" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-d1745f68f8d2dad7', '//www.mi.com/service/exchange#free', 'pcpid']);"><i class="iconfont"></i>15天免费换货</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/service/exchange#mail" target="_blank" data-stat-id="f1b5c2451cf73123" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-f1b5c2451cf73123', '//www.mi.com/service/exchange#mail', 'pcpid']);"><i class="iconfont"></i>满150元包邮</a></li>
                <li><a rel="nofollow" href="http://www.mi.com/static/maintainlocation/" target="_blank" data-stat-id="b57397dd7ad77a31" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-b57397dd7ad77a31', '//www.mi.com/static/maintainlocation/', 'pcpid']);"><i class="iconfont"></i>520余家售后网点</a></li>
            </ul>
        </div>
        <div class="footer-links clearfix">

            <dl class="col-links col-links-first">
                <dt>友情链接</dt>
                
                <dd><a rel="nofollow" href="www.baidu.com" onclick="_msq.push">百度</a></dd>
                
                <dd><a rel="nofollow" href="www.taobao.com" onclick="_msq.push">淘宝</a></dd>
                
                <dd><a rel="nofollow" href="www.tengxun.com" onclick="_msq.push">腾讯</a></dd>                
            </dl>
                
            <div class="col-contact">
                <p class="phone">400-100-5678</p>
                <p><span class="J_serviceTime-normal" style="">周一至周日 8:00-18:00</span>
                <span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
                <a rel="nofollow" class="btn btn-line-primary btn-small" href="http://www.mi.com/service/contact" target="_blank" data-stat-id="a7642f0a3475d686" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-a7642f0a3475d686', '//www.mi.com/service/contact', 'pcpid']);"><i class="iconfont"></i> 24小时在线客服</a>            </div>
            </div>
    </div>
</div>
<div class="site-info">
    <div class="container">
        <span class="logo ir">小米官网</span>
        <div class="info-text">
            <p>小米旗下网站：<a href="http://www.mi.com/index.html" target="_blank" data-stat-id="b9017a4e9e9eefe3" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-b9017a4e9e9eefe3', '//www.mi.com/index.html', 'pcpid']);">小米商城</a><span class="sep">|</span><a href="http://www.miui.com/" target="_blank" data-stat-id="ed2a0e25c8b0ca2f" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-ed2a0e25c8b0ca2f', 'http://www.miui.com/', 'pcpid']);">MIUI</a><span class="sep">|</span><a href="http://www.miliao.com/" target="_blank" data-stat-id="826b32c1478a98d5" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-826b32c1478a98d5', 'http://www.miliao.com/', 'pcpid']);">米聊</a><span class="sep">|</span><a href="http://www.duokan.com/" target="_blank" data-stat-id="c9d2af1ad828a834" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c9d2af1ad828a834', 'http://www.duokan.com/', 'pcpid']);">多看书城</a><span class="sep">|</span><a href="http://www.miwifi.com/" target="_blank" data-stat-id="96f1a8cecc909af2" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-96f1a8cecc909af2', 'http://www.miwifi.com/', 'pcpid']);">小米路由器</a><span class="sep">|</span><a href="http://call.mi.com/" target="_blank" data-stat-id="347f6dd0d8d9fda3" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-347f6dd0d8d9fda3', 'http://call.mi.com/', 'pcpid']);">视频电话</a><span class="sep">|</span><a href="http://blog.xiaomi.com/" target="_blank" data-stat-id="4ad42379062eda19" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-4ad42379062eda19', 'http://blog.xiaomi.com/', 'pcpid']);">小米后院</a><span class="sep">|</span><a href="http://xiaomi.tmall.com/" target="_blank" data-stat-id="dfe0fac59cfb15d9" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-dfe0fac59cfb15d9', 'http://xiaomi.tmall.com/', 'pcpid']);">小米天猫店</a><span class="sep">|</span><a href="http://shop115048570.taobao.com/" target="_blank" data-stat-id="c2613d0d3b77ddff" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c2613d0d3b77ddff', 'http://shop115048570.taobao.com', 'pcpid']);">小米淘宝直营店</a><span class="sep">|</span><a href="http://union.mi.com/" target="_blank" data-stat-id="2f48f953961c637d" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-2f48f953961c637d', 'http://union.mi.com/', 'pcpid']);">小米网盟</a><span class="sep">|</span><a href="http://static.mi.com/feedback/" target="_blank" data-stat-id="6479cd2d041bcf04" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-6479cd2d041bcf04', '//static.mi.com/feedback/', 'pcpid']);">问题反馈</a><span class="sep">|</span><a href="#J_modal-globalSites" data-toggle="modal" target="_blank" data-stat-id="9db137a8e0d5b3dd" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-9db137a8e0d5b3dd', '#J_modal-globalSites', 'pcpid']);">Select Region</a>            </p>
            <p>©<a href="http://www.mi.com/" target="_blank" title="mi.com" data-stat-id="836cacd9ca5b75dd" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-836cacd9ca5b75dd', '//www.mi.com/', 'pcpid']);">mi.com</a> 京ICP证110507号 <a href="http://www.miitbeian.gov.cn/" target="_blank" rel="nofollow" data-stat-id="f96685804376361a" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-f96685804376361a', 'http://www.miitbeian.gov.cn/', 'pcpid']);">京ICP备10046444号</a> <a rel="nofollow" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134" target="_blank" data-stat-id="57efc92272d4336b" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-57efc92272d4336b', 'http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134', 'pcpid']);">京公网安备11010802020134号 </a><a rel="nofollow" href="http://c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg" target="_blank" data-stat-id="c5f81675b79eb130" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c5f81675b79eb130', '//c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg', 'pcpid']);">京网文[2014]0059-0009号</a>
            <br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</p>
        </div>
        <div class="info-links">
            <a href="http://privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn" target="_blank" data-stat-id="de920be99941f792" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-de920be99941f792', '//privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn', 'pcpid']);"><img src="%E5%A1%AB%E5%86%99%E8%AE%A2%E5%8D%95%E4%BF%A1%E6%81%AF_files/seal.png" alt="TRUSTe Privacy Certification"></a>
            <a href="http://search.szfw.org/cert/l/CX20120926001783002010" target="_blank" data-stat-id="d44905018f8d7096" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-d44905018f8d7096', '//search.szfw.org/cert/l/CX20120926001783002010', 'pcpid']);"><img src="%E5%A1%AB%E5%86%99%E8%AE%A2%E5%8D%95%E4%BF%A1%E6%81%AF_files/v-logo-2.png" alt="诚信网站"></a>
            <a href="https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082" target="_blank" data-stat-id="3e1533699f264eac" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-3e1533699f264eac', 'https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082', 'pcpid']);"><img src="%E5%A1%AB%E5%86%99%E8%AE%A2%E5%8D%95%E4%BF%A1%E6%81%AF_files/v-logo-1.png" alt="可信网站"></a>
            <a href="http://www.315online.com.cn/member/315140007.html" target="_blank" data-stat-id="b085e50c7ec83104" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-b085e50c7ec83104', 'http://www.315online.com.cn/member/315140007.html', 'pcpid']);"><img src="%E5%A1%AB%E5%86%99%E8%AE%A2%E5%8D%95%E4%BF%A1%E6%81%AF_files/v-logo-3.png" alt="网上交易保障中心"></a>       
        </div>
    </div>
    <div class="slogan ir">探索黑科技，小米为发烧而生</div>
</div>

    <div id="J_modalWeixin" class="modal fade modal-hide modal-weixin" data-width="480" data-height="520">
        <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="cfd3189b8a874ba4" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-cfd3189b8a874ba4', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">小米手机官方微信二维码</span>
        </div>
        <div class="modal-bd">
            <p style="margin: 0 0 10px;">打开微信，点击右上角的“+”，选择“扫一扫”功能，<br>对准下方二维码即可。</p>
            <img alt="" src="%E5%A1%AB%E5%86%99%E8%AE%A2%E5%8D%95%E4%BF%A1%E6%81%AF_files/qr.png" width="375" height="375">
        </div>
    </div>
<!-- .modal-weixin END -->
<div class="modal modal-hide modal-bigtap-queue" id="J_bigtapQueue">
    <div class="modal-body">
        <span class="close" data-dismiss="modal" aria-hidden="true">退出排队</span>
        <div class="con">
            <div class="title">正在排队，请稍候喔！</div>
            <div class="queue-tip-box">
                <p class="queue-tip">当前人数较多，请您耐心等待，排队期间请不要关闭页面。</p>
                <p class="queue-tip">时常来官网看看，最新产品和活动信息都会在这里发布。</p>
                <p class="queue-tip">下载小米商城 App 玩玩吧！产品开售信息抢先知道。</p>
                <p class="queue-tip">发现了让你眼前一亮的小米产品，别忘了分享给朋友！</p>
                <p class="queue-tip">产品开售前会有预售信息，关注官网首页就不会错过。</p>
            </div>
        </div>

        <div class="queue-posters">
            <div class="poster poster-3"></div>
            <div class="poster poster-2"></div>
            <div class="poster poster-1"></div>
            <div class="poster poster-4"></div>
            <div class="poster poster-5"></div>
        </div>
    </div>
</div>
<!-- .xm-dm-queue END -->
<div id="J_bigtapError" class="modal modal-hide modal-bigtap-error">
    <span class="close" data-dismiss="modal" aria-hidden="true"><i class="iconfont"></i></span>
    <div class="modal-body">
        <h3>抱歉，网络拥堵无法连接服务器</h3>
        <p class="error-tip">由于访问人数太多导致服务器压力山大，请您稍后再重试。</p>
        <p>
            <a class="btn btn-primary" id="J_bigtapRetry" data-stat-id="c148a4197491d5bd" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c148a4197491d5bd', '', 'pcpid']);">重试</a>
        </p>
    </div>
</div>


<div id="J_bigtapModeBox" class="modal fade modal-hide modal-bigtap-mode">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body">
            <h3 class="title">为防黄牛，请您输入下面的验证码</h3>
             <p class="desc">在防黄牛的路上，我们一直在努力，也知道做的还不够。<br>
    所以，这次劳烦您多输一次验证码，我们一起防黄牛。</p>
            <div class="mode-loading" id="J_bigtapModeLoading">
                <img src="%E5%A1%AB%E5%86%99%E8%AE%A2%E5%8D%95%E4%BF%A1%E6%81%AF_files/loading.gif" alt="" width="32" height="32">
                <a id="J_bigtapModeReload" class="reload  hide" href="javascript:void(0);" data-stat-id="ce9e5bb5b994ad55" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-ce9e5bb5b994ad55', 'javascript:void(0);', 'pcpid']);">网络错误，点击重新获取验证码！</a>
            </div>
            <div class="mode-action hide" id="J_bigtapModeAction">
                <div class="mode-con" id="J_bigtapModeContent"></div>
                <input name="bigtapmode" class="input-text" id="J_bigtapModeInput" placeholder="请输入正确的验证码" type="text">
                <p class="tip" id="J_bigtapModeTip"></p>
                <a class="btn  btn-gray" id="J_bigtapModeSubmit" data-stat-id="7f083d6abed714f8" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-7f083d6abed714f8', '', 'pcpid']);">确认</a>
            </div>
        </div>
    </div>

<div id="J_bigtapSoldout" class="modal fade modal-hide modal-bigtap-soldout modal-bigtap-soldout-norec">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body ">
            <div class="content clearfix">
                <span class="mitu"></span>
                <p class="title">很抱歉，人真是太多了<br>您晚了一步...</p>
            </div>

            <div class="bigtap-recomment-goods">
                <div class="hd"><span>这些产品也不错，而且有现货哦！</span></div>
                <ul class="clearfix" id="J_bigtapRecommentList"></ul>
            </div>
        </div>
    </div>
<!-- .xm-dm-error END -->
<div id="J_modal-globalSites" class="modal fade modal-hide modal-globalSites" data-width="640">
       <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="d63900908fde14b1" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-d63900908fde14b1', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">Select Region</span>
        </div>
        <div class="modal-bd">
            <h3>Welcome to Mi.com</h3>
            <p class="modal-globalSites-tips">Please select your country or region</p>
            <p class="modal-globalSites-links clearfix">
                <a href="http://www.mi.com/index.html" data-stat-id="51fe807618ae85f4" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-51fe807618ae85f4', '//www.mi.com/index.html', 'pcpid']);">Mainland China</a>
                <a href="http://www.mi.com/hk/" data-stat-id="d8e4264197de1747" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-d8e4264197de1747', 'http://www.mi.com/hk/', 'pcpid']);">Hong Kong</a>
                <a href="http://www.mi.com/tw/" data-stat-id="8b54359fb6116e28" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-8b54359fb6116e28', 'http://www.mi.com/tw/', 'pcpid']);">Taiwan</a>
                <a href="http://www.mi.com/sg/" data-stat-id="e9c0506f7e4e7161" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-e9c0506f7e4e7161', 'http://www.mi.com/sg/', 'pcpid']);">Singapore</a>
                <a href="http://www.mi.com/my/" data-stat-id="d6299ad30ec761a8" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-d6299ad30ec761a8', 'http://www.mi.com/my/', 'pcpid']);">Malaysia</a>
                <a href="http://www.mi.com/ph/" data-stat-id="22b601cf7b3ada84" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-22b601cf7b3ada84', 'http://www.mi.com/ph/', 'pcpid']);">Philippines</a>
                <a href="http://www.mi.com/in/" data-stat-id="441d26d4571e10dc" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-441d26d4571e10dc', 'http://www.mi.com/in/', 'pcpid']);">India</a>
                <a href="http://www.mi.com/id/" data-stat-id="88ccf9755c488ec5" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-88ccf9755c488ec5', 'http://www.mi.com/id/', 'pcpid']);">Indonesia</a>
                <a href="http://br.mi.com/" data-stat-id="c41d871bf5ddcd95" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-c41d871bf5ddcd95', 'http://br.mi.com/', 'pcpid']);">Brasil</a>
                <a href="http://www.mi.com/en/" data-stat-id="4426c5dac474df5f" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-4426c5dac474df5f', 'http://www.mi.com/en/', 'pcpid']);">Global Home</a>
                <a href="http://www.mi.com/mena/" data-stat-id="261bb8cf155fb56b" onclick="_msq.push(['trackEvent', '50d1f382fadafb8b-261bb8cf155fb56b', 'http://www.mi.com/mena/', 'pcpid']);"> MENA</a>
            </p>
        </div>
    </div>
<!-- .modal-globalSites END -->
</body></html>


<script>
    $(".daijin").click(function(){
        var num = $(".dainum").html();
    })
</script>