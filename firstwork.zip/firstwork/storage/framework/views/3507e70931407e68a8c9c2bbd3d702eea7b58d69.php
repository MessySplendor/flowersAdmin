<?php $__env->startSection('content'); ?>

<div class="span16">
	<div class="uc-box uc-main-box">
		<div class="uc-content-box coupon-box">
			<div class="box-hd">
				<h1 class="title">优惠券</h1>
				<div class="more clearfix">
					<br>

				</div>
			</div>
			<div class="box-bd">
				
				<div id="J_couponContainer" class="tab-container">
				<br>
					<table style="border:1px solid #b0b0b0;" width="800" height="50">
						<tr style="background-color:#eaf8ff;">
							<th>面值</th>
							<th>获得时间</th>
							<th>到期时间</th>
							<th>是否使用</th>
						</tr>
						<?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
							<td><?php echo e($v->val); ?>元</td>
							<td><?php echo e(date('Y-m-d H:i:s',$v->stopti)); ?></td>
							<td><?php echo e(date('Y-m-d H:i:s', $v->startti)); ?></td>
							<td>
								<?php if($v->state==0): ?>
									未使用
								<?php elseif($v->orderstatu==1): ?>
									已使用
								<?php elseif($v->orderstatu==2): ?>
									已过期
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.myslef.myself', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>