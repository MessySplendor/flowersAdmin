<?php $__env->startSection('content'); ?>
<div class="span16"> 
    <div class="uc-box uc-main-box">
        <div class="uc-content-box portal-content-box">
            <div class="box-bd">
                <div class="portal-main clearfix">
                    <div class="user-card">
                        <h2 class="username"><?php echo e(session("homeuser")->det_nicheng); ?></h2>
                        <p class="tip"></p>
                        <a class="link" href="/home/myself/<?php echo e(session('homeuser')->det_id); ?>/edit">修改个人信息 &gt;</a>
                         <img class="avatar" src="/uploads/hphoto/<?php echo e(empty(session('hphoto'))?session("homeuser")->det_photo:session('hphoto')); ?>" alt="" width="150" height="150">
                    </div>
                    <div class="user-actions">
                        <ul class="action-list">
                           <li>绑定手机：<span class="tel"><?php echo e(session("homeuser")->det_phone); ?></span></li>
                            <li>绑定邮箱：<span class="tel"><?php echo e(session("homeuser")->det_email); ?></span>
                        </ul>
                    </div>
                    </div>
                    <div class="portal-sub">
                        <ul class="info-list clearfix">
                            <li>
                                <h3>待支付的订单</h3>
                                <a href="<?php echo e(url('home/dfk')); ?>" data-stat-id="dd6496f77a167a5d" onclick="_msq.push">查看待支付订单<i class="iconfont"></i></a>
                                <img src="<?php echo e(asset('homes/Images/portal-icon-1.png')); ?>" alt="">
                            </li>
                            <li>
                                <h3>待收货的订单</h3>
                                <a href="<?php echo e(url('home/dsh')); ?>" onclick="_msq.push">查看待收货订单<i class="iconfont"></i></a>
                                <img src="<?php echo e(asset('homes/Images/portal-icon-2.png')); ?>" alt="">
                            </li>
                            <li>
                                <h3>待评价的订单</h3>
                                <a href="<?php echo e(url('home/pj/0')); ?>" onclick="_msq.push">查看待评价商品<i class="iconfont"></i></a>
                                <img src="<?php echo e(asset('homes/Images/portal-icon-3.png')); ?>" alt="">
                            </li>
                            <!-- <li>
                                <h3>喜欢的商品：<span class="num">0</span></h3>
                                <a href="http://order.mi.com/user/favorite?r=39318.1482406634" data-stat-id="e7f60a4653081c02" onclick="_msq.push(['trackEvent', '45a270e10b1f8e93-e7f60a4653081c02', 'http://order.mi.com/user/favorite', 'pcpid']);">查看喜欢的商品<i class="iconfont"></i></a>
                                <img src="<?php echo e(asset('homes/Images/portal-icon-4.png')); ?>" alt="">
                            </li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.myslef.myself', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>