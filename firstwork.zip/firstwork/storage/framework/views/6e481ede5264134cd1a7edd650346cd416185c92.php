<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-lg ">
	<form id="form" action="<?php echo e(url('admin/link')); ?>" class="form-horizontal" method="post">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6><i class="fa  fa-check-circle-o bk-fg-warning"></i>添加链接</h6>									
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<div class="form-group">
					<label class="col-sm-3 control-label">链接名称<span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="name" class="form-control" placeholder="请输入链接名称" required/>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">链接地址 <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="url" class="form-control" placeholder="请输入链接地址" required />
					</div>
				</div>
				<div class="row">
					<div class="col-sm-9 col-sm-offset-3">
						<button class="bk-margin-5 btn btn-info">添加</button>
						<button type="reset" class="bk-margin-5 btn btn-default">重置</button>
					</div>
				</div>
			</div>									
		</div>
	</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>