<?php $__env->startSection('content'); ?>

<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="panel panel-default bk-bg-white">
				<div class="panel-heading bk-bg-white">
					<h6><i class="fa fa-table red"></i><span class="break"></span>Default</h6>
					<div class="panel-actions">
						<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-sm-6">
							<div class="bk-margin-bottom-10">
								<button id="addToTable" class="btn btn-info">管理员列表 <i class="fa fa-plus"></i></button>
							</div>
						</div>
					</div>
					<form style='display:none;' action='/admin/userlist' method='post' name='myform'>
						<input type='hidden' name='_token' value='<?php echo e(csrf_token()); ?>'>
						<input type='hidden' name='_method' value='DELETE'>
					</form>
					<table class="table table-bordered table-striped mb-none" id="datatable-editable">
						<thead>
							<tr>
								<th>序号</th>
								<th>账号</th>
								<th>管理员</th>
								<th>操作</th>
							</tr>
						</thead>
						<tbody>
						<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<tr class="gradeX">
								<td><?php echo e($v->admin_id); ?></td>
								<td><?php echo e($v->admin_name); ?></td>
								<td>管理员</td>
								<td class="actions">
									<a href="#" class="hidden on-editing save-row"><i class="fa fa-save"></i></a>
									<a href="#" class="hidden on-editing cancel-row"><i class="fa fa-times"></i></a>
									<a href="/admin/userlist/<?php echo e($v->admin_id); ?>/edit" class="on-default edit-row"><i class="fa fa-pencil"></i></a>
									<a href="javascript:doDel(<?php echo e($v->admin_id); ?>)" class="on-default remove-row"><i class="fa fa-trash-o"></i></a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</tbody>

					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function doDel(admin_id)
	{
		if(confirm("你确定要删除管理员吗？")){
			var form = document.myform;
			form.action = '/admin/userlist/'+admin_id;
			form.submit();
		}
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>