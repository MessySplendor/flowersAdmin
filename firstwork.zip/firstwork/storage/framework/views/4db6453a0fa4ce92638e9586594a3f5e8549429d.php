<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span><a href="<?php echo e(url('admin/dd')); ?>">订单列表</a></h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped mb-none" id="datatable-editable">
					
					<thead>
						<tr style="background-color:#eaf8ff">
							<th>订单编号</th>
							<th>下单时间</th>
							<th>用户名</th>
							<th>订单状态</th>
							<th colspan="2" style="text-align:center;">操作</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr class="gradeX">
							<td><?php echo e($v->ordernumber); ?></td>
							<td><?php echo e(date("Y-m-d H:i:s",$v->dtime)); ?></td>
							<td><?php echo e($v->name); ?></td>
							<td style="color:red;">
								<?php if($v->statues==1): ?>
									待付款
								<?php elseif($v->statues==2): ?>
									待发货
								<?php elseif($v->statues==3): ?>
									待收货
								<?php elseif($v->statues==4): ?>
									交易已完成
								<?php endif; ?>
							</td>
							<td>
								<a href="<?php echo e(url('admin/odlist/'.$v->ordernumber.'')); ?>">查看订单</a>
							</td>
							<td>
								<?php if($v->statues==1): ?>
								<a class="btn btn-info" href="">待付款</a>
								<?php elseif($v->statues==2): ?>
								<a class="btn btn-info" href="<?php echo e(url('admin/fahuo/'.$v->ordernumber.'')); ?>">去发货</a>
								<?php elseif($v->statues==3): ?>
								<a class="btn btn-info" href="">等待收货</a>
								<?php elseif($v->statues==4): ?>
								<a class="btn btn-info" href="">交易成功</a>
								<?php endif; ?>

							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>	
<?php $__env->stopSection(); ?>				 
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>