<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="panel panel-default bk-bg-white">
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span>评论列表</h6>							
				<div class="panel-actions">
					<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
				</div>
			</div>
			<div class="panel-body">
				<table class="table table-bordered table-striped mb-none" id="datatable-editable">
					
					<thead>
						<tr>
							<th>编号</th>
							<th>商品名称</th>
							<th>评论时间</th>
							<th>评论内容</th>
							<th>用户</th>
							<th>操作</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr class="gradeX">
							<td><?php echo e($v->comment_id); ?></td>
							<td><?php echo e($v->goods_name); ?></td>
							<td><?php echo e(date('Y-m-d H:i:s',$v->comment_time)); ?></td>
							<td><?php echo e($v->comment_content); ?></td>
							<td><?php echo e($v->name); ?></td>
							<td>
								<a href="<?php echo e(url('admin/comment/'.$v->comment_id.'')); ?>">删除</a>
							</td>
							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</tbody>

					
				</table>
				<?php echo e($comment->links()); ?>

			</div>
		</div>
	</div>
</div>	
<?php $__env->stopSection(); ?>				 
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>