<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <title>个人中心</title>
        <meta name="viewport" content="width=1226">
        <meta name="description" content="">
        <meta name="keywords" content="小米手机,小米手机官网">
        <link rel="stylesheet" href="<?php echo e(asset('homes/info_files/base.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('homes/info_files/main.css')); ?>">
    </head>
    <body>
        <div class="site-topbar">
                <div class="container">
                    <div class="topbar-nav">
                        <a >小米商城</a>
                            <span class="sep">|</span>
                        <a >MIUI</a>
                    </div>
                    <div class="topbar-cart" id="J_miniCartTrigger">
                        <a rel="nofollow" class="cart-mini" id="J_miniCartBtn" href="<?php echo e(url('/cart')); ?>"><i class="iconfont">&#xe60c;</i>购物车<span class="cart-mini-num J_cartNum"></span></a>
                        <div class="cart-menu" id="J_miniCartMenu">
                            <div class="loading"><div class="loader"></div></div>
                        </div>
                    </div>
                     <?php if(session('homeuser') != null): ?>
            
                    <div class="topbar-info" id="J_userInfo">
                         <a  rel="nofollow" class="link" href="<?php echo e(url('home/myself')); ?>" data-needlogin="true"><?php echo e(session('homeuser')->det_nicheng); ?></a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(url('home/out')); ?>" >退出</a><span class="sep">|</span><a href="<?php echo e(url('home/order/0')); ?>">我的订单</a>
                    </div>
                    <?php else: ?>
                    <div class="topbar-info" id="J_userInfo">
                        <a  rel="nofollow" class="link" href="<?php echo e(url('home/login')); ?>" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(asset('home/zhuce')); ?>" >注册</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="breadcrumbs">
            <div class="container">
                <a href="<?php echo e(asset('/')); ?>">首页</a><span class="sep">&gt;</span><span>个人中心</span>    </div>
        </div>
        <div class="page-main user-main">
            <div class="container">
                <div class="row">
                    <div class="span4">
                        <div class="uc-box uc-sub-box">
                   <div class="uc-nav-box">
                        <div class="box-hd">
                            <h3 class="title">订单中心</h3>
                        </div>
                        <div class="box-bd">
                            <ul class="uc-nav-list">
                                <li><a href="<?php echo e(url('home/dingdan')); ?>">我的订单</a></li>                              
                            </ul>
                            <ul class="uc-nav-list">
                                <li><a href="<?php echo e(url('home/pj/0')); ?>">评价晒单</a></li>                              
                            </ul>
                        </div>
                    </div>
                    <div class="uc-nav-box">
                        <div class="box-hd">
                            <h3 class="title">个人中心</h3>
                        </div>
                        <div class="box-bd">
                            <ul class="uc-nav-list">
                                <li class="active"><a href="<?php echo e(url('home/myself')); ?>">我的个人中心</a></li>                                
                                 <li><a href="<?php echo e(url('home/stor')); ?>">代金券</a></li>
                                <li><a href="<?php echo e(url('home/store')); ?>">我的收藏</a></li>
                                <li><a href="<?php echo e(url('home/myaddress')); ?>">收货地址</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>                    
                </div>
            </div>
        </div>

        <div class="site-footer">
            <div class="container">
                <div class="footer-service">
                    <ul class="list-service clearfix">
                        <li><a rel="nofollow" target="_blank" data-stat-id="46873828b7b782f4" ><i class="iconfont"></i>预约维修服务</a></li>
                        <li><a rel="nofollow" target="_blank" data-stat-id="78babcae8a619e26" ><i class="iconfont"></i>7天无理由退货</a></li>
                        <li><a rel="nofollow" target="_blank" data-stat-id="d1745f68f8d2dad7" ><i class="iconfont"></i>15天免费换货</a></li>
                        <li><a rel="nofollow" target="_blank" data-stat-id="2b5586f1346ce37a" ><i class="iconfont"></i>满99元包邮</a></li>
                        <li><a rel="nofollow" target="_blank" data-stat-id="b57397dd7ad77a31" ><i class="iconfont"></i>520余家售后网点</a></li>
                    </ul>
                </div>
                <div class="footer-links clearfix">
                    
                    <dl class="col-links col-links-first">
                        <dt>帮助中心</dt>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="e5dad0738a41014f">账户管理</a></dd>
                        
                        <dd><a rel="nofollow" data-stat-id="8e128f473e680197" >购物指南</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="fd9e3532f60a2f8d" >订单操作</a></dd>
                        
                    </dl>
                        
                    <dl class="col-links ">
                        <dt>服务支持</dt>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="8e282b6f669ba990">售后政策</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="5f2408ab3c808aa2">自助服务</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="18c340c920a278a1">相关下载</a></dd>
                        
                    </dl>
                        
                    <dl class="col-links ">
                        <dt>线下门店</dt>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="b27b566974e4aa67">小米之家</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="6dab396f7a873f15" >服务网点</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="9af5efe014c3aea2" >零售网点</a></dd>
                        
                    </dl>
                        
                    <dl class="col-links ">
                        <dt>关于小米</dt>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="f6d386c65b1f4132">了解小米</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="4307a445f5592adb">加入小米</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="6842e821365ee45d">联系我们</a></dd>
                        
                    </dl>
                        
                    <dl class="col-links ">
                        <dt>关注我们</dt>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="4d561ee685cd2e15">新浪微博</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="78fdefa9dee561b5">小米部落</a></dd>
                        
                        <dd><a rel="nofollow" data-toggle="modal" data-stat-id="47539f6570f0da90">官方微信</a></dd>
                        
                    </dl>
                        
                    <dl class="col-links ">
                        <dt>特色服务</dt>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="fdc16dd51892a164">F 码通道</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="99876c8aaf8ef0a4" >小米移动</a></dd>
                        
                        <dd><a rel="nofollow" target="_blank" data-stat-id="b08be6bd51351e1a">防伪查询</a></dd>
                         
                    </dl>
                        
                    <div class="col-contact">
                        <p class="phone">400-100-5678</p>
                            <p><span class="J_serviceTime-normal" style="">周一至周日 8:00-18:00</span>
                            <span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
                            <a rel="nofollow" class="btn btn-line-primary btn-small"  target="_blank" data-stat-id="a7642f0a3475d686"><i class="iconfont"></i> 24小时在线客服</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-info">
            <div class="container">
                <div class="logo ir">小米官网</div>
                    <div class="info-text">
                        <p class="sites">
                            <a rel="nofollow" href=""  onclick="_msq.push">小米商城</a>
                                <span class="sep">|</span>
                            <a rel="nofollow" href="" onclick="_msq.push">MIUI</a>
                        </p>
                        <p>©
                            <a href="" onclick="_msq.push">mi.com</a> 京ICP证110507号 
                            <a href=""  onclick="_msq.push">京ICP备10046444号</a> 
                            <a rel="nofollow" href=""  onclick="_msq.push">京公网安备11010802020134号 </a>
                            <a rel="nofollow" href="" onclick="_msq.push">京网文[2014]0059-0009号</a>

                            <br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试
                        </p>
                    </div>
                    <div class="info-links">
                        <a rel="nofollow" href="" onclick="_msq.push">
                            <img rel="nofollow" src="" alt="TRUSTe Privacy Certification">
                        </a>
                        <a rel="nofollow" href="" onclick="_msq.push">
                            <img rel="nofollow" src="" alt="诚信网站">
                        </a>
                        <a rel="nofollow" href="" onclick="_msq.push">
                            <img rel="nofollow" src="" alt="可信网站">
                        </a>
                        <a rel="nofollow" href="" onclick="_msq.push">
                            <img rel="nofollow" src="" alt="网上交易保障中心">
                        </a>
                    </div>
                </div>
                <div class="slogan ir">探索黑科技，小米为发烧而生</div>
            </div>
        </div>
    </body>
</html>