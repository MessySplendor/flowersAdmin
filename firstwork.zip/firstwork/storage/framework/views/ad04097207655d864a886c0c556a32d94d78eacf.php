<?php $__env->startSection('content'); ?>

<div class="xm-product-box">
    <div class="hd nav-bar J_headNav">
        <div class="container">
            <div class="title">
			    <h2>
			    小米Note
			    </h2>
			</div>
			<div class="nav">				
			    <a href="<?php echo e(url('home/buy/'.$list[0]->goods_id.'')); ?>" target="_blank" class="btn btn-primary btn-small" >立即购买</a>
			</div>
			<div class="bd">
			    <div class="nav-bar nav-bar-hidden J_fixNarBar">
			        <div class="container">
			            <div class="title">
						    <h2>
						       小米Note 2
						    </h2>
						</div>
						<div class="nav">
						   
						    <a href="<?php echo e(url('home/buy/'.$list[0]->goods_id.'')); ?>" target="_blank" class="btn btn-primary btn-small" data-stat-id="e56825e6e2c7e9b1" onclick="_msq.push">立即购买</a>
						</div>
			        </div>
			    </div>
			</div>
		</div>

<div class="minote2-specs minote2-bd">

    <div class="section section-intro is-visible preload">
        <div class="container common-container">
            <style type="text/css">
                #show{
                    width:450px;
                    height:600px;
                    float:left;
                    margin-left:50px;
                    margin_top:50px;
                }
            </style>
            <div id="show">
                <img src="<?php echo e(asset('/uploads/gdimage/'.$list[0]->image.'')); ?>" id="hid" width="550px" height="600px">
            </div>
            <div class="context">
                <div class="sup clearfix">
                <!-- 必须写成$i,不能写成i -->
                <!-- 每两个为一组,所以要隔一个遍历 $i+=2 -->
                <?php for($i=0;$i<count($introduction);$i+=2): ?>
                    <?php if(($i+1)%6!=0): ?>
                    <dl>
                        <dt><?php echo e($introduction[$i]); ?></dt>
                        <dd><?php echo e($introduction[$i+1]); ?></dd>
                    </dl>
                    <?php else: ?>
                    <dl class='last'>
                        <dt><?php echo e($introduction[$i]); ?></dt>
                        <dd><?php echo e($introduction[$i+1]); ?></dd>
                    </dl>
                    <?php endif; ?>  
                <?php endfor; ?> 
                </div>

                <div class="sub" id="J_colorSwitch">
                    <div>
                        <span class="sub-span1">标准版 / 高配版</span>
                    </div>
                    <ul class="clearfix">
                    <style type="text/css">
                        .kuang{
                            width:50px;
                            height:70px;
                            margin:0 auto;
                        }
                    </style>
                    <script type="text/javascript" src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
                    <script type="text/javascript">
                        $(function(){
                            $("#did img").mouseover(function(){
                                    $(this).css("border","1px solid red");
                                    $("#hid").attr('src',$(this).attr('src'));
                                }).mouseout(function(){
                                    $(this).css("border","");
                                });
                            });
                    </script>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li data-index="1" class="active" >
                            <div>
                                <div class="kuang" id="did">   
                                    <img src="<?php echo e(asset('/uploads/gdimage/'.$v->image.'')); ?>" width="50px" height="70px">
                                </div>
                                <p><?php echo e($v->flag); ?></p>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--配置-->
    <div class="section section-config preload is-visible">
        <div class="container">
            <div class="row">
                <div class="span5">
                    <h2 class="tit webfont">配置</h2>
                </div>
                <div class="span15">
                    <div class="row marB1">
                        <div class="span5">
                            <div class="context">  
                                <h3><?php echo e($configone[0]); ?></h3>
                                <div class="context">
                                <?php $__currentLoopData = $configone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <!-- 跳过第一次循环 -->
                                    <?php if($loop->first): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                    <!-- 跳过最后一次循环 -->
                                    <?php if($loop->last): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                     <!-- 执行循环 -->
                                    <?php echo e($v); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </div>
                              <p class="price"><?php echo e($configone[count($configone)-1]); ?></p>
                            </div>
                        </div>
                        <div class="span5">
                            <div class="context">
                                <h3><?php echo e($configtwo[0]); ?></h3>
                                <div class="context">
                                <?php $__currentLoopData = $configtwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <!-- 跳过第一次循环 -->
                                    <?php if($loop->first): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                    <!-- 跳过最后一次循环 -->
                                    <?php if($loop->last): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                     <!-- 执行循环 -->
                                    <?php echo e($v); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </div>
                                <p class="price"><?php echo e($configtwo[count($configtwo)-1]); ?></p>
                            </div>
                        </div>
                        <div class="span5">
                            <div class="context">
                                <h3><?php echo e($configthree[0]); ?></h3>
                                <div class="context">
                                <?php $__currentLoopData = $configthree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <!-- 跳过第一次循环 -->
                                    <?php if($loop->first): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                    <!-- 跳过最后一次循环 -->
                                    <?php if($loop->last): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>
                                     <!-- 执行循环 -->
                                    <?php echo e($v); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </div>
                                <p class="price"><?php echo e($configthree[count($configthree)-1]); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="link">
                        <a href="javascript:void(0);" class="J_control" data-stat-id="6939dabf2cc952bf" onclick="_msq.push(['trackEvent', 'a9390b41ea30e940-6939dabf2cc952bf', 'javascript:void(0);', 'pcpid']);">多大存储空间适合我 <i class="arrow"></i></a>
                    </div>
                    <div class="msg J_msg">
                        <span class="closed"><i class="iconfont"></i></span>
                        <div class="context">
                            容量越大，你在 手机上就有越多空间用来存储文件。<br>
                            如果你喜欢定期使用小米云服务存储文件，如音乐、照片和影片，那么，较小的容量是个不错的选择。<br>
                            对于喜欢在手机上随时听歌、玩游戏等用户来说，选择较大容量可能更合适。选择容量时，一定要考虑<br>
                            自己的容量需求可能会随着时间的推移而变化。
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--尺寸重量   -->
    <div class="section section-size preload is-visible">
        <div class="container">
            <div class="row">
                <div class="span5">
                    <h2 class="tit webfont"><?php echo e($size_weight[0]); ?></h2>
                </div>
                <div class="span15">
                    <div class="context">
                        <?php $__currentLoopData = $size_weight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <!-- 跳过第一次循环 -->
                            <?php if($loop->first): ?>
                                <?php continue; ?>
                            <?php endif; ?>
                             <!-- 执行循环 -->
                            <?php echo e($v); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!--续航 与 快充-->
    <div class="section preload is-visible">
        <div class="container">
            <div class="row">
                <div class="span5">
                    <h2 class="tit webfont"><?php echo e($electricize[0]); ?></h2>
                </div>
                <div class="span15">
                    <div class="context">
                        <?php $__currentLoopData = $electricize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <!-- 跳过第一次循环 -->
                            <?php if($loop->first): ?>
                                <?php continue; ?>
                            <?php endif; ?>
                             <!-- 执行循环 -->
                            <?php echo e($v); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="link">
                        <a href="javascript:void(0);" class="J_control" data-stat-id="64ae3fb08ca1ab0f" onclick="_msq.push(['trackEvent', 'a9390b41ea30e940-64ae3fb08ca1ab0f', 'javascript:void(0);', 'pcpid']);">小米实验室实测表现 <i class="arrow"></i></a>
                    </div>
                    <div class="msg J_msg">
                        <span class="closed"><i class="iconfont"></i></span>
                        <div class="context">

                            待机 240小时<br>
                            音乐 139小时<br>
                            视频播放 15.73小时<br>
                            阅读 22小时<br>
                            游戏 12小时<br>
                            通话 46小时<br>
                            导航 13小时
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <!--拍照 与 摄像-->
    <div class="section section-camera preload is-visible">
        <div class="container">
            <div class="row">
                <div class="span5">
                    <h2 class="tit webfont"><?php echo e($camera[0]); ?></h2>
                </div>
                <div class="span6">
                    <div class="context">
                        <h3>2256 万像素相机</h3>
                        <?php $__currentLoopData = $camera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <!-- 跳过第一次循环 -->
                            <?php if($loop->first): ?>
                                <?php continue; ?>
                            <?php endif; ?>
                             <!-- 执行循环 -->
                            <?php echo e($v); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="context text1">
                        <h3>800万像素自动对焦前置相机 </h3>
                        5片式镜头，ƒ/2.0 ，FOV 76°<br>
                        支持 AF 自动对焦<br>
                        第三代智能美颜，支持大眼、瘦脸<br>
                        合影优选<br>
                        面部识别功能
                    </div>
                    <div class="context text1">
                        <h3>支持 4K 防抖视频拍摄 </h3>
                    </div>

                    <div class="link">
                        <a href="http://www.mi.com/minote2/camera" data-stat-id="47f52b4c938cb4c2" onclick="_msq.push(['trackEvent', 'a9390b41ea30e940-47f52b4c938cb4c2', '/minote2/camera', 'pcpid']);">了解相机 &gt;</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--显示屏-->
    <div class="section section-screen preload is-visible">
        <div class="container">
            <div class="row marB2">
                <div class="span5">
                    <h2 class="tit webfont">
                        <?php echo e($screen[0]); ?>

                    </h2>
                </div>
                <div class="span7">
                    <div class="context">
                        <p class="text">
                            <?php $__currentLoopData = $screen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <!-- 跳过第一次循环 -->
                                <?php if($loop->first): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                 <!-- 执行循环 -->
                                <?php echo e($v); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--全网通-->
    <div class="section section-screen preload is-visible">
        <div class="container">
            <div class="row">
                <div class="span5">
                    <h2 class="tit webfont">
                        <?php echo e($operator[0]); ?><br>
                    </h2>
                </div>
                <div class="span7">
                    <div class="context">
                        <p class="text">
                            <?php $__currentLoopData = $operator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <!-- 跳过第一次循环 -->
                                <?php if($loop->first): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                 <!-- 执行循环 -->
                                <?php echo e($v); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </p>

                    </div>

                </div>
                <div class="span7">
                    <div class="img img1"></div>
                </div>
            </div>
            <div class="row">
                <div class="span5"></div>
                <div class="span15">
                    <div class="link">
                        <a href="javascript:void(0);" class="J_control" data-stat-id="4ed18390826ef85c" onclick="_msq.push(['trackEvent', 'a9390b41ea30e940-4ed18390826ef85c', 'javascript:void(0);', 'pcpid']);"> </i></a>
                    </div>
                    <div class="msg J_msg">
                        <span class="closed"><i class="iconfont"></i></span>
                        <div class="context">
                            <h3>双卡使用特别说明：</h3>
                            <div class="text">
                                支持移动、联通、电信4G / 3G / 2G，支持多种载波聚合组合的 4G+ 网络<br>
                                当主卡移动、联通4G时，副卡突破性的最高支持联通3G 网络语音电话<br>
                                2张电信卡无法同时使用：同时使用时一张卡可使用 4G 网络，另一张卡将不能注册网络。​
                            </div>

                            <h3>全球版</h3>
                            <div class="text">
                                FDD-LTE (频段 B1，B2，B3，B4，B5，B7，B8，B12，B13，B17，<br>
                                B18，B19，B20，B25，B26，B28，B29，B30)<br>
                                TDD-LTE (频段 B38，B39，B40，B41)<br>
                                TD-SCDMA (频段 B34，B39)<br>
                                WCDMA (频段 B1，B2，B4，B5，B8)<br>
                                GSM (频段 B2，B3，B5，B8)<br>
                                CDMA (频段 BC0，B1，B10，B15)
                            </div>


                            <h3>全网通</h3>

                            <div class="text">
                                FDD-LTE (频段 B1，B3，B5，B7)<br>
                                TDD-LTE (频段 B38，B39，B40，B41)<br>
                                TD-SCDMA (频段 B34，B39)<br>
                                WCDMA (频段 B1，B2，B5，B8)<br>
                                GSM (频段 B2，B3，B5，B8)<br>
                                CDMA (频段 BC0)
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>