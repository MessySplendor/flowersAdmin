<!DOCTYPE html>
<html xml:lang="zh-CN"><head><script type="text/javascript" async="" src=""></script><script type="text/javascript" async="" src=""></script><script type="text/javascript" async="" src=""></script><script type="text/javascript" async="" src=""></script><script type="text/javascript" async="" src=""></script>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>购买-小米商城</title>
<meta name="viewport" content="width=1226">
<meta name="description" content="小米Note 2开放购买页面支持购买小米Note 2．有多种版本可以选择">
<meta name="keywords" content="小米Note2购买,小米商城">
<link rel="shortcut icon" href="http://s01.mifile.cn/favicon.ico" type="image/x-icon">
<link rel="icon" href="http://s01.mifile.cn/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('homes/buy/base.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('homes/buy//buy-choose.css')); ?>">
<script type="text/javascript" async="" src=""></script><script type="text/javascript">var _head_over_time = (new Date()).getTime();</script>
</head>
<body>
    <div class="site-header site-mini-header">
        <div class="container">
            <div class="header-logo">
                <a class="logo ir" href=""data-stat-id="f4006c1551f77f22" onclick="_msq.push">小米官网</a>
            </div>
        
            <div class="topbar-info" id="J_userInfo">
            <span class="user">
                <?php if(session('homeuser') != null): ?>
        
                <div class="topbar-info" id="J_userInfo">
                     <a  rel="nofollow" class="link" href="<?php echo e(url('home/myself')); ?>" data-needlogin="true"><?php echo e(session('homeuser')->det_nicheng); ?></a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(url('home/out')); ?>" >退出</a><span class="sep">|</span><a href="<?php echo e(url('home/dingdan')); ?>">我的订单</a>
                </div>
                <?php else: ?>
                <div class="topbar-info" id="J_userInfo">
                    <a  rel="nofollow" class="link" href="<?php echo e(asset('home/login')); ?>" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(asset('home/zhuce')); ?>" >注册</a>
                </div>
                <?php endif; ?>
            </span>
                
            </div>
        </div>
    </div>
    <!-- .site-mini-header END -->
    <div class="container breadcrumbs">
    </div>

<div class="container hide">
    <div class="xm-phone-menu">
        <ul class="clearfix">
            <li>
                <a href="http://item.mi.com/buyphone/compare" data-stat-id="875e20e81de519cf" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-875e20e81de519cf', '//item.mi.com/buyphone/compare', 'pcpid']);">
                    <img src="" alt="">
                    <span>对比手机</span>
                </a>
            </li>
        </ul>
    </div>
</div>

<style>
.msg-bd font {display:none;}
</style>

<script type="text/javascript">
    var orderapi = '//cn.orderapi.mi.com';
    var chooseConfig = {
        phone_type: 'minote2',
        package_tag: 'minote2',
        version_data: {"node_id":983,"title":"\u5c0f\u7c73Note 2","desc":"\u8d2d\u4e70\u5c0f\u7c73Note 2","img":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-zuhe.png","next_title":"\u9009\u62e9\u7248\u672c","short_tag":"minote2","href_url":"\/\/www.mi.com\/minote2\/","price_min":"2799","price_max":"3499","children":[{"node_id":984,"title":"\u6807\u51c6\u7248 4GB\u5185\u5b58+64GB\u5bb9\u91cf","short_tag":"","img":"!600x600","icon":"","clickable":1,"push_type":null,"href_url":"","goods_id":0,"sales_type":"0","heyue_tag":"","desc":"\u9a81\u9f99821 \u6027\u80fd\u7248\uff0c\u6700\u9ad8\u4e3b\u9891 2.35GHz\uff0cAdreno 530 \u56fe\u5f62\u5904\u7406\u5668","next_title":"\u9009\u62e9\u989c\u8272","price_min":"2799","price_max":"2799","force_status":"default","price":0,"is_openbuy":0,"is_presales":0,"is_opensell":0,"is_fixedlink":0,"subscribe_url":"","subscribe_title":"","children":[{"node_id":987,"title":"\u4eae\u9ed1\u8272","short_tag":"","img":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-heise!600x600.png","icon":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/mi4-icon-hei.png","clickable":1,"push_type":null,"href_url":"","goods_id":2164200001,"sales_type":"0","heyue_tag":"","desc":"","next_title":"","price_min":"2799","price_max":"2799","force_status":"default","price":"2799","is_openbuy":0,"is_presales":0,"is_opensell":1,"is_opensell_open":1,"opensell_url":"\/\/cart.mi.com\/cart\/recommend\/goods_id\/2164200001","is_fixedlink":0,"subscribe_url":"","subscribe_title":""},{"node_id":986,"title":"\u51b0\u5ddd\u94f6","short_tag":"","img":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-yin!600x600.png","icon":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone-common\/icon-yin.jpg","clickable":1,"push_type":null,"href_url":"","goods_id":2164200002,"sales_type":"0","heyue_tag":"","desc":"","next_title":"","price_min":"2799","price_max":"2799","force_status":"default","price":"2799","is_openbuy":0,"is_presales":0,"is_opensell":1,"is_opensell_open":1,"opensell_url":"\/\/cart.mi.com\/cart\/recommend\/goods_id\/2164200002","is_fixedlink":0,"subscribe_url":"","subscribe_title":""}]},{"node_id":985,"title":"\u9ad8\u914d\u7248 6GB\u5185\u5b58+128GB\u5bb9\u91cf","short_tag":"","img":"!600x600","icon":"","clickable":1,"push_type":null,"href_url":"","goods_id":0,"sales_type":"0","heyue_tag":"","desc":"\u9a81\u9f99821 \u6027\u80fd\u7248\uff0c\u6700\u9ad8\u4e3b\u9891 2.35GHz\uff0cAdreno 530 \u56fe\u5f62\u5904\u7406\u5668","next_title":"\u9009\u62e9\u989c\u8272","price_min":"3299","price_max":"3299","force_status":"default","price":0,"is_openbuy":0,"is_presales":0,"is_opensell":0,"is_fixedlink":0,"subscribe_url":"","subscribe_title":"","children":[{"node_id":989,"title":"\u4eae\u9ed1\u8272","short_tag":"","img":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-heise!600x600.png","icon":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/mi4-icon-hei.png","clickable":1,"push_type":null,"href_url":"","goods_id":2164200004,"sales_type":"0","heyue_tag":"","desc":"","next_title":"","price_min":"3299","price_max":"3299","force_status":"default","price":"3299","is_openbuy":0,"is_presales":0,"is_opensell":1,"is_opensell_open":1,"opensell_url":"\/\/cart.mi.com\/cart\/recommend\/goods_id\/2164200004","is_fixedlink":0,"subscribe_url":"","subscribe_title":""},{"node_id":988,"title":"\u51b0\u5ddd\u94f6","short_tag":"","img":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-yin!600x600.png","icon":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone-common\/icon-yin.jpg","clickable":1,"push_type":null,"href_url":"","goods_id":2164200005,"sales_type":"0","heyue_tag":"","desc":"","next_title":"","price_min":"3299","price_max":"3299","force_status":"default","price":"3299","is_openbuy":0,"is_presales":0,"is_opensell":1,"is_opensell_open":1,"opensell_url":"\/\/cart.mi.com\/cart\/recommend\/goods_id\/2164200005","is_fixedlink":0,"subscribe_url":"","subscribe_title":""}]},{"node_id":1029,"title":"\u5168\u7403\u7248 6GB\u5185\u5b58+128GB\u5bb9\u91cf","short_tag":"","img":"!600x600","icon":"","clickable":1,"push_type":null,"href_url":"","goods_id":0,"sales_type":"0","heyue_tag":"","desc":"4G+ \u5168\u7403\u9891\u6bb5\uff0c\u9a81\u9f99821 \u6027\u80fd\u7248\uff0c\u6700\u9ad8\u4e3b\u9891 2.35GHz\uff0cAdreno 530 \u56fe\u5f62\u5904\u7406\u5668","next_title":"","price_min":"3499","price_max":"3499","force_status":"default","price":0,"is_openbuy":0,"is_presales":0,"is_opensell":0,"is_fixedlink":0,"subscribe_url":"","subscribe_title":"","children":[{"node_id":1030,"title":"\u4eae\u9ed1\u8272","short_tag":"","img":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-heise!600x600.png","icon":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/mi4-icon-hei.png","clickable":1,"push_type":null,"href_url":"","goods_id":2164200006,"sales_type":"0","heyue_tag":"","desc":"","next_title":"","price_min":"3499","price_max":"3499","force_status":"default","price":"3499","is_openbuy":0,"is_presales":0,"is_opensell":1,"is_opensell_open":1,"opensell_url":"\/\/cart.mi.com\/cart\/recommend\/goods_id\/2164200006","is_fixedlink":0,"subscribe_url":"","subscribe_title":""}]}]},
        multi_desc: [{"type":"\u5b9a\u65f6\u6587\u6848","data":[]},{"type":"\u5b9a\u65f6\u6587\u6848","data":[]},{"type":"\u5b9a\u65f6\u6587\u6848","data":[]},{"type":"image","data":[{"pic_url":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-shenruliaojie.png","title":"\u5c0f\u7c73Note 2","link_url":"http:\/\/www.mi.com\/minote2\/","height":null}]},{"type":"image","data":[{"pic_url":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-lunbo1.png","title":"\u5c0f\u7c73Note 2","link_url":"http:\/\/www.mi.com\/minote2\/","height":null},{"pic_url":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-lunbo2.jpg","title":"\u5c0f\u7c73Note 2","link_url":"http:\/\/www.mi.com\/minote2\/","height":null},{"pic_url":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-lunbo3.jpg","title":"\u5c0f\u7c73Note 2","link_url":"http:\/\/www.mi.com\/minote2\/","height":null},{"pic_url":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-lunbo4.jpg","title":"\u5c0f\u7c73Note 2","link_url":"http:\/\/www.mi.com\/minote2\/","height":null}]},{"type":"image","data":[{"pic_url":"\/\/c1.mifile.cn\/f\/i\/15\/item\/buyphone\/note2-yiwaibao.png","title":"\u5c0f\u7c73Note 2","link_url":"http:\/\/www.mi.com\/service\/damage","height":""}]},{"type":"specs","data":[{"title":"\u5904\u7406\u5668","subs":[{"itemName":"\u6807\u51c6\u7248 4GB\u5185\u5b58+64GB\u5bb9\u91cf","content":"\u9a81\u9f99821 \u6027\u80fd\u7248\uff0c\u6700\u9ad8\u4e3b\u9891 2.35GHz<br\/>Adreno 530 \u56fe\u5f62\u5904\u7406\u5668<br\/>4G+ \u5168\u7f51\u901a"},{"itemName":"\u9ad8\u914d\u5168\u7f51\u901a 6GB\u5185\u5b58+128GB\u5bb9\u91cf","content":"\u9a81\u9f99821 \u6027\u80fd\u7248\uff0c\u6700\u9ad8\u4e3b\u9891 2.35GHz<br\/>Adreno 530 \u56fe\u5f62\u5904\u7406\u5668<br\/>4G+ \u5168\u7f51\u901a"},{"itemName":"\u9ad8\u914d\u5168\u7403\u7248 6GB\u5185\u5b58+128GB\u5bb9\u91cf","content":"\u9a81\u9f99821 \u6027\u80fd\u7248\uff0c\u6700\u9ad8\u4e3b\u9891 2.35GHz<br\/>Adreno 530 \u56fe\u5f62\u5904\u7406\u5668<br\/>4G+ \u5168\u7403\u9891\u6bb5"}]},{"title":"\u5185\u5b58 \/ \u5b58\u50a8","content":"4GB\u5185\u5b58+64GB\u5bb9\u91cf<br\/>6GB\u5185\u5b58+128GB\u5bb9\u91cf"},{"title":"\u663e\u793a\u5c4f","content":"5.7 \u82f1\u5bf8\u67d4\u6027\u66f2\u9762\u5c4f<br\/>100000:1 \u5bf9\u6bd4\u5ea6<br\/>110% NTSC\u8272\u57df<br\/>1920 x 1080 \u5206\u8fa8\u7387<br\/>\u652f\u6301\u9633\u5149\u5c4f\uff0c\u5f3a\u70c8\u9633\u5149\u4e0b\u6e05\u6670\u53ef\u89c1\u5c4f\u5e55\u5185\u5bb9<br\/>\u652f\u6301\u62a4\u773c\u6a21\u5f0f<br\/>\u652f\u6301\u8272\u6e29\u8c03\u8282\u3001\u6807\u51c6\u6a21\u5f0f"},{"title":"\u6307\u7eb9\u8bc6\u522b","content":"\u524d\u7f6e\u6307\u7eb9\u8bc6\u522b"},{"title":"2256 \u4e07\u50cf\u7d20\u76f8\u673a","content":"6\u7247\u5f0f\u955c\u5934\uff0cf\/2.0\uff0cFOV 80\u00b0<br\/>\u53cc\u8272\u6e29\u95ea\u5149\u706f<br\/>\u786c\u4ef6\u7ea7\u7535\u5b50\u9632\u6296<br\/>\u6697\u5149\u753b\u8d28\u589e\u5f3a\u6280\u672f<br\/>HDR\u9ad8\u52a8\u6001\u8303\u56f4\u8c03\u8282\u6280\u672f<br\/>\u5168\u666f\u6a21\u5f0f<br\/>\u8fde\u62cd\u6a21\u5f0f<br\/>\u9762\u90e8\u8bc6\u522b\u529f\u80fd<br\/>\u5b9e\u65f6\u6ee4\u955c\u62cd\u7167"},{"title":"800\u4e07\u50cf\u7d20\u81ea\u52a8\u5bf9\u7126\u524d\u7f6e\u76f8\u673a","content":"5\u7247\u5f0f\u955c\u5934\uff0c\u0192\/2.0 \uff0cFOV 76\u00b0<br\/>\u652f\u6301 AF \u81ea\u52a8\u5bf9\u7126<br\/>\u7b2c\u4e09\u4ee3\u667a\u80fd\u7f8e\u989c\uff0c\u652f\u6301\u5927\u773c\u3001\u7626\u8138<br\/>\u5408\u5f71\u4f18\u9009<br\/>\u9762\u90e8\u8bc6\u522b\u529f\u80fd"},{"title":"\u7f51\u7edc\u652f\u6301","content":"\u5168\u7403\u7248\uff086 \u6a21 37 \u9891\uff09<br\/>\u5168\u7f51\u901a\uff086 \u6a21 19 \u9891\uff09<br\/>\u652f\u6301 CAT 12<br\/>\u652f\u6301\u591a\u79cd\u8f7d\u6ce2\u805a\u5408\u7ec4\u5408\u7684 4G+ \u7f51\u7edc"},{"title":"\u65e0\u7ebf\u8fde\u63a5","content":"802.11 ac \u53cc\u9891\u65e0\u7ebf\u7f51\u7edc<br\/>\u84dd\u72594.2\u65e0\u7ebf\u6280\u672f<br\/>\u652f\u6301\u5168\u529f\u80fdNFC"},{"title":"\u4f20\u611f\u5668","content":"\u7ea2\u5916<br\/>\u9640\u87ba\u4eea<br\/>\u52a0\u901f\u5ea6\u4f20\u611f\u5668<br\/>\u8ddd\u79bb\u611f\u5e94\u5668<br\/>\u73af\u5883\u5149\u4f20\u611f\u5668<br\/>\u970d\u5c14\u611f\u5e94\u5668<br\/>\u7535\u5b50\u7f57\u76d8<br\/>\u6c14\u538b\u8ba1"},{"title":"GPS","content":"GPS<br\/>AGPS<br\/>GLONASS<br\/>\u5317\u6597\u5b9a\u4f4d"},{"title":"\u7535\u6c60\u5bb9\u91cf","content":"4070mAh\uff08typ\uff09 \/ 4000mAh\uff08min\uff09\u8d85\u957f\u7eed\u822a<br\/>\u652f\u6301\u5feb\u51453.0<br\/>9V \/ 2A \u5145\u7535"},{"title":"\u53ef\u9009\u7248\u672c","content":"\u6807\u51c6\u7248 4GB\u5185\u5b58+64GB\u5bb9\u91cf\uff1a2799\u5143<br\/>\u9ad8\u914d\u5168\u7f51\u901a 6GB\u5185\u5b58+128GB\u5bb9\u91cf\uff1a3299\u5143<br\/>\u9ad8\u914d\u5168\u7403\u7248 6GB\u5185\u5b58+128GB\u5bb9\u91cf\uff1a3499\u5143"}]}],
        package_data: [{"commodity_id":"1164300035","commodity_name":"\u5fc5\u5907\u5957\u9910","show_price":"99","market_price":"118","iamge":"\/\/i1.mifile.cn\/a1\/pms_1477274192.41871348.jpg","list":[[{"commodity_id":1163600039,"commodity_name":"\u5c0f\u7c73\u81ea\u62cd\u6746\uff08\u7ebf\u63a7\u7248\uff09 \u7070\u8272","goods_id":"2163600015","image":"\/\/i1.mifile.cn\/a1\/pms_1474430238.84556547.jpg","icon":"\/\/i1.mifile.cn\/a1\/pms_1474430238.84556547.jpg"}],[{"commodity_id":1161800010,"commodity_name":"\u5c0f\u7c73\u80f6\u56ca\u8033\u673a \u767d\u8272","goods_id":"2161800007","image":"\/\/i1.mifile.cn\/a1\/T1FVDQBbET1RXrhCrK.jpg","icon":"\/\/i1.mifile.cn\/a1\/T1FVDQBbET1RXrhCrK.jpg"},{"commodity_id":1161800009,"commodity_name":"\u5c0f\u7c73\u80f6\u56ca\u8033\u673a \u9ed1\u8272","goods_id":"2161800006","image":"\/\/i1.mifile.cn\/a1\/T1SkV_BCd_1RXrhCrK.jpg","icon":"\/\/i1.mifile.cn\/a1\/T1SkV_BCd_1RXrhCrK.jpg"}]]},{"commodity_id":"1164300036","commodity_name":"\u5b9e\u7528\u5957\u9910","show_price":"147","market_price":"167","iamge":"\/\/i1.mifile.cn\/a1\/pms_1477274152.15973919.jpg","list":[[{"commodity_id":1163600039,"commodity_name":"\u5c0f\u7c73\u81ea\u62cd\u6746\uff08\u7ebf\u63a7\u7248\uff09 \u7070\u8272","goods_id":"2163600015","image":"\/\/i1.mifile.cn\/a1\/pms_1474430238.84556547.jpg","icon":"\/\/i1.mifile.cn\/a1\/pms_1474430238.84556547.jpg"}],[{"commodity_id":1161800010,"commodity_name":"\u5c0f\u7c73\u80f6\u56ca\u8033\u673a \u767d\u8272","goods_id":"2161800007","image":"\/\/i1.mifile.cn\/a1\/T1FVDQBbET1RXrhCrK.jpg","icon":"\/\/i1.mifile.cn\/a1\/T1FVDQBbET1RXrhCrK.jpg"},{"commodity_id":1161800009,"commodity_name":"\u5c0f\u7c73\u80f6\u56ca\u8033\u673a \u9ed1\u8272","goods_id":"2161800006","image":"\/\/i1.mifile.cn\/a1\/T1SkV_BCd_1RXrhCrK.jpg","icon":"\/\/i1.mifile.cn\/a1\/T1SkV_BCd_1RXrhCrK.jpg"}],[{"commodity_id":1144800001,"commodity_name":"\u5c0f\u7c73\u79fb\u52a8\u7535\u6e905000mAh \u94f6\u8272","goods_id":"2144800001","image":"\/\/i1.mifile.cn\/a1\/T1pZbvBTET1RXrhCrK.jpg","icon":"\/\/i1.mifile.cn\/a1\/T1pZbvBTET1RXrhCrK.jpg"}]]}],
        opensell_ids:["2164200001","2164200002","2164200004","2164200005","2164200006"],
        special_opensell_ids:'',
        book_bigtap_ids:{"2160400006":{"is_book":true,"buy_start_time":1461895200},"2160400007":{"is_book":true,"buy_start_time":1461895200},"2160700029":{"is_book":true,"buy_start_time":1461895200},"2150100003":{"is_book":true,"buy_start_time":1461895200},"2154700014":{"is_book":true,"buy_start_time":1461895200},"2160400010":{"is_book":true,"buy_start_time":1461895200},"2161600033":{"is_book":true,"buy_start_time":1461895200},"2162100004":{"is_book":true,"buy_start_time":1461895200},"2162800010":{"is_book":true,"buy_start_time":1461895200},"1162700001":{"is_book":true,"buy_start_time":1461895200},"2155300001":{"is_book":true,"buy_start_time":1461895200},"2162000035":{"is_book":true,"buy_start_time":1461895200},"2162100006":{"is_book":true,"buy_start_time":1461895200},"2155300002":{"is_book":true,"buy_start_time":1461895200},"2163500025":{"is_book":true,"buy_start_time":1461895200},"2163500026":{"is_book":true,"buy_start_time":1461895200},"2163500027":{"is_book":true,"buy_start_time":1461895200},"2162900014":{"is_book":true,"buy_start_time":1461895200},"2163800008":{"is_book":true,"buy_start_time":1461895200},"2163800007":{"is_book":true,"buy_start_time":1461895200},"2163800006":{"is_book":true,"buy_start_time":1461895200},"2163800005":{"is_book":true,"buy_start_time":1461895200},"2163700032":{"is_book":true,"buy_start_time":1461895200},"2163800009":{"is_book":true,"buy_start_time":1461895200},"1164100014":{"is_book":true,"buy_start_time":1461895200},"2164200021":{"is_book":true,"buy_start_time":1461895200},"2164200005":{"is_book":true,"buy_start_time":1461895200},"2164200006":{"is_book":true,"buy_start_time":1461895200},"2164200004":{"is_book":true,"buy_start_time":1461895200},"2164200002":{"is_book":true,"buy_start_time":1461895200},"2164200001":{"is_book":true,"buy_start_time":1461895200},"2142400036":{"is_book":true,"buy_start_time":1461895200},"1164200001":{"is_book":true,"buy_start_time":1461895200},"2164200011":{"is_book":true,"buy_start_time":1461895200},"2164200007":{"is_book":true,"buy_start_time":1461895200},"2164200048":{"is_book":true,"buy_start_time":1461895200},"2164200047":{"is_book":true,"buy_start_time":1461895200},"2164200046":{"is_book":true,"buy_start_time":1461895200},"2164200045":{"is_book":true,"buy_start_time":1461895200},"2164200043":{"is_book":true,"buy_start_time":1461895200},"2163700017":{"is_book":true,"buy_start_time":1461895200},"2163700011":{"is_book":true,"buy_start_time":1461895200},"2163700013":{"is_book":true,"buy_start_time":1461895200},"2164700002":{"is_book":true,"buy_start_time":1461895200},"2164200008":{"is_book":true,"buy_start_time":1461895200},"2164200012":{"is_book":true,"buy_start_time":1461895200},"2164600009":{"is_book":true,"buy_start_time":1461895200},"2164300005":{"is_book":true,"buy_start_time":1461895200},"2163900011":{"is_book":true,"buy_start_time":1461895200},"2164400025":{"is_book":true,"buy_start_time":1461895200},"2163900010":{"is_book":true,"buy_start_time":1461895200},"2164800010":{"is_book":true,"buy_start_time":1461895200},"2154300011":{"is_book":true,"buy_start_time":1461895200},"2164300024":{"is_book":true,"buy_start_time":1461895200},"2164200044":{"is_book":true,"buy_start_time":1461895200},"2164700025":{"is_book":true,"buy_start_time":1461895200},"2165200032":{"is_book":true,"buy_start_time":1461895200}},
        checkSaleReg: true,  // 开售提醒开关
        showRecomment: true  // 推荐商品开关
    };
</script>

<div class="container buy-choose-box">

    <div class="hd nav-bar J_headNav">
        <div class="container">
            <div class="title">
                <h2>
                   <?php echo e($list[0]->goods_name); ?>

                </h2>
            </div>

        </div>
    </div>
        
    <div class="bd">
        <div class="pro-choose-main clearfix" id="J_chooseMain">
            <div class="pro-view">
                <img id="src" src="<?php echo e(asset('uploads/gdimage/'.$list[0]->image.'')); ?>" alt="小米Note 2" id="J_proImg" style="height: 80%;">
            </div>
            <div class="pro-info">
                <div class="pro-title clearfix">
                    <h1>
                        <span class="pro-name J_proDesc"><?php echo e($list[0]->goods_name); ?></span>
                        <span class="pro-price"><?php echo e($type_price[1]); ?></span>
                    </h1>
                    <a href="/home/gdetail/'.<?php echo e($goods_id); ?>.'" class="pro-more" target="_blank" id="J_proMore" data-stat-id="de39737fcfb04642" >深入了解产品&gt;</a>
                </div>
                <div>
                    <style type="text/css">
                        .kuang{
                            width:570px;
                        }
                        .border{
                            border:1px solid #DFDFDF;
                            width:263px;
                            height:50px;
                            text-align:center;
                            line-height:50px;
                            float:left;
                            margin-right:15px;
                            margin-top:5px;

                        }

                    </style>
                    <div class="pro-choose-step J_step" data-index="1"> 
                        <div class="step-title"> 1. 选择版本 
                            <i class="pro-version-desc-icon">!</i> 
                            <span class="pro-version-desc J_verDesc" data-index="1"></span> 
                        </div> 
                        <div class="kuang">
                            <?php for($i=0;$i<count($type_price);$i+=2): ?>
                                <div  class="border select" price="<?php echo e($type_price[$i+1]); ?>"><?php echo e($type_price[$i]); ?></div>
                            <?php endfor; ?>
                        </div>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
<script type="text/javascript">
    var car_type="";
    var car_color="";
    var car_pic="";
    var car_price="";
    $(function(){
        $(".select").mousedown(function(){
            $('.select').css('border', '1px solid #DFDFDF');
            $(this).css("border","1px solid red");
            $('.pro-price').text($(this).attr('price'));
            $('.J_verDesc').text($(this).text());
            $('.msg-bd b:nth-child(2)').text($(this).text());
            $('.msg-bd b:nth-child(4)').text($(this).attr('price'));
            car_type = $(this).text();
            car_price= $(this).attr('price');
            //document.write(type);
        });
         $(".xuan").mousedown(function(){
            $('.xuan').css('border', '1px solid #DFDFDF');
            $(this).css("border","1px solid red");
            $('.pro-price').text($(this).attr('price'));
            $('.bian').text($(this).text());
            $('.msg-bd b:nth-child(3)').text($(this).text());
            car_color = $(this).text();
        });
            $('.image').mousedown(function(){
            $('#src').attr('src',$(this).attr('src'));
            car_pic=$(this).attr('src');
            $('.buy').mousedown(function(){
            $.ajax({
            url: '<?php echo e(url('home/buycar')); ?>',
            type: 'post',
            dataType: 'json',
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            data: {goods_id:'<?php echo e($goods_id); ?>',car_color:car_color,car_type:car_type,car_price:car_price,_token:'<?php echo e(csrf_token()); ?>',car_pic:car_pic},
            });   
            });   
        }); 

//-------------收藏----------------//
            $('.collect').mousedown(function(){
                $.ajax({
                url: '<?php echo e(url('home/collect')); ?>',
                type: 'post',
                dataType: 'json',
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                data: {goods_id:'<?php echo e($goods_id); ?>',color:car_color,type:car_type,price:car_price,_token:'<?php echo e(csrf_token()); ?>'},
                error:function()            
                {
                    alert('ajax请求失败');
                },
                success:function(data)      
                {
                    if(data){
                        alert('添加成功');
                    }
                }
                });   
            });   
    });
</script>
                    </div>
                    <div class="pro-choose-step J_step" data-index="2">
                        <div class="step-title" style="clear:both"> 2. 选择颜色 
                             
                            <span class="pro-version-desc bian" data-index="2"></span> 
                        </div> 
                        <div class="kuang">
                            <?php for($i=0;$i<count($list);$i++): ?>
                                <div class="border image xuan" src="<?php echo e(asset('uploads/gdimage/'.$list[$i]->image.'')); ?>"><?php echo e($list[$i]->flag); ?></div>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
                <div class="choose-result-msg" id="J_chooseResultMsg" style="clear:both">
                    <span class="msg-tit">您选择了以下产品:</span>
                    <p class="msg-bd"><b><?php echo e($list[0]->goods_name); ?></b> <b></b> <b></b> <b></b></p>
                </div>
                <div class="pro-choose-result" id="J_chooseResult">
                    <a  data-gid="2164200001" href="<?php echo e(url('cart')); ?>" class="buy btn  btn-primary ">立即购买</a>
                    <a  data-gid="2164200001" class="collect btn  btn-primary ">收藏</a>
                </div>
                <div class="pro-choose-result hide" id="J_chooseResultInit">
                    <a href="javascript:void(0);" class="btn btn-dakeLight" data-stat-id="7326452943dc03b6" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-7326452943dc03b6', 'javascript:void(0);', 'pcpid']);">下一步</a>
                    <!-- <span class="next-desc">请选择商品</span> -->
                </div>
            </div>
            <!-- pro-info END -->
        </div>
        <!-- pro-choose_main End-->
    </div>
    <!-- bd END -->
</div>
<!-- buy-choose-box END -->


<!-- bar -->
<div class="header-bar" id="J_headerBar">
    <div class="container">
        <span class="pro-desc" id="J_headerBarDesc">小米Note 2 标准版 4GB内存+64GB容量 亮黑色 2799元</span><a href="javascript:void(0)" class="btn btn-primary" data-stat-id="081b10ad0061e9de" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-081b10ad0061e9de', 'javascript:void(0)', 'pcpid']);">立即购买</a>
    </div>
</div>

<!-- 视频 弹窗 -->
<div class="modal modal-hide fade modal-video" id="J_showVideo">
    <span data-dismiss="modal" aria-hidden="true" class="close"><i class="iconfont"></i></span>
    <div class="modal-header">
        <h3>&nbsp;</h3>
    </div>
    <div class="modal-body"></div>
</div>







<!-- 保险弹窗 -->
<!-- 保险弹窗 -->
<div class="modal in modal-hide modal-baoxian" id="baoxian">
    <div class="modal-header">
        <h3>小米手机意外保障服务</h3>
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
    </div>
    <div class="modal-body">
        <div class="con-1">
            <h4>购买保购障服务的手机在意外受损时可获得免费维修</h4>
            <ul class="icon-list clearfix">
                <li>
                    <span class="icon icon-1"></span>
                    屏幕碎裂免费换新屏
                </li>
                <li>
                    <span class="icon icon-2"></span>
                    进水、摔落免费修
                </li>
                <li>
                    <span class="icon icon-3"></span>
                    修好为止
                </li>
            </ul>
            <dl class="xuzhi">
                <dt>为保障您的权益，购买前请仔细阅读：</dt>
                <dd>· 本保障服务目前仅适用于小米手机用户，仅可随手机一起在线购买。</dd>
                <dd>· 本保障服务自您收到手机起生效，有效期为一年，若您在收到手机7日内需要取消保障服务，请连同手机一起申请退货。</dd>
                <dd>· 故意行为导致的手机损坏以及盗窃、抢劫、遗失手机等不在服务保障范围内（具体以小米手机意外保障服务条款为准）。<br>
                    <a href="http://cart.mi.com/static/insuranceAgreement.php?type=" target="_blank" class="J_baoxianMore" data-stat-id="618f0738281f9446" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-618f0738281f9446', '//cart.mi.com/static/insuranceAgreement.php', 'pcpid']);">了解《小米手机意外保障服务》详细条款&gt;</a>
                </dd>
            </dl>
        </div>
    </div>
    <div class="modal-footer clearfix">
        <a class="btn btn-primary" data-dismiss="modal" aria-hidden="true" data-stat-id="70b1dab01f0212bb" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-70b1dab01f0212bb', '', 'pcpid']);">确认</a>
    </div>
</div>


<div class="modal fade  modal-hide modal-bigtap-tip" id="J_modalBigtapTip">
    <div class="modal-header">
        <h3>温馨提示</h3>
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
    </div>
    <div class="modal-body">
         
    </div>
    <div class="modal-footer clearfix">
        <a class="btn btn-primary" data-dismiss="modal" aria-hidden="true" data-stat-id="2d63fe270ff4b9d4" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-2d63fe270ff4b9d4', '', 'pcpid']);">确定</a>
    </div>
</div>
 
<div class="site-footer">
    <div class="container">
        <div class="footer-service">
            <ul class="list-service clearfix">
                            <li><a rel="nofollow" href="http://www.mi.com/static/fast/" target="_blank" data-stat-id="46873828b7b782f4" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-46873828b7b782f4', '//www.mi.com/static/fast/', 'pcpid']);"><i class="iconfont"></i>预约维修服务</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/service/exchange#back" target="_blank" data-stat-id="78babcae8a619e26" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-78babcae8a619e26', '//www.mi.com/service/exchange#back', 'pcpid']);"><i class="iconfont"></i>7天无理由退货</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/service/exchange#free" target="_blank" data-stat-id="d1745f68f8d2dad7" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-d1745f68f8d2dad7', '//www.mi.com/service/exchange#free', 'pcpid']);"><i class="iconfont"></i>15天免费换货</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/service/exchange#mail" target="_blank" data-stat-id="f1b5c2451cf73123" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-f1b5c2451cf73123', '//www.mi.com/service/exchange#mail', 'pcpid']);"><i class="iconfont"></i>满150元包邮</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/static/maintainlocation/" target="_blank" data-stat-id="b57397dd7ad77a31" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-b57397dd7ad77a31', '//www.mi.com/static/maintainlocation/', 'pcpid']);"><i class="iconfont"></i>520余家售后网点</a></li>
                        </ul>
        </div>
        <div class="footer-links clearfix">
            
            <dl class="col-links col-links-first">
                    <dt>友情链接</dt>
                    
                    <dd><a rel="nofollow" href="www.baidu.com" onclick="_msq.push">百度</a></dd>
                    
                    <dd><a rel="nofollow" href="www.taobao.com" onclick="_msq.push">淘宝</a></dd>
                    
                    <dd><a rel="nofollow" href="www.tengxun.com" onclick="_msq.push">腾讯</a></dd>                
                </dl>
                
            <div class="col-contact">
                <p class="phone">400-100-5678</p>
<p><span class="J_serviceTime-normal" style="
">周一至周日 8:00-18:00</span>
<span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
<a rel="nofollow" class="btn btn-line-primary btn-small" href="http://www.mi.com/service/contact" target="_blank" data-stat-id="a7642f0a3475d686" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-a7642f0a3475d686', '//www.mi.com/service/contact', 'pcpid']);"><i class="iconfont"></i> 24小时在线客服</a>            </div>
        </div>
    </div>
</div>
<div class="site-info">
    <div class="container">
        <div class="info-text">
            <p><a href="http://www.mi.com/index.html" target="_blank" data-stat-id="b9017a4e9e9eefe3" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-b9017a4e9e9eefe3', '//www.mi.com/index.html', 'pcpid']);">小米商城</a><span class="sep">|</span><a href="http://www.miui.com/" target="_blank" data-stat-id="ed2a0e25c8b0ca2f" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-ed2a0e25c8b0ca2f', 'http://www.miui.com/', 'pcpid']);">MIUI</a><span class="sep">|</span><a href="http://www.miliao.com/" target="_blank" data-stat-id="826b32c1478a98d5" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-826b32c1478a98d5', 'http://www.miliao.com/', 'pcpid']);">米聊</a><span class="sep">|</span><a href="http://www.duokan.com/" target="_blank" data-stat-id="c9d2af1ad828a834" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-c9d2af1ad828a834', 'http://www.duokan.com/', 'pcpid']);">多看书城</a><span class="sep">|</span><a href="http://www.miwifi.com/" target="_blank" data-stat-id="96f1a8cecc909af2" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-96f1a8cecc909af2', 'http://www.miwifi.com/', 'pcpid']);">小米路由器</a><span class="sep">|</span><a href="http://call.mi.com/" target="_blank" data-stat-id="347f6dd0d8d9fda3" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-347f6dd0d8d9fda3', 'http://call.mi.com/', 'pcpid']);">视频电话</a><span class="sep">|</span><a href="http://blog.xiaomi.com/" target="_blank" data-stat-id="4ad42379062eda19" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-4ad42379062eda19', 'http://blog.xiaomi.com/', 'pcpid']);">小米后院</a><span class="sep">|</span><a href="http://xiaomi.tmall.com/" target="_blank" data-stat-id="dfe0fac59cfb15d9" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-dfe0fac59cfb15d9', 'http://xiaomi.tmall.com/', 'pcpid']);">小米天猫店</a><span class="sep">|</span><a href="http://shop115048570.taobao.com/" target="_blank" data-stat-id="c2613d0d3b77ddff" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-c2613d0d3b77ddff', 'http://shop115048570.taobao.com', 'pcpid']);">小米淘宝直营店</a><span class="sep">|</span><a href="http://union.mi.com/" target="_blank" data-stat-id="2f48f953961c637d" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-2f48f953961c637d', 'http://union.mi.com/', 'pcpid']);">小米网盟</a><span class="sep">|</span><a href="http://static.mi.com/feedback/" target="_blank" data-stat-id="6479cd2d041bcf04" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-6479cd2d041bcf04', '//static.mi.com/feedback/', 'pcpid']);">问题反馈</a><span class="sep">|</span><a href="#J_modal-globalSites" target="_blank" data-stat-id="9db137a8e0d5b3dd" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-9db137a8e0d5b3dd', '#J_modal-globalSites', 'pcpid']);">Select Region</a>            </p>
            <p>©<a href="http://www.mi.com/" target="_blank" title="mi.com" data-stat-id="836cacd9ca5b75dd" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-836cacd9ca5b75dd', '//www.mi.com/', 'pcpid']);">mi.com</a> 京ICP证110507号 <a href="http://www.miitbeian.gov.cn/" target="_blank" rel="nofollow" data-stat-id="f96685804376361a" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-f96685804376361a', 'http://www.miitbeian.gov.cn/', 'pcpid']);">京ICP备10046444号</a> <a rel="nofollow" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134" target="_blank" data-stat-id="57efc92272d4336b" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-57efc92272d4336b', 'http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134', 'pcpid']);">京公网安备11010802020134号 </a><a rel="nofollow" href="http://c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg" target="_blank" data-stat-id="c5f81675b79eb130" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-c5f81675b79eb130', '//c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg', 'pcpid']);">京网文[2014]0059-0009号</a>

<br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</p>
        </div>
        <div class="info-links">
                    <a href="http://privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn" target="_blank" data-stat-id="de920be99941f792" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-de920be99941f792', '//privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn', 'pcpid']);"><img src="" alt="TRUSTe Privacy Certification"></a>
                    <a href="http://search.szfw.org/cert/l/CX20120926001783002010" target="_blank" data-stat-id="d44905018f8d7096" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-d44905018f8d7096', '//search.szfw.org/cert/l/CX20120926001783002010', 'pcpid']);"><img src="" alt="诚信网站"></a>
                    <a href="https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082" target="_blank" data-stat-id="3e1533699f264eac" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-3e1533699f264eac', 'https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082', 'pcpid']);"><img src="" alt="可信网站"></a>
                    <a href="http://www.315online.com.cn/member/315140007.html" target="_blank" data-stat-id="b085e50c7ec83104" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-b085e50c7ec83104', 'http://www.315online.com.cn/member/315140007.html', 'pcpid']);"><img src="" alt="网上交易保障中心"></a>
                </div>
    </div>
    <div class="slogan ir">探索黑科技，小米为发烧而生</div>
</div>
<!-- .site-footer END -->
<div id="J_modalWeixin" class="modal fade modal-hide modal-weixin" data-width="480" data-height="520">
        <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="cfd3189b8a874ba4" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-cfd3189b8a874ba4', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">小米手机官方微信二维码</span>
        </div>
        <div class="modal-bd">
            <p style="margin: 0 0 10px;">打开微信，点击右上角的“+”，选择“扫一扫”功能，<br>对准下方二维码即可。</p>
            <img alt="" src="" width="375" height="375">
        </div>
    </div>
<!-- .modal-weixin END -->
<div class="modal modal-hide modal-bigtap-queue" id="J_bigtapQueue">
    <div class="modal-body">
        <span class="close" data-dismiss="modal" aria-hidden="true">退出排队</span>
        <div class="con">
            <div class="title">正在排队，请稍候喔！</div>
            <div class="queue-tip-box">
                <p class="queue-tip">当前人数较多，请您耐心等待，排队期间请不要关闭页面。</p>
                <p class="queue-tip">时常来官网看看，最新产品和活动信息都会在这里发布。</p>
                <p class="queue-tip">下载小米商城 App 玩玩吧！产品开售信息抢先知道。</p>
                <p class="queue-tip">发现了让你眼前一亮的小米产品，别忘了分享给朋友！</p>
                <p class="queue-tip">产品开售前会有预售信息，关注官网首页就不会错过。</p>
            </div>
        </div>

        <div class="queue-posters">
            <div class="poster poster-3"></div>
            <div class="poster poster-2"></div>
            <div class="poster poster-1"></div>
            <div class="poster poster-4"></div>
            <div class="poster poster-5"></div>
        </div>
    </div>
</div>
<!-- .xm-dm-queue END -->
<div id="J_bigtapError" class="modal modal-hide modal-bigtap-error">
    <span class="close" data-dismiss="modal" aria-hidden="true"><i class="iconfont"></i></span>
    <div class="modal-body">
        <h3>抱歉，网络拥堵无法连接服务器</h3>
        <p class="error-tip">由于访问人数太多导致服务器压力山大，请您稍后再重试。</p>
        <p>
            <a class="btn btn-primary" id="J_bigtapRetry" data-stat-id="c148a4197491d5bd" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-c148a4197491d5bd', '', 'pcpid']);">重试</a>
        </p>
    </div>
</div>


<div id="J_bigtapModeBox" class="modal fade modal-hide modal-bigtap-mode">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body">
            <h3 class="title">为防黄牛，请您输入下面的验证码</h3>
             <p class="desc">在防黄牛的路上，我们一直在努力，也知道做的还不够。<br>
    所以，这次劳烦您多输一次验证码，我们一起防黄牛。</p>
            <div class="mode-loading" id="J_bigtapModeLoading">
                <img src="" alt="" width="32" height="32">
                <a id="J_bigtapModeReload" class="reload  hide" href="javascript:void(0);" data-stat-id="ce9e5bb5b994ad55" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-ce9e5bb5b994ad55', 'javascript:void(0);', 'pcpid']);">网络错误，点击重新获取验证码！</a>
            </div>
            <div class="mode-action hide" id="J_bigtapModeAction">
                <div class="mode-con" id="J_bigtapModeContent"></div>
                <input name="bigtapmode" class="input-text" id="J_bigtapModeInput" placeholder="请输入正确的验证码" type="text">
                <p class="tip" id="J_bigtapModeTip"></p>
                <a class="btn  btn-gray" id="J_bigtapModeSubmit" data-stat-id="7f083d6abed714f8" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-7f083d6abed714f8', '', 'pcpid']);">确认</a>
            </div>
        </div>
    </div>

<div id="J_bigtapSoldout" class="modal fade modal-hide modal-bigtap-soldout modal-bigtap-soldout-norec">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body ">
            <div class="content clearfix">
                <span class="mitu"></span>
                <p class="title">很抱歉，人真是太多了<br>您晚了一步...</p>
            </div>

            <div class="bigtap-recomment-goods">
                <div class="hd"><span>这些产品也不错，而且有现货哦！</span></div>
                <ul class="clearfix" id="J_bigtapRecommentList"></ul>
            </div>
        </div>
    </div>
<!-- .xm-dm-error END -->
<div id="J_modal-globalSites" class="modal fade modal-hide modal-globalSites" data-width="640">
       <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="d63900908fde14b1" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-d63900908fde14b1', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">Select Region</span>
        </div>
        <div class="modal-bd">
            <h3>Welcome to Mi.com</h3>
            <p class="modal-globalSites-tips">Please select your country or region</p>
            <p class="modal-globalSites-links clearfix">
                <a href="http://www.mi.com/index.html" data-stat-id="51fe807618ae85f4" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-51fe807618ae85f4', '//www.mi.com/index.html', 'pcpid']);">Mainland China</a>
                <a href="http://www.mi.com/hk/" data-stat-id="d8e4264197de1747" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-d8e4264197de1747', 'http://www.mi.com/hk/', 'pcpid']);">Hong Kong</a>
                <a href="http://www.mi.com/tw/" data-stat-id="8b54359fb6116e28" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-8b54359fb6116e28', 'http://www.mi.com/tw/', 'pcpid']);">Taiwan</a>
                <a href="http://www.mi.com/sg/" data-stat-id="e9c0506f7e4e7161" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-e9c0506f7e4e7161', 'http://www.mi.com/sg/', 'pcpid']);">Singapore</a>
                <a href="http://www.mi.com/my/" data-stat-id="d6299ad30ec761a8" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-d6299ad30ec761a8', 'http://www.mi.com/my/', 'pcpid']);">Malaysia</a>
                <a href="http://www.mi.com/ph/" data-stat-id="22b601cf7b3ada84" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-22b601cf7b3ada84', 'http://www.mi.com/ph/', 'pcpid']);">Philippines</a>
                <a href="http://www.mi.com/in/" data-stat-id="441d26d4571e10dc" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-441d26d4571e10dc', 'http://www.mi.com/in/', 'pcpid']);">India</a>
                <a href="http://www.mi.com/id/" data-stat-id="88ccf9755c488ec5" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-88ccf9755c488ec5', 'http://www.mi.com/id/', 'pcpid']);">Indonesia</a>
                <a href="http://br.mi.com/" data-stat-id="c41d871bf5ddcd95" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-c41d871bf5ddcd95', 'http://br.mi.com/', 'pcpid']);">Brasil</a>
                <a href="http://www.mi.com/en/" data-stat-id="4426c5dac474df5f" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-4426c5dac474df5f', 'http://www.mi.com/en/', 'pcpid']);">Global Home</a>
                <a href="http://www.mi.com/mena/" data-stat-id="261bb8cf155fb56b" onclick="_msq.push(['trackEvent', '6efef01ea0e85562-261bb8cf155fb56b', 'http://www.mi.com/mena/', 'pcpid']);"> MENA</a>
            </p>
        </div>
    </div>


</body></html>