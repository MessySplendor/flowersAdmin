	<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN"><head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	// 
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta charset="UTF-8">
	<title>我的购物车-小米商城</title>
	<meta name="viewport" content="width=1226">
	<!-- <link rel="shortcut icon" href="" type="image/x-icon"> -->
	<link rel="icon" href="" type="image/x-icon">
	<link rel="stylesheet" href="<?php echo e(asset('homes/cart/base.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('homes/cart/cart.css')); ?>">
	<script type="text/javascript" async="" src="<?php echo e(asset('homes/cart/xmst.js')); ?>"></script>
	<script type="text/javascript">var _head_over_time = (new Date()).getTime();</script>
	<script src="<?php echo e(asset('homes/cart/userInfoJsonP.htm')); ?>" type="text/javascript" async=""></script></head>
	<body>
	    <div class="site-header site-mini-header">
	        <div class="container">
	            <div class="header-logo">
	                <a class="logo ir" href="" title="小米官网" data-stat-id="f4006c1551f77f22" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-f4006c1551f77f22', 'pcpid']);">小米官网</a>
	            </div>
	            <div class="header-title has-more" id="J_miniHeaderTitle"><h2>我的购物车</h2><p>温馨提示：产品是否购买成功，以最终下单为准哦，请尽快结算</p></div>
	        <?php if(session('homeuser') != null): ?>
	            <div class="topbar-info" id="J_userInfo"><span class="user"><a rel="nofollow" class="user-name" href="" target="_blank" data-stat-id="3297450e3f6d14da" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-3297450e3f6d14da', '//my.mi.com/portal', 'pcpid']);"><span class="name"><?php echo e(session('homeuser')->det_nicheng); ?></span><i class="iconfont"></i></a><ul class="user-menu" style="display: none;"><li><a rel="nofollow" href="http://my.mi.com/portal" target="_blank" data-stat-id="e0b9e1d1fa8052a2" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-e0b9e1d1fa8052a2', '//my.mi.com/portal', 'pcpid']);">个人中心</a></li><li><a rel="nofollow" href="http://order.mi.com/user/comment" target="_blank" data-stat-id="6d05445058873c2c" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-6d05445058873c2c', '//order.mi.com/user/comment', 'pcpid']);">评价晒单</a></li><li><a rel="nofollow" href="http://order.mi.com/user/favorite" target="_blank" data-stat-id="32e2967e9a749d3d" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-32e2967e9a749d3d', '//order.mi.com/user/favorite', 'pcpid']);">我的喜欢</a></li><li><a rel="nofollow" href="" target="_blank" data-stat-id="6c2aba14bc7f649a" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-6c2aba14bc7f649a', 'http://account.xiaomi.com/', 'pcpid']);">小米账户</a></li><li><a rel="nofollow" href="" data-stat-id="770a31519c713b11" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-770a31519c713b11', '//order.mi.com/site/logout', 'pcpid']);">退出登录</a></li></ul></span><span class="sep">|</span><a rel="nofollow" class="link link-order" href="" target="_blank" data-stat-id="a9e9205e73f0742c" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-a9e9205e73f0742c', '//static.mi.com/order/', 'pcpid']);">我的订单</a></div>
	            <?php else: ?>
	            <div id="J_userInfo" class="topbar-info">
	                <a class="link" href="<?php echo e(url('home/login')); ?>" data-needlogin="true" data-stat-id="bf3aa4c80c0ac789" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-bf3aa4c80c0ac789', '//order.mi.com/site/login', 'pcpid']);">登录</a>
	                <span class="sep">|</span>
	                <a class="link" href="" data-stat-id="749b1369201c13fb" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-749b1369201c13fb', 'https://account.xiaomi.com/pass/register', 'pcpid']);">注册</a>
	            </div>
	            <?php endif; ?>
	        </div>
	    </div>	


		<div class="page-main">
			<div id="J_cartEmpty" class="cart-empty cart-empty-nologin">
			<h2>您的购物车还是空的！</h2>
			<p class="login-desc">登录后将显示您之前加入的商品</p>
			<a id="J_loginBtn" class="btn btn-primary btn-login" href="<?php echo e(asset('/home/login')); ?>" data-stat-id="981e88d70784e360" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-981e88d70784e360', '//order.mi.com/site/login', 'pcpid']);">立即登录</a>
			<a class="btn btn-primary btn-shoping J_goShoping" href="<?php echo e(asset('/home')); ?>" data-stat-id="4658a7dfd89505fc" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-4658a7dfd89505fc', '//list.mi.com/0', 'pcpid']);">马上去购物</a>
			</div>
		</div>

		<div class="cart-recommend container xm-carousel-container" id="J_miHistoryBox">
		<h2 class="xm-recommend-title"><span>您还看了</span></h2>
		<div class="xm-recommend">
			<div class="xm-carousel-wrapper" style="height: 320px; overflow: hidden;">
				<ul class="xm-carousel-col-5-list xm-carousel-list clearfix" data-carousel-list="true" style="width: 1984px; margin-left: 0px; transition: margin-left 0.5s ease 0s;">
				 <li class="J_xm-recommend-list">  <dl> <dt> 
				 <a href="" data-stat-method="1_0" data-stat-index="0" data-stat-text="小米蓝牙耳机青春版" target="_blank" data-stat-pid="stat_购物车.您还看了_0_1_0" data-stat-aid="小米蓝牙耳机青春版" data-stat-id="小米蓝牙耳机青春版+stat_购物车.您还看了_0_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米蓝牙耳机青春版+stat_购物车.您还看了_0_1_0', '//item.mi.com/1163700019.html', 'pcpid']);">
				  <img src="pms_1478248721.jpg" srcset="pms_1478248721.42297795.jpg?width=280&amp;height=280 2x" alt="小米蓝牙耳机青春版"> </a> </dt> 
				  <dd class="xm-recommend-name"> <a href="http://item.mi.com/1163700019.html" data-stat-method="1_0" data-stat-index="0" data-stat-text="小米蓝牙耳机青春版" target="_blank" data-stat-pid="stat_购物车.您还看了_0_1_0" data-stat-aid="小米蓝牙耳机青春版" data-stat-id="小米蓝牙耳机青春版+stat_购物车.您还看了_0_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米蓝牙耳机青春版+stat_购物车.您还看了_0_1_0', '//item.mi.com/1163700019.html', 'pcpid']);"> 小米蓝牙耳机青春版 </a> </dd> 
				  <dd class="xm-recommend-price">59元</dd> 
				  <dd class="xm-recommend-tips">   </dd> 
				  <dd class="xm-recommend-notice"></dd> </dl>  </li> 
				  <li class="J_xm-recommend-list">  <dl> <dt> 
				  <a href="" data-stat-method="1_0" data-stat-index="1" data-stat-text="小米圈铁耳机Pro" target="_blank" data-stat-pid="stat_购物车.您还看了_1_1_0" data-stat-aid="小米圈铁耳机Pro" data-stat-id="小米圈铁耳机Pro+stat_购物车.您还看了_1_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米圈铁耳机Pro+stat_购物车.您还看了_1_1_0', '//item.mi.com/1164300015.html', 'pcpid']);"> 
				  <img src="pms_1478510064.jpg" srcset="//i1.mifile.cn/a1/pms_1478510064.36397738.jpg?width=280&amp;height=280 2x" alt="小米圈铁耳机Pro"> </a> </dt> 
				  <dd class="xm-recommend-name"> 
				  <a href="" data-stat-method="1_0" data-stat-index="1" data-stat-text="小米圈铁耳机Pro" target="_blank" data-stat-pid="stat_购物车.您还看了_1_1_0" data-stat-aid="小米圈铁耳机Pro" data-stat-id="小米圈铁耳机Pro+stat_购物车.您还看了_1_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米圈铁耳机Pro+stat_购物车.您还看了_1_1_0', '//item.mi.com/1164300015.html', 'pcpid']);"> 小米圈铁耳机Pro </a> </dd> 
				  <dd class="xm-recommend-price">149元</dd> 
				  <dd class="xm-recommend-tips">   </dd> 
				  <dd class="xm-recommend-notice"></dd> </dl>  </li> 
				  <li class="J_xm-recommend-list">  <dl> <dt> 
				  <a href="" data-stat-method="1_0" data-stat-index="2" data-stat-text="iHealth智能血压计（蓝牙版）" target="_blank" data-stat-pid="stat_购物车.您还看了_2_1_0" data-stat-aid="iHealth智能血压计（蓝牙版）" data-stat-id="iHealth智能血压计（蓝牙版）+stat_购物车.您还看了_2_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-iHealth智能血压计（蓝牙版）+stat_购物车.您还看了_2_1_0', '//item.mi.com/1153900039.html', 'pcpid']);"> 
				  <img src="T17FCQByWv1RXrhCrK.jpg" srcset="//i1.mifile.cn/a1/T17FCQByWv1RXrhCrK.jpg?width=280&amp;height=280 2x" alt="iHealth智能血压计（蓝牙版）"> </a> </dt> 
				  <dd class="xm-recommend-name"> 
				  <a href="" data-stat-method="1_0" data-stat-index="2" data-stat-text="iHealth智能血压计（蓝牙版）" target="_blank" data-stat-pid="stat_购物车.您还看了_2_1_0" data-stat-aid="iHealth智能血压计（蓝牙版）" data-stat-id="iHealth智能血压计（蓝牙版）+stat_购物车.您还看了_2_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-iHealth智能血压计（蓝牙版）+stat_购物车.您还看了_2_1_0', '//item.mi.com/1153900039.html', 'pcpid']);"> iHealth智能血压计（蓝牙版） </a> </dd> 
				  <dd class="xm-recommend-price">199元</dd> 
				  <dd class="xm-recommend-tips">   </dd> 
				  <dd class="xm-recommend-notice"></dd> </dl>  </li> 
				  <li class="J_xm-recommend-list">  <dl> <dt> 
				  <a href="" data-stat-method="1_0" data-stat-index="3" data-stat-text="米家压力IH电饭煲" target="_blank" data-stat-pid="stat_购物车.您还看了_3_1_0" data-stat-aid="米家压力IH电饭煲" data-stat-id="米家压力IH电饭煲+stat_购物车.您还看了_3_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-米家压力IH电饭煲+stat_购物车.您还看了_3_1_0', '//item.mi.com/1161200060.html', 'pcpid']);"> 
				  <img src="T1OVC_ByY_1RXrhCrK.jpg" srcset="//i1.mifile.cn/a1/T1OVC_ByY_1RXrhCrK.jpg?width=280&amp;height=280 2x" alt="米家压力IH电饭煲"> </a> </dt> <dd class="xm-recommend-name"> <a href="http://item.mi.com/1161200060.html" data-stat-method="1_0" data-stat-index="3" data-stat-text="米家压力IH电饭煲" target="_blank" data-stat-pid="stat_购物车.您还看了_3_1_0" data-stat-aid="米家压力IH电饭煲" data-stat-id="米家压力IH电饭煲+stat_购物车.您还看了_3_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-米家压力IH电饭煲+stat_购物车.您还看了_3_1_0', '//item.mi.com/1161200060.html', 'pcpid']);"> 米家压力IH电饭煲 </a> </dd> <dd class="xm-recommend-price">999元</dd> <dd class="xm-recommend-tips">   </dd> <dd class="xm-recommend-notice"></dd> </dl>  </li> <li class="J_xm-recommend-list">  <dl> <dt> <a href="http://item.mi.com/1152900009.html" data-stat-method="1_0" data-stat-index="4" data-stat-text="小米净水器（厨上式）" target="_blank" data-stat-pid="stat_购物车.您还看了_4_1_0" data-stat-aid="小米净水器（厨上式）" data-stat-id="小米净水器（厨上式）+stat_购物车.您还看了_4_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米净水器（厨上式）+stat_购物车.您还看了_4_1_0', '//item.mi.com/1152900009.html', 'pcpid']);"> <img src="%E6%88%91%E7%9A%84%E8%B4%AD%E7%89%A9%E8%BD%A6-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/T1vJE_Bv_T1RXrhCrK.jpg" srcset="//i1.mifile.cn/a1/T1vJE_Bv_T1RXrhCrK.jpg?width=280&amp;height=280 2x" alt="小米净水器（厨上式）"> </a> </dt> <dd class="xm-recommend-name"> <a href="http://item.mi.com/1152900009.html" data-stat-method="1_0" data-stat-index="4" data-stat-text="小米净水器（厨上式）" target="_blank" data-stat-pid="stat_购物车.您还看了_4_1_0" data-stat-aid="小米净水器（厨上式）" data-stat-id="小米净水器（厨上式）+stat_购物车.您还看了_4_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米净水器（厨上式）+stat_购物车.您还看了_4_1_0', '//item.mi.com/1152900009.html', 'pcpid']);"> 小米净水器（厨上式） </a> </dd> <dd class="xm-recommend-price">1299元</dd> <dd class="xm-recommend-tips">   </dd> <dd class="xm-recommend-notice"></dd> </dl>  </li> <li class="J_xm-recommend-list">  <dl> <dt> <a href="http://item.mi.com/1161200011.html" data-stat-method="1_0" data-stat-index="5" data-stat-text="小米圈铁耳机" target="_blank" data-stat-pid="stat_购物车.您还看了_5_1_0" data-stat-aid="小米圈铁耳机" data-stat-id="小米圈铁耳机+stat_购物车.您还看了_5_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米圈铁耳机+stat_购物车.您还看了_5_1_0', '//item.mi.com/1161200011.html', 'pcpid']);"> <img src="%E6%88%91%E7%9A%84%E8%B4%AD%E7%89%A9%E8%BD%A6-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/pms_1467184989.jpg" srcset="//i1.mifile.cn/a1/pms_1467184989.74561304.jpg?width=280&amp;height=280 2x" alt="小米圈铁耳机"> </a> </dt> <dd class="xm-recommend-name"> <a href="http://item.mi.com/1161200011.html" data-stat-method="1_0" data-stat-index="5" data-stat-text="小米圈铁耳机" target="_blank" data-stat-pid="stat_购物车.您还看了_5_1_0" data-stat-aid="小米圈铁耳机" data-stat-id="小米圈铁耳机+stat_购物车.您还看了_5_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米圈铁耳机+stat_购物车.您还看了_5_1_0', '//item.mi.com/1161200011.html', 'pcpid']);"> 小米圈铁耳机 </a> </dd> <dd class="xm-recommend-price">99元</dd> <dd class="xm-recommend-tips">   </dd> <dd class="xm-recommend-notice"></dd> </dl>  </li> <li class="J_xm-recommend-list">  <dl> <dt> <a href="http://item.mi.com/1160800067.html" data-stat-method="1_0" data-stat-index="6" data-stat-text="小米净水器（厨下式）" target="_blank" data-stat-pid="stat_购物车.您还看了_6_1_0" data-stat-aid="小米净水器（厨下式）" data-stat-id="小米净水器（厨下式）+stat_购物车.您还看了_6_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米净水器（厨下式）+stat_购物车.您还看了_6_1_0', '//item.mi.com/1160800067.html', 'pcpid']);"> <img src="%E6%88%91%E7%9A%84%E8%B4%AD%E7%89%A9%E8%BD%A6-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/T1hMK_BjEv1RXrhCrK.jpg" srcset="//i1.mifile.cn/a1/T1hMK_BjEv1RXrhCrK.jpg?width=280&amp;height=280 2x" alt="小米净水器（厨下式）"> </a> </dt> <dd class="xm-recommend-name"> <a href="http://item.mi.com/1160800067.html" data-stat-method="1_0" data-stat-index="6" data-stat-text="小米净水器（厨下式）" target="_blank" data-stat-pid="stat_购物车.您还看了_6_1_0" data-stat-aid="小米净水器（厨下式）" data-stat-id="小米净水器（厨下式）+stat_购物车.您还看了_6_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米净水器（厨下式）+stat_购物车.您还看了_6_1_0', '//item.mi.com/1160800067.html', 'pcpid']);"> 小米净水器（厨下式） </a> </dd> <dd class="xm-recommend-price">1999元</dd> <dd class="xm-recommend-tips">   </dd> <dd class="xm-recommend-notice"></dd> </dl>  </li> <li class="J_xm-recommend-list">  <dl> <dt> <a href="http://item.mi.com/1164700010.html" data-stat-method="1_0" data-stat-index="7" data-stat-text="小米WiFi放大器 2" target="_blank" data-stat-pid="stat_购物车.您还看了_7_1_0" data-stat-aid="小米WiFi放大器2" data-stat-id="小米WiFi放大器2+stat_购物车.您还看了_7_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米WiFi放大器2+stat_购物车.您还看了_7_1_0', '//item.mi.com/1164700010.html', 'pcpid']);"> <img src="%E6%88%91%E7%9A%84%E8%B4%AD%E7%89%A9%E8%BD%A6-%E5%B0%8F%E7%B1%B3%E5%95%86%E5%9F%8E_files/pms_1481188619.jpg" srcset="//i1.mifile.cn/a1/pms_1481188619.07736357.jpg?width=280&amp;height=280 2x" alt="小米WiFi放大器 2"> </a> </dt> <dd class="xm-recommend-name"> <a href="http://item.mi.com/1164700010.html" data-stat-method="1_0" data-stat-index="7" data-stat-text="小米WiFi放大器 2" target="_blank" data-stat-pid="stat_购物车.您还看了_7_1_0" data-stat-aid="小米WiFi放大器2" data-stat-id="小米WiFi放大器2+stat_购物车.您还看了_7_1_0" onclick="_msq.push(['trackEvent', '08fae3d5cb3abaaf-小米WiFi放大器2+stat_购物车.您还看了_7_1_0', '//item.mi.com/1164700010.html', 'pcpid']);"> 小米WiFi放大器 2 </a> </dd> <dd class="xm-recommend-price">49元</dd> <dd class="xm-recommend-tips">   </dd> <dd class="xm-recommend-notice"></dd> </dl>  </li></ul></div><div class="xm-pagers-wrapper"><ul class="xm-pagers"><li class="pager pager-active"><span class="dot">1</span></li><li class="pager"><span class="dot">2</span></li></ul></div></div></div>
    </div>
</div>
	</body>
</html>