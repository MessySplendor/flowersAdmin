<!DOCTYPE html>
<html xml:lang="zh-CN" lang="zh-CN"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script type="text/javascript" async="" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/unjcV2.js"></script><script type="text/javascript" async="" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/mstr.js"></script><script type="text/javascript" async="" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/jquery.js"></script>
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta charset="UTF-8">
<title>我的收货地址</title>
<meta name="viewport" content="width=1226">
<meta name="description" content="">
<meta name="keywords" content="小米商城">

<link rel="shortcut icon" href="http://s01.mifile.cn/favicon.ico" type="image/x-icon">
<link rel="icon" href="http://s01.mifile.cn/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('homes/myaddress/base.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('homes/myaddress/main.css')); ?>">
</head>
<body>
<div class="site-topbar">
            <div class="container">
                <div class="topbar-nav">
                    <a href="" onclick="_msq.push">小米商城</a>
                        <span class="sep">|</span>
                    <a href="" onclick="_msq.push">MIUI</a>
                </div>
                <div class="topbar-cart" id="J_miniCartTrigger">
                    <a rel="nofollow" class="cart-mini" id="J_miniCartBtn" href="<?php echo e(url('/cart')); ?>"><i class="iconfont">&#xe60c;</i>购物车
                        <span class="cart-mini-num J_cartNum"></span>
                    </a>
                    <div class="cart-menu" id="J_miniCartMenu">
                        <div class="loading"><div class="loader"></div></div>
                    </div>
                </div>
                 <?php if(session('homeuser') != null): ?>
        
                <div class="topbar-info" id="J_userInfo">
                     <a  rel="nofollow" class="link" href="<?php echo e(url('home/myself')); ?>" data-needlogin="true"><?php echo e(session('homeuser')->det_nicheng); ?></a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(url('home/out')); ?>" >退出</a><span class="sep">|</span><a href="<?php echo e(url('home/dingdan')); ?>">我的订单</a>
                </div>
                <?php else: ?>
                <div class="topbar-info" id="J_userInfo">
                    <a  rel="nofollow" class="link" href="<?php echo e(asset('home/login')); ?>" data-needlogin="true">登录</a><span class="sep">|</span><a  rel="nofollow" class="link" href="<?php echo e(asset('home/zhuce')); ?>" >注册</a>
                </div>
                <?php endif; ?>
            </div>
        </div>

<div class="site-header">
<div class="breadcrumbs">
    <div class="container">
        <a href="<?php echo e(url('home')); ?>" data-stat-id="b0bcd814768c68cc" onclick="_msq.push">首页</a><span class="sep">&gt;</span><span>个人中心</span>    </div>
</div>

<div class="page-main user-main">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="uc-box uc-sub-box">
                   <div class="uc-nav-box">
                        <div class="box-hd">
                            <h3 class="title">订单中心</h3>
                        </div>
                        <div class="box-bd">
                            <ul class="uc-nav-list">
                                <li><a href="<?php echo e(url('home/dingdan')); ?>">我的订单</a></li>                              
                            </ul>
                            <ul class="uc-nav-list">
                                <li><a href="<?php echo e(url('home/pj/0')); ?>">评价晒单</a></li>                              
                            </ul>
                        </div>
                    </div>
                    <div class="uc-nav-box">
                        <div class="box-hd">
                            <h3 class="title">个人中心</h3>
                        </div>
                        <div class="box-bd">
                            <ul class="uc-nav-list">
                                <li><a href="<?php echo e(url('home/myself')); ?>">我的个人中心</a></li>                                
                                <li><a href="<?php echo e(url('home/stor')); ?>">代金券</a></li>
                                <li><a href="<?php echo e(url('home/store')); ?>">我的收藏</a></li>
                                <li class="active"><a href="<?php echo e(url('home/myaddress')); ?>">收货地址</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="span16">
			    <div class="uc-box uc-main-box">
			        <div class="uc-content-box">
			            <div class="box-hd">
			                <h1 class="title">收货地址</h1>
			            </div>
			            <div class="box-bd">
			                <div class="user-address-list J_addressList clearfix">
			                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				                <div class="border" style="width:270px;height:190px;border:1px solid #E0E0E0;color:#757575;float:left;margin-left:15px;margin-top:10px">
				                    <dl style="width:140px;float:left;margin-left:20px;margin-top:15px;">
				                        <dd>
				                            <span style="font-size:18px;color:black;font-weight:bold;"><?php echo e($v->name); ?></span>
				                        </dd><br>
				                        <dd>
				                            <span><?php echo e($v->phone); ?></span>
				                        </dd>
				                        <dd>
				                            <span><?php echo e($v->address); ?></span>&nbsp;&nbsp;
				                            <span><?php echo e($v->address_detail); ?></span>                           
				                        </dd>
				                        <dd>
				                            邮编：<span><?php echo e($v->postcode); ?></span>    
				                        </dd>
				                    </dl>
				                    <br>
				                    <div class="actions">
				                        <a class="arise" address_id="<?php echo e($v->address_id); ?>" style="float:right;margin-right:10px;margin-top:150px;"></a>
				                        <a class="delete" href="" address_id="<?php echo e($v->address_id); ?>" style="float:right;margin-right:10px;margin-top:150px;"></a>
				                    </div>
				                </div>
				                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					        	<div style="text-align:center;width:270px;height:190px;border:1px solid #E0E0E0;float:left;margin-left:15px;margin-top:10px;">
			                        <span style="float:left;margin-top:60px;margin-left:100px"><span class="show" style="font-weight:bold;font-size:30px;">+</span><br>添加新地址</span>
			                    </div>
				                
			            	</div> 
<!-- ------------------选择地址弹框 -------------------->
		                    <div class="address-box" style="display:none;position:absolute;left:442px;top:170px;background-color:#FFFFFF;text-align:center;border:1px solid #E0E0E0;width:340px;float:left;">
		                        <form action="<?php echo e(url('home/address')); ?>" method="post">
		                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		                        <div class="box-main">
		                            <div class="form-section">
		                                <input class="input-size J_addressInput" style="margin-top:10px" id="user_name" name="name" placeholder="收货人姓名" type="text">
		                            </div>
		                            <div class="form-section">
		                                <input class="input-size J_addressInput" id="user_phone" name="phone" placeholder="手机号" type="text">
		                            </div>
		                            <div class="form-section form-select-2 clearfix">
		                                <div >
		                                    <div>
		                                        <select class="input-size" id="cid" style="margin-left:19px;" name="address[]" ><option >--请选择--</option></select>
		                                    </div>
		                                </div>
		                            </div>
		                            <div class="address-supp-tip hide" id="J_addressSuppTip">您的收货地址需要补全街道信息</div>
		                            <div class="form-section">
		                                <textarea style="width:80%;margin-left:19px;" class=" J_addressInput" type="text" id="user_adress" name="address_detail" placeholder="详细地址"></textarea>
		                            </div>
		                            <div class="form-section">
		                                <input class="input-size J_addressInput" id="user_zipcode" placeholder="邮政编码" name="postcode" type="text">
		                            </div>
		                        </div>
		                        <div class="form-confirm clearfix">
		                            <button style="background-color:#FA4D03" type="submit" class="btn btn-warning">保存</button>
		                            <a style="background-color:#585858" class="btn btn-gray" id="J_cancel" data-stat-id="51d8900b7a3585e5" >取消</a>
		                        </div>
		                        </form>
		                    </div>
                
<!-- ------------------选择地址弹框 end-------------------->
<!-- ------------------修改地址弹框-------------------->
		                    <div class="address-box set" style="display:none;position:absolute;left:442px;top:170px;background-color:#FFFFFF;text-align:center;border:1px solid #E0E0E0;width:340px;float:left;">
		                        <form action="" method="post">
		                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		                        <div class="box-main">
		                            <div class="form-section">
		                                <input class="input-size J_addressInput" style="margin-top:10px" name="name" value="" type="text">
		                            </div>
		                            <div class="form-section">
		                                <input class="input-size J_addressInput"  name="phone" value="" type="text">
		                            </div>
		                            <div class="form-section">
		                                <input class="input-size J_addressInput" name="address" value="" type="text">
		                            </div>
		                            <div class="form-section">
		                                <textarea style="width:80%;margin-left:19px;" class=" J_addressInput" type="text" id="user_adress" name="address_detail" value=""></textarea>
		                            </div>
		                            <div class="form-section">
		                                <input class="input-size J_addressInput" id="user_zipcode" value="" name="postcode" type="text">
		                            </div>
		                        </div>
		                        <div class="form-confirm clearfix">
		                            <button style="background-color:#FA4D03" type="submit" class="btn btn-warning">修改</button>
		                            <a style="background-color:#585858" class="btn btn-gray" id="cancel" data-stat-id="51d8900b7a3585e5" >取消</a>
		                        </div>
		                        </form>
		                    </div>
<!-- ------------------修改地址弹框 end-------------------->      
			        </div>
			        </div>
			    </div>
    		</div>
		</div>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script>
<script type="text/javascript">
$(function(){
    $('.show').mousedown(function(){
        $('.address-box:first').css('display','');
    });
    $('.border').mousedown(function(){
        $('.border').css('border','1px solid #E0E0E0');
        $(this).css('border','1px solid red');
        $('.arise').text('');
        $('.delete').text('');
        $(this).find('a:eq(0)').text('修改');
        $(this).find('a:eq(1)').text('删除');
        $('#J_confirmAddress span:first').text($(this).find('span:first').text());
        $('#J_confirmAddress span:eq(1)').text($(this).find('span:eq(1)').text());
        $('#J_confirmAddress span:eq(2)').text($(this).find('dd:eq(2)').text());
        var address_id=$(this).find('a:eq(0)').attr('address_id');
        $.ajax({
        url:'<?php echo e(url('/home/defaultadd')); ?>',
        async:true,               
        type:'post',                
        data:{address_id:address_id,_token:'<?php echo e(csrf_token()); ?>'},              
        dataType:'json', 
        
        });
       
    });
//-----------------------删除地址--------------------------//            
    $('.delete').mousedown(function() {
        $(this).css('color','red');
        var address_id=$(this).attr('address_id');
        $.ajax({
        url:'<?php echo e(url('/home/deleteadd')); ?>',
        async:true,               
        type:'post',                
        data:{address_id:address_id,_token:'<?php echo e(csrf_token()); ?>'},              
        dataType:'json', 
        // error:function()            
        // {
        //     alert('ajax请求失败');
        // },
        success:function(data)      
        {
            if(data){
             alert('删除成功');
         }
        }
        });
    });
//----------------------------end---------------------------------//
    var address_id='';
    $('.arise').mousedown(function(){
        $(this).css('color','red');
        $('.set').css('display','');
        $('.set input:eq(1)').attr('value',$(this).parent().prev().prev().children('dd:first').children('span').text());
        $('.set input:eq(2)').attr('value',$(this).parent().prev().prev().children('dd:eq(1)').children('span').text());
        $('.set input:eq(3)').attr('value',$(this).parent().prev().prev().children('dd:eq(2)').children('span:first').text());
        $('.set textarea').text($(this).parent().prev().prev().children('dd:eq(2)').children('span:eq(1)').text());
        $('.set input:eq(4)').attr('value',$(this).parent().prev().prev().children('dd:eq(3)').children('span').text());
        $('.set form').attr('action','<?php echo e(url('home/updateaddress')); ?>'+'/'+$(this).attr('address_id'));
    });

    $('#J_cancel').mousedown(function(){
        $('.address-box:first').css('display','none');
    });
    $('#cancel').mousedown(function(){
        $('.address-box:eq(1)').css('display','none');
    });
// ------------------------------------选择地址ajax----------------------
    $.ajax({
        url:'<?php echo e(url('/home/check')); ?>',
        async:true,               
        type:'post',                
        data:{upid:0,_token:'<?php echo e(csrf_token()); ?>'},              
        dataType:'json',            
        // error:function()
        // {
        //     alert('ajax请求失败');
        // },
        success:function(data)      
        {
            //console.log(data);
            for (var i = 0; i < data.length; i++) {
                $('#cid').append("<option value='"+data[i].id+"'>"+data[i].name+"</option>");
            };
        }
    });

    $("select").live("change",function(){
        //先清除后面的select(清上一次选择的)，再添加新的select
        $(this).nextAll("select").remove();
        //因为下面需要用到当前对象，但是是另一个函数体内，不能用$(this)
        var ob = $(this);
        //判断选择的是不是默认的请选择
        if($(this).val() != '--请选择--'){
            alert(upid);return false;
            $.ajax({
                url:'<?php echo e(url('/home/check')); ?>',
                async:true,                
                type:'post',               
                data:{upid:upid,_token:'<?php echo e(csrf_token()); ?>'},               
                dataType:'json',            
                // error:function()            
                // {
                //     alert('ajax请求失败');
                // },
                success:function(data)      
                {
                    // console.log(data);
                    //判断是否还有数据返回，就是判断是否有下一级信息，没有下一级信息上一级下拉框后面则不会添加新的下拉框
                    if(data.length>0){
                        //新建一个select标签
                        var select = $("<select name='address[]'><option>--请选择--</option></select>");
                        //循环给select标签添加上option
                        for (var i = 0; i < data.length; i++) {
                            //alert(i);
                            $(select).append("<option value='"+data[i].id+"'>"+data[i].name+"</option>");
                            
                        };
                        //追加到前一个select后面
                        ob.after(select);
                    }
                }
            });
        }
    });
// -------------------------------选择地址ajax  end----------------------//
});
</script>
 <style type="text/css">
    .input-size{
        width:80%;
        margin-left:19px;
        height:30px;
    }
    select{
        width:80%;
        margin-left:19px;
        height:30px;
        margin-top:10px;
    }
    
 </style>
		<div id="J_modalEditAddress" class="modal fade modal-hide modal-edit-address">
		    <div class="modal-body">
		        <iframe width="100%" height="100%" frameborder="0"></iframe>
		    </div>
		</div>
        </div>
    </div>
</div>

<div class="site-footer">
    <div class="container">
        <div class="footer-service">
            <ul class="list-service clearfix">
                            <li><a rel="nofollow" href="http://www.mi.com/static/fast/" target="_blank" data-stat-id="46873828b7b782f4" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-46873828b7b782f4', '//www.mi.com/static/fast/', 'pcpid']);"><i class="iconfont"></i>预约维修服务</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/service/exchange#back" target="_blank" data-stat-id="78babcae8a619e26" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-78babcae8a619e26', '//www.mi.com/service/exchange#back', 'pcpid']);"><i class="iconfont"></i>7天无理由退货</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/service/exchange#free" target="_blank" data-stat-id="d1745f68f8d2dad7" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-d1745f68f8d2dad7', '//www.mi.com/service/exchange#free', 'pcpid']);"><i class="iconfont"></i>15天免费换货</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/service/exchange#mail" target="_blank" data-stat-id="f1b5c2451cf73123" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-f1b5c2451cf73123', '//www.mi.com/service/exchange#mail', 'pcpid']);"><i class="iconfont"></i>满150元包邮</a></li>
                            <li><a rel="nofollow" href="http://www.mi.com/static/maintainlocation/" target="_blank" data-stat-id="b57397dd7ad77a31" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-b57397dd7ad77a31', '//www.mi.com/static/maintainlocation/', 'pcpid']);"><i class="iconfont"></i>520余家售后网点</a></li>
                        </ul>
        </div>
        <div class="footer-links clearfix">
            
            <dl class="col-links col-links-first">
                <dt>友情链接</dt>
                
                <dd><a rel="nofollow" href="www.baidu.com" onclick="_msq.push">百度</a></dd>
                
                <dd><a rel="nofollow" href="www.taobao.com" onclick="_msq.push">淘宝</a></dd>
                
                <dd><a rel="nofollow" href="www.tengxun.com" onclick="_msq.push">腾讯</a></dd>                
            </dl>
            <div class="col-contact">
                <p class="phone">400-100-5678</p>
<p><span class="J_serviceTime-normal" style="
">周一至周日 8:00-18:00</span>
<span class="J_serviceTime-holiday" style="display:none;">2月7日至13日服务时间 9:00-18:00</span><br>（仅收市话费）</p>
<a rel="nofollow" class="btn btn-line-primary btn-small" href="http://www.mi.com/service/contact" target="_blank" data-stat-id="a7642f0a3475d686" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-a7642f0a3475d686', '//www.mi.com/service/contact', 'pcpid']);"><i class="iconfont"></i> 24小时在线客服</a>            </div>
        </div>
    </div>
</div>
<div class="site-info">
    <div class="container">
        <div class="logo ir">小米官网</div>
        <div class="info-text">
            <p>小米旗下网站：<a href="http://www.mi.com/index.html" target="_blank" data-stat-id="b9017a4e9e9eefe3" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-b9017a4e9e9eefe3', '//www.mi.com/index.html', 'pcpid']);">小米商城</a><span class="sep">|</span><a href="http://www.miui.com/" target="_blank" data-stat-id="ed2a0e25c8b0ca2f" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-ed2a0e25c8b0ca2f', 'http://www.miui.com/', 'pcpid']);">MIUI</a><span class="sep">|</span><a href="http://www.miliao.com/" target="_blank" data-stat-id="826b32c1478a98d5" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-826b32c1478a98d5', 'http://www.miliao.com/', 'pcpid']);">米聊</a><span class="sep">|</span><a href="http://www.duokan.com/" target="_blank" data-stat-id="c9d2af1ad828a834" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-c9d2af1ad828a834', 'http://www.duokan.com/', 'pcpid']);">多看书城</a><span class="sep">|</span><a href="http://www.miwifi.com/" target="_blank" data-stat-id="96f1a8cecc909af2" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-96f1a8cecc909af2', 'http://www.miwifi.com/', 'pcpid']);">小米路由器</a><span class="sep">|</span><a href="http://call.mi.com/" target="_blank" data-stat-id="347f6dd0d8d9fda3" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-347f6dd0d8d9fda3', 'http://call.mi.com/', 'pcpid']);">视频电话</a><span class="sep">|</span><a href="http://blog.xiaomi.com/" target="_blank" data-stat-id="4ad42379062eda19" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-4ad42379062eda19', 'http://blog.xiaomi.com/', 'pcpid']);">小米后院</a><span class="sep">|</span><a href="http://xiaomi.tmall.com/" target="_blank" data-stat-id="dfe0fac59cfb15d9" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-dfe0fac59cfb15d9', 'http://xiaomi.tmall.com/', 'pcpid']);">小米天猫店</a><span class="sep">|</span><a href="http://shop115048570.taobao.com/" target="_blank" data-stat-id="c2613d0d3b77ddff" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-c2613d0d3b77ddff', 'http://shop115048570.taobao.com', 'pcpid']);">小米淘宝直营店</a><span class="sep">|</span><a href="http://union.mi.com/" target="_blank" data-stat-id="2f48f953961c637d" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-2f48f953961c637d', 'http://union.mi.com/', 'pcpid']);">小米网盟</a><span class="sep">|</span><a href="http://static.mi.com/feedback/" target="_blank" data-stat-id="6479cd2d041bcf04" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-6479cd2d041bcf04', '//static.mi.com/feedback/', 'pcpid']);">问题反馈</a><span class="sep">|</span><a href="#J_modal-globalSites" data-toggle="modal" target="_blank" data-stat-id="9db137a8e0d5b3dd" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-9db137a8e0d5b3dd', '#J_modal-globalSites', 'pcpid']);">Select Region</a>            </p>
            <p>©<a href="http://www.mi.com/" target="_blank" title="mi.com" data-stat-id="836cacd9ca5b75dd" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-836cacd9ca5b75dd', '//www.mi.com/', 'pcpid']);">mi.com</a> 京ICP证110507号 <a href="http://www.miitbeian.gov.cn/" target="_blank" rel="nofollow" data-stat-id="f96685804376361a" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-f96685804376361a', 'http://www.miitbeian.gov.cn/', 'pcpid']);">京ICP备10046444号</a> <a rel="nofollow" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134" target="_blank" data-stat-id="57efc92272d4336b" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-57efc92272d4336b', 'http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802020134', 'pcpid']);">京公网安备11010802020134号 </a><a rel="nofollow" href="http://c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg" target="_blank" data-stat-id="c5f81675b79eb130" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-c5f81675b79eb130', '//c1.mifile.cn/f/i/2013/cn/jingwangwen.jpg', 'pcpid']);">京网文[2014]0059-0009号</a>

<br> 违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</p>
        </div>
        <div class="info-links">
                    <a href="http://privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn" target="_blank" data-stat-id="de920be99941f792" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-de920be99941f792', '//privacy.truste.com/privacy-seal/validation?rid=4fc28a8c-6822-4980-9c4b-9fdc69b94eb8&amp;lang=zh-cn', 'pcpid']);"><img src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/seal.png" alt="TRUSTe Privacy Certification"></a>
                    <a href="http://search.szfw.org/cert/l/CX20120926001783002010" target="_blank" data-stat-id="d44905018f8d7096" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-d44905018f8d7096', '//search.szfw.org/cert/l/CX20120926001783002010', 'pcpid']);"><img src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/v-logo-2.png" alt="诚信网站"></a>
                    <a href="https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082" target="_blank" data-stat-id="3e1533699f264eac" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-3e1533699f264eac', 'https://ss.knet.cn/verifyseal.dll?sn=e12033011010015771301369&amp;ct=df&amp;pa=461082', 'pcpid']);"><img src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/v-logo-1.png" alt="可信网站"></a>
                    <a href="http://www.315online.com.cn/member/315140007.html" target="_blank" data-stat-id="b085e50c7ec83104" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-b085e50c7ec83104', 'http://www.315online.com.cn/member/315140007.html', 'pcpid']);"><img src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/v-logo-3.png" alt="网上交易保障中心"></a>
        
        </div>
    </div>
<div class="slogan ir">探索黑科技，小米为发烧而生</div></div>

<div id="J_modalWeixin" class="modal fade modal-hide modal-weixin" data-width="480" data-height="520">
        <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="cfd3189b8a874ba4" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-cfd3189b8a874ba4', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">小米手机官方微信二维码</span>
        </div>
        <div class="modal-bd">
            <p style="margin: 0 0 10px;">打开微信，点击右上角的“+”，选择“扫一扫”功能，<br>对准下方二维码即可。</p>
            <img alt="" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/qr.png" width="375" height="375">
        </div>
    </div>
<!-- .modal-weixin END -->
<div class="modal modal-hide modal-bigtap-queue" id="J_bigtapQueue">
    <div class="modal-body">
        <span class="close" data-dismiss="modal" aria-hidden="true">退出排队</span>
        <div class="con">
            <div class="title">正在排队，请稍候喔！</div>
            <div class="queue-tip-box">
                <p class="queue-tip">当前人数较多，请您耐心等待，排队期间请不要关闭页面。</p>
                <p class="queue-tip">时常来官网看看，最新产品和活动信息都会在这里发布。</p>
                <p class="queue-tip">下载小米商城 App 玩玩吧！产品开售信息抢先知道。</p>
                <p class="queue-tip">发现了让你眼前一亮的小米产品，别忘了分享给朋友！</p>
                <p class="queue-tip">产品开售前会有预售信息，关注官网首页就不会错过。</p>
            </div>
        </div>

        <div class="queue-posters">
            <div class="poster poster-3"></div>
            <div class="poster poster-2"></div>
            <div class="poster poster-1"></div>
            <div class="poster poster-4"></div>
            <div class="poster poster-5"></div>
        </div>
    </div>
</div>
<!-- .xm-dm-queue END -->
<div id="J_bigtapError" class="modal modal-hide modal-bigtap-error">
    <span class="close" data-dismiss="modal" aria-hidden="true"><i class="iconfont"></i></span>
    <div class="modal-body">
        <h3>抱歉，网络拥堵无法连接服务器</h3>
        <p class="error-tip">由于访问人数太多导致服务器压力山大，请您稍后再重试。</p>
        <p>
            <a class="btn btn-primary" id="J_bigtapRetry" data-stat-id="c148a4197491d5bd" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-c148a4197491d5bd', '', 'pcpid']);">重试</a>
        </p>
    </div>
</div>


<div id="J_bigtapModeBox" class="modal fade modal-hide modal-bigtap-mode">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body">
            <h3 class="title">为防黄牛，请您输入下面的验证码</h3>
             <p class="desc">在防黄牛的路上，我们一直在努力，也知道做的还不够。<br>
    所以，这次劳烦您多输一次验证码，我们一起防黄牛。</p>
            <div class="mode-loading" id="J_bigtapModeLoading">
                <img src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/loading.gif" alt="" width="32" height="32">
                <a id="J_bigtapModeReload" class="reload  hide" href="javascript:void(0);" data-stat-id="ce9e5bb5b994ad55" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-ce9e5bb5b994ad55', 'javascript:void(0);', 'pcpid']);">网络错误，点击重新获取验证码！</a>
            </div>
            <div class="mode-action hide" id="J_bigtapModeAction">
                <div class="mode-con" id="J_bigtapModeContent"></div>
                <input name="bigtapmode" class="input-text" id="J_bigtapModeInput" placeholder="请输入正确的验证码" type="text">
                <p class="tip" id="J_bigtapModeTip"></p>
                <a class="btn  btn-gray" id="J_bigtapModeSubmit" data-stat-id="7f083d6abed714f8" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-7f083d6abed714f8', '', 'pcpid']);">确认</a>
            </div>
        </div>
    </div>

<div id="J_bigtapSoldout" class="modal fade modal-hide modal-bigtap-soldout modal-bigtap-soldout-norec">
        <span class="close" data-dismiss="modal"><i class="iconfont"></i></span>
        <div class="modal-body ">
            <div class="content clearfix">
                <span class="mitu"></span>
                <p class="title">很抱歉，人真是太多了<br>您晚了一步...</p>
            </div>

            <div class="bigtap-recomment-goods">
                <div class="hd"><span>这些产品也不错，而且有现货哦！</span></div>
                <ul class="clearfix" id="J_bigtapRecommentList"></ul>
            </div>
        </div>
    </div>
<!-- .xm-dm-error END -->
<div id="J_modal-globalSites" class="modal fade modal-hide modal-globalSites" data-width="640">
       <div class="modal-hd">
            <a class="close" data-dismiss="modal" data-stat-id="d63900908fde14b1" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-d63900908fde14b1', '', 'pcpid']);"><i class="iconfont"></i></a>
            <span class="title">Select Region</span>
        </div>
        <div class="modal-bd">
            <h3>Welcome to Mi.com</h3>
            <p class="modal-globalSites-tips">Please select your country or region</p>
            <p class="modal-globalSites-links clearfix">
                <a href="http://www.mi.com/index.html" data-stat-id="51fe807618ae85f4" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-51fe807618ae85f4', '//www.mi.com/index.html', 'pcpid']);">Mainland China</a>
                <a href="http://www.mi.com/hk/" data-stat-id="d8e4264197de1747" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-d8e4264197de1747', 'http://www.mi.com/hk/', 'pcpid']);">Hong Kong</a>
                <a href="http://www.mi.com/tw/" data-stat-id="8b54359fb6116e28" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-8b54359fb6116e28', 'http://www.mi.com/tw/', 'pcpid']);">Taiwan</a>
                <a href="http://www.mi.com/sg/" data-stat-id="e9c0506f7e4e7161" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-e9c0506f7e4e7161', 'http://www.mi.com/sg/', 'pcpid']);">Singapore</a>
                <a href="http://www.mi.com/my/" data-stat-id="d6299ad30ec761a8" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-d6299ad30ec761a8', 'http://www.mi.com/my/', 'pcpid']);">Malaysia</a>
                <a href="http://www.mi.com/ph/" data-stat-id="22b601cf7b3ada84" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-22b601cf7b3ada84', 'http://www.mi.com/ph/', 'pcpid']);">Philippines</a>
                <a href="http://www.mi.com/in/" data-stat-id="441d26d4571e10dc" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-441d26d4571e10dc', 'http://www.mi.com/in/', 'pcpid']);">India</a>
                <a href="http://www.mi.com/id/" data-stat-id="88ccf9755c488ec5" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-88ccf9755c488ec5', 'http://www.mi.com/id/', 'pcpid']);">Indonesia</a>
                <a href="http://br.mi.com/" data-stat-id="c41d871bf5ddcd95" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-c41d871bf5ddcd95', 'http://br.mi.com/', 'pcpid']);">Brasil</a>
                <a href="http://www.mi.com/en/" data-stat-id="4426c5dac474df5f" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-4426c5dac474df5f', 'http://www.mi.com/en/', 'pcpid']);">Global Home</a>
                <a href="http://www.mi.com/mena/" data-stat-id="261bb8cf155fb56b" onclick="_msq.push(['trackEvent', '73ce9fb1e71baa17-261bb8cf155fb56b', 'http://www.mi.com/mena/', 'pcpid']);"> MENA</a>
            </p>
        </div>
    </div>
<!-- .modal-globalSites END -->

<script type="text/javascript" async="" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/xmst.js"></script><script src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/base.js"></script>
<script>
(function() {
    MI.namespace('GLOBAL_CONFIG');
    MI.GLOBAL_CONFIG = {
        orderSite: 'http://order.mi.com',
        wwwSite: '//www.mi.com',
        cartSite: '//cart.mi.com',
        itemSite: '//item.mi.com',
        assetsSite: '//s01.mifile.cn',
        listSite: '//list.mi.com',
        searchSite: '//search.mi.com',
        mySite: '//my.mi.com',
        damiaoSite: 'http://tp.hd.mi.com/',
        damiaoGoodsId:[],
        logoutUrl: 'http://order.mi.com/site/logout',
        staticSite: '//static.mi.com',
        quickLoginUrl: 'https://account.xiaomi.com/pass/static/login.html'
    };
    MI.setLoginInfo.orderUrl = MI.GLOBAL_CONFIG.orderSite + '/user/order';
    MI.setLoginInfo.logoutUrl = MI.GLOBAL_CONFIG.logoutUrl;
    MI.setLoginInfo.init(MI.GLOBAL_CONFIG);
    MI.miniCart.init();
    MI.updateMiniCart();
})();
</script>

<script type="text/javascript" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/address.js"></script>
<script type="text/javascript" src="%E6%88%91%E7%9A%84%E6%94%B6%E8%B4%A7%E5%9C%B0%E5%9D%80_files/user.js"></script>

<script>
var _msq = _msq || [];
_msq.push(['setDomainId', 100]);
_msq.push(['trackPageView']);
(function() {
    var ms = document.createElement('script');
    ms.type = 'text/javascript';
    ms.async = true;
    ms.src = '//c1.mifile.cn/f/i/15/stat/js/xmst.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(ms, s);
})();
</script>


</body></html>