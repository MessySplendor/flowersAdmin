<?php $__env->startSection('content'); ?>
<div class="site-header">
	<div class="container">
		<div class="header-logo">
			<a class="logo ir" href="" title="小米官网"  onclick="_msq.push">小米官网</a>
			  <div class="doodle" style="display: block;"></div>
		</div>
			<ul class="nav-list J_navMainList clearfix">
				<!-- 这句中的id会在连接网络是启用网上的左侧列表<li id="J_navCategory" class="nav-category"> -->
				<li id="" class="nav-category">
					<div class="site-category"> 
						<ul id="J_categoryList" class="site-category-list clearfix">
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
							<li class="category-item"> 
								<a class="title" href="<?php echo e(url('home/gde/'.$v->goods_id.'')); ?>" onclick="_msq.push"><?php echo e($v->goods_name); ?></a>
								<div class="children clearfix children-col-3">
									<ul class="children-list children-list-col children-list-col-1">
										<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
										<?php if($v->goods_id==$link->goods_pid): ?>
										<li class="star-goods"> 
											<a class="link" href="<?php echo e(url('home/gde/'.$link->goods_id.'')); ?>" onclick="_msq.push">
												<img class="thumb" src="<?php echo e(asset('/uploads/goods/'.$link->image.'')); ?>" alt="" width="40" height="40">
												<!-- 此处遍历的是轮播图旁边的列表出 -->
												<span class="text"><?php echo e($link->goods_name); ?></span>
												<!-- <span class="text">小米Note 2</span> -->
											</a> 
											<a class="btn btn-line-primary btn-small btn-buy" href="" onclick="_msq.push">选购</a> 
										</li>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
									</ul>
								</div> 
							</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
						</ul>
					</div>
				</li>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li class="nav-item">
				
					<a class="link" href="<?php echo e(url('home/gde/'.$v->goods_id.'')); ?>" onclick="_msq.push">
						<!-- 此处是头部横排分类处 -->
						<span class="text"><?php echo e($v->goods_name); ?></span>
						<span class="arrow">&nbsp;</span>
						
					</a>
					<div class="item-children">
						<div class="container">
							<ul class="children-list clearfix">
								<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<?php if($v->goods_id==$n->goods_pid): ?>
								<li>
									<div class="figure figure-thumb">
										<a href="<?php echo e(url('home/gde/'.$n->goods_id.'')); ?>" onclick="_msq.push ">
											<img src="<?php echo e(asset('/uploads/goods/'.$n->image.'')); ?>" alt="小米MIX" width="160" height="110">
										</a>
									</div>
									<div class="title">
										<a href=""  onclick="_msq.push "><?php echo e($n->goods_name); ?></a>
									</div>
									<p class="price">3499元起</p>
								</li>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</ul>
						</div>
					</div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</ul>
		<div class="header-search">
			<form id="J_searchForm" class="search-form clearfix" action="" method="get">
				<input class="search-text" id="search"  type="search">
				<input class="search-btn iconfont" value="" type="submit">
				<div class="search-hot-words">
					<a href="">小米MIX</a>
					<a href="">人工智能电视</a>
				</div>
				<div id="J_keywordList" class="keyword-list hide">
					<ul class="result-list"></ul>
				</div>
			</form>
		</div>
	</div>
</div>
<div class="home-hero-container container">
	<div class="home-hero">
		<div class="home-hero-slider">
			<div class="ui-viewport" style="width: 100%; overflow: hidden; position: relative; height: 460px;">
				<div id="J_homeSlider" class="xm-slider" data-stat-title="焦点图轮播" style="width: auto; position: relative;">												
					<div class="slide loaded" data-bg-set="{'img':''}" style="float: none; list-style: outside none none; position: absolute; width: 1226px; z-index: 0; display: none;">
						<a href="" data-stat-aid="AA14626" data-stat-pid="2_15_4_70" target="_blank" data-stat-id="AA14626+2_15_4_70" onclick="_msq.push;">
							<img src="<?php echo e(asset('/homes/images/1.jpg')); ?>" srcset=""></a>
					</div>
											
					<div class="slide loaded" data-bg-set="{'img':''}" style="float: none; list-style: outside none none; position: absolute; width: 1226px; z-index: 0; display: none;">
						<a href="" data-stat-aid="AA14641" data-stat-pid="2_15_5_71" target="_blank" data-stat-id="AA14641+2_15_5_71" onclick="_msq.push;">
							<img src="<?php echo e(asset('/homes/images/3.jpg')); ?>" srcset=""></a>
					</div>
				</div>
			</div>
			<div class="ui-controls ui-has-pager ui-has-controls-direction">
				<div class="ui-pager ui-default-pager">
					<div class="ui-pager-item">
						<a href="" data-slide-index="0" class="ui-pager-link active">1</a>
					</div>
					<div class="ui-pager-item">
						<a href="" data-slide-index="1" class="ui-pager-link">2</a>
					</div>
				</div>
				<div class="ui-controls-direction">
					<a class="ui-prev" href="" data-stat-id="76844b8f89037755" onclick="_msq.push(['trackEvent', '79fe2eae924d2a2e-76844b8f89037755', '', 'pcpid']);">上一张</a>
					<a class="ui-next" href="" data-stat-id="2f67a19a4f208791" onclick="_msq.push(['trackEvent', '79fe2eae924d2a2e-2f67a19a4f208791', '', 'pcpid']);">下一张</a>
				</div>
			</div>
		</div>
		

		<div class="home-hero-sub row">
			<div class="span4">
				<ul class="home-channel-list clearfix">
					<li class="top left">
						<a href=""  onclick="_msq.push"><i class="iconfont">?</i>选购手机</a>	
					</li>
					<li class="top left">
						<a href=""  onclick="_msq.push"><i class="iconfont">?</i>选购手机</a>	
					</li>
					<li class="top left">
						<a href=""  onclick="_msq.push"><i class="iconfont">?</i>选购手机</a>	
					</li>
					<li class="top left">
						<a href=""  onclick="_msq.push"><i class="iconfont">?</i>选购手机</a>	
					</li>
					<li class="top left">
						<a href=""  onclick="_msq.push"><i class="iconfont">?</i>选购手机</a>	
					</li>
					<li class="top left">
						<a href=""  onclick="_msq.push"><i class="iconfont">?</i>选购手机</a>	
					</li>
				</ul>
			</div>
			<div class="span16" id="J_homePromo" data-stat-title="焦点图下方小图">
				<ul class="home-promo-list clearfix">
					<li class="first">
						<a class="item" href=""  onclick="_msq.push">
							<img alt="米家扫地机器人买赠" src="<?php echo e(asset('homes/images/left1.jpg')); ?>" >
						
						</a>
					</li>
					<li>
						<a class="item" href=""  onclick="_msq.push">
							<img alt="米家扫地机器人买赠" src="<?php echo e(asset('homes/images/left2.jpg')); ?>" >
						
						</a>
					</li>
					<li>
						<a class="item" href=""  onclick="_msq.push">
							<img alt="米家扫地机器人买赠" src="<?php echo e(asset('homes/images/left3.jpg')); ?>" >
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>
<div class="page-main home-main">
	<div class="container">
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<h2 class="title"><?php echo e($v->goods_name); ?></h2>
			<div class="box-bd J_brickBd">
				<div class="row">
					<div class="span4 span-first">
						<ul class="brick-promo-list clearfix"> 
							<li class="brick-item brick-item-l"> 
								<a href="" onclick="_msq.push">
									<img src="<?php echo e(asset('homes/images/IH.jpg')); ?>" alt="图片走丢了^~^">
								</a> 
							</li>
						</ul>
					</div>
					<div class="span16">
						<ul class="brick-list clearfix">
						<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<?php if($v->goods_id==$m->goods_pid): ?>  
							<li class="brick-item brick-item-m brick-item-m-2"> 
								<div class="figure figure-img"> 
									<a href="<?php echo e(url('home/gde/'.$m->goods_id.'')); ?>" onclick="_msq.push ">
										<img src="<?php echo e(asset('/uploads/goods/'.$m->image.'')); ?>" width="160" height="160"> 
									</a> 
								</div> 
								<h3 class="title">
									<a href="<?php echo e(url('home/gde/'.$m->goods_id.'')); ?>" onclick="_msq.push "><?php echo e($m->goods_name); ?></a>
								</h3> 
								<p class="desc">限量送小米插线板 5孔位</p> 
								<p class="price"> 
									<span class="num">999</span>元  
								</p> 
								<div class="flag flag-gift">有赠品</div>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
							</li>
						</ul>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>