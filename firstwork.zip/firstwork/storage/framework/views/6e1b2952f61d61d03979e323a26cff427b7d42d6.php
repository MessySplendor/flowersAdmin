<?php $__env->startSection('content'); ?>


<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-indent red"></i>修改管理员账号-密码</h6>							
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<form action="/admin/userlist/<?php echo e($ob->admin_id); ?>" method="post" class="form-horizontal ">
		<input type='hidden' name='_token' value="<?php echo e(csrf_token()); ?>">
		<input type='hidden' name='_method' value="PUT">
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-small">账号</label>
			<div class="col-sm-6">
				<input type="text" id="input-small" name="admin_name" class="form-control input-sm" value="<?php echo e($ob->admin_name); ?>" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">密码</label>
			<div class="col-sm-6">
				<input type="password" id="input-normal" name="admin_pass" class="form-control"  />
			</div>
			</div>
			<div class="form-group">
				<div class="col-sm-6">
				</div>
				<div class="col-sm-2">
					<input type="reset"  />
				</div>
				<div class="col-sm-2">
					<input type="submit" value="确认修改" />
				</div>
			</div>
		</form>
	</div>					
</div>
			<?php if(session('msg')): ?>
				<?php echo e(session('msg')); ?>

			 <?php else: ?>
			 	
			<?php endif; ?>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>