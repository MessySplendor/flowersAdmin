<?php $__env->startSection('content'); ?>


<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-indent red"></i><a href="<?php echo e(url('admin/homelist')); ?>" >用户详细信息</a></h6>							
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-small">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;账号:</label>
			<div class="col-sm-7">
				<input type="text" id="input-small"  class="form-control input-sm" disabled value="<?php echo e($lt ->name); ?>" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-small">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;昵称:</label>
			<div class="col-sm-7">
				<input type="text" id="input-small" class="form-control input-sm"  disabled value="<?php echo e($geren ->det_nicheng); ?>" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;性别:</label>
			<div class="col-sm-7">
				<input type="text" id="input-normal" disabled value="<?php echo e(($geren ->det_sex = 'man')?'男':'女'); ?>"  class="form-control"  />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;电话号:</label>
			<div class="col-sm-7">
				<input type="text" id="input-normal"  class="form-control"  disabled value="<?php echo e($geren ->det_phone); ?>" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;邮箱:</label>
			<div class="col-sm-7">
				<input type="text" id="input-normal" disabled value="<?php echo e($geren ->det_email); ?>" class="form-control" />
			</div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label" for="input-normal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;卡号:</label>
			<div class="col-sm-7">
				<input type="text" id="input-normal" disabled value="<?php echo e($geren ->det_card); ?>" class="form-control"  />
			</div>
		</div>
			
		
	</div>					
</div>
				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>