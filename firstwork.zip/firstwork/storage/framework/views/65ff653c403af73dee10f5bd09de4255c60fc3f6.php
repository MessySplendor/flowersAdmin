<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
<div class="panel panel-default bk-bg-white">
	<div class="panel-heading bk-bg-white">
		<h6><i class="fa fa-table"></i><span class="break"></span>友情链接</h6>
		<div class="panel-actions">
			<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
			<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
		</div>
	</div>
	<div class="panel-body">
		<div class="table-responsive">	
			<form action="/admin/link" method="post" name="myform">
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<input type="hidden" name="_method" value="DELETE">
			</form>
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
				<thead>
					<tr>
						<th>链接编号</th>
						<th>链接名称</th>
						<th>链接地址</th>
						<th>操作</th>
					</tr>
				</thead>   
				<tbody>	
				<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>							
					<tr>
						<td><?php echo e($v->id); ?></td>
						<td><?php echo e($v->name); ?></td>
						<td><?php echo e($v->url); ?></td>
						<td>
							<a class="btn btn-info" href="/admin/link/<?php echo e($v->id); ?>/edit">
								<i class="fa fa-edit ">修改</i>                                            
							</a>
							<a class="btn btn-danger" href="javascript:doDel(<?php echo e($v->id); ?>)">
								<i class="fa fa-trash-o ">删除</i> 
							
						</td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</tbody>
			</table>
			<?php echo e($list->links()); ?>

			<script type="text/javascript">
				function doDel(id)
				{
					if(confirm("你确定要删除吗？")){
					var form=document.myform;
					//alert($id);
					form.action='/admin/link/'+id;
					form.submit();
					}
				}
			</script>
		</div>
	</div>
</div>
</div>					
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>