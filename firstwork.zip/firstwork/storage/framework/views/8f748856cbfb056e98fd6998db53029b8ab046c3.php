<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta charset='utf-8'>
	</head>
	<body>
		<h3>文件上传</h3>
		<form action="/home/touphoto" method="POST" enctype="multipart/form-data">
			<input type='hidden' name='_token' value='<?php echo e(csrf_token()); ?>'>
			文件：<input type='file' name='mypic'>
			<input type='submit' value='上传'>
		</form>
		<?php if(session('msg')): ?>
			<div style="font-size: 16px;color: red;"><?php echo e(session('msg')); ?></div>
		<?php endif; ?>
	</body>
</html>