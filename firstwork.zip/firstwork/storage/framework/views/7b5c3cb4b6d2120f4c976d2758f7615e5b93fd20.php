<?php $__env->startSection('content'); ?>
<?php if(session('msg')): ?>
	<?php echo e(session('msg')); ?>

<?php endif; ?>
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading bk-bg-white">
					<h6><i class="fa fa-indent red"></i>修改网站配置信息</h6>						
					<div class="panel-actions">
						<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
						<a href="#" class="btn-close"><i class="fa fa-times"></i></a>
					</div>
				</div>					
				<div class="panel-body">
					<form class="form-horizontal"  action="<?php echo e(url('admin/config')); ?>" method="post" role="form" enctype='multipart/form-data'>
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">网站标题</label>
							<div class="col-lg-10 col-md-10">
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<input type="text" name="config_title" value="<?php echo e($list->config_title); ?>" class="form-control" />
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">网站关键字</label>
							<div class="col-lg-10 col-md-10">
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
										<input type="text" name="config_keys" value="<?php echo e($list->config_keys); ?>" class="form-control" />
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">网站logo</label>
							<div class="col-md-9">
								<input type="file" id="file-input" name="config_photo">
							</div>
						</div>
						<div class="form-group">
							<label  class="col-lg-2 col-md-2 col-sm-12 control-label" for="select">网站网关</label>
							<div class="col-md-6">
								<select id="select" name="config_state" class="form-control input-lg" size="1">
									<option value="1">开</option>
									<option value="2">关</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label">网站描述</label>
							<div class="col-lg-10 col-md-10">
								<textarea id="textarea-input" name="config_des"  rows="9" class="form-control" ><?php echo e($list->config_des); ?></textarea>
							</div>
						</div>
						<div class="form-group">
							<label class="col-lg-2 col-md-2 col-sm-12 control-label"></label>
							<div class="col-lg-10 col-md-10 ">
								<button type="submit" class="bk-margin-5 btn btn-info">修改</button>
								<button type="reset" class="bk-margin-5 btn btn-default">重置</button>
							</div>
						</div>
					</form>
				</div>							
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>