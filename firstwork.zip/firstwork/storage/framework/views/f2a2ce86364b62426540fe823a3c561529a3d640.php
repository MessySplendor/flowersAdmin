<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0, maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<title>小米帐号 - 个人信息</title>
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('homes/forme/reset.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('homes/forme/layout.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('homes/forme/modacctip.css')); ?>">
<style type="text/css">
</style></head>
<body class="zh_CN" style="overflow-y: scroll;">
  <div class="popup_mask" style="display: none;" id="loadingMask">
    <div class="bkc"></div>
    <div class="mod_wrap loadingmask">
      
    </div>
  </div>
  <div class="wrapper blockimportant">
  <div class="wrap">

<div class="layout bugfix_ie6 dis_none">
  <div class="n-logo-area clearfix">
    <a href="/" class="fl-l">
      <img src="<?php echo e(asset('homes/forme/n-logo.png')); ?>" >
    </a>
      <a id="logoutLink" class="fl-r logout" href="<?php echo e(url('/home/out')); ?>">
          退出
      </a>
  </div>
    <!--头像 名字-->
</div>

  <div class="layout">
      <div class="n-main-nav clearfix">
        <ul>
          <li class="current">
            <a title="个人信息">个人信息</a>
            <em class="n-nav-corner"></em>
          </li>
        </ul>
      </div>
      <div class="n-frame">
  <div class="uinfo c_b">
        <div class="">
        <div class="main_l">
          <div class="naInfoImgBox t_c">
            <div class="na-img-area marauto">
              <!--na-img-bg-area不能插入任何子元素-->
              <div class="na-img-bg-area"><img src="/uploads/hphoto/<?php echo e(empty(session('hphoto'))?$user_info->det_photo:session('hphoto')); ?>" alt=""></div>
              <em class="na-edit"></em>
            </div>
            <div class="naImgLink">
             <a class="color4a9" href="<?php echo e(url('/home/touphoto')); ?>" title="设置头像">设置头像</a>
        
            </div>
          </div>        
        </div>
      
        <div class="main_r">
          <div class="framedatabox">
            <div class="fdata">
              
              <h3>基础资料</h3>    
            </div>
            <form action='/home/myself/<?php echo e($user_info->det_id); ?>' method='post'>
                <input type='hidden' name='_token' value='<?php echo e(csrf_token()); ?>'>
                <input type='hidden' name='_method' value="PUT">
            <div class="fdata lblnickname">
           
              <p>
              <!-- <input type="hidden" name="det_uid" value="<?php echo e($user_info->det_uid); ?>"> -->
              <span>昵称：</span><span class="value">
                <input type="text" name='det_nicheng' value="<?php echo e($user_info->det_nicheng); ?>">
        
                </span></p>     
            </div>
            <div class="fdata lblbirthday">
              <p><span>邮箱：</span><span class="value">
       
          <input type="text" name="det_email" value="<?php echo e(($user_info->det_email == null)?"请填写邮箱": $user_info->det_email); ?>">
        
        </span></p>     
            </div>
            <div class="fdata lblgender">
              <p><span>性别：</span><span class="value">
                <select name="det_sex" id="">
                  <option value="man" <?php echo e(($user_info->det_sex =='man')?"selected":''); ?>>男</option>
                  <option value="woman" <?php echo e(($user_info->det_sex =='woman')?"selected":''); ?>>女</option>
                </select>
             </span></p>     
            </div>
      <div class="btn_editinfo"><a id="editInfoWap" class="btnadpt bg_normal" href="">编辑基础资料</a></div>
          </div>
        <div class="framedatabox">
        <div class="fdata">
          <h3>高级设置</h3>    
        </div>
        <div class="fdata click-row">
                        
          <p>
          <span>银行卡：</span>         
          <span class="arrow_r">
            <input type="text" name="det_card" value="<?php echo e(($user_info->det_card == null)?"请填写卡号": $user_info->det_card); ?>">
          </span>
          </p>     
        </div>            
        <div class="fdata click-row">
          
          <p>
            <span>电话号：  </span>
            <span class="box_center">
              <input type="text" name="det_phone" value="<?php echo e(($user_info->det_phone == null)?"请填写电话号": $user_info->det_phone); ?>">
            </span>
          </p> 
        
        </div>
        <div class="fdata click-row">
          
         
            <span class="box_center">
              <input type="submit"  value="确认">
            </span>
        </div>
          </form>
          <?php if(session('msg')): ?>
             <spann class="box_center"><?php echo e(session('msg')); ?></spann>
          <?php else: ?>
                                        
          <?php endif; ?>
        </div>
        </div>
        </div>
      

    <div class="logout_wap">
      <a class="btnadpt bg_white" href="https://account.xiaomi.com/pass/logout?userId=1197179546&amp;callback=https://account.xiaomi.com">退出</a>
    </div>
      </div>
   </div>
  </div>
  </div>
  </div>
  <div class="n-footer">
  <div class="nf-link-area clearfix">
  <ul class="lang-select-list">
    <li><a class="lang-select-li current" href="javascript:void(0)" data-lang="zh_CN">简体</a>|</li>
    <li><a class="lang-select-li" href="javascript:void(0)" data-lang="zh_TW">繁体</a>|</li>
    <li><a class="lang-select-li" href="javascript:void(0)" data-lang="en">English</a></li>
    
      |<li><a class="a_critical" href="http://static.account.xiaomi.com/html/faq/faqList.html" target="_blank"><em></em>常见问题</a></li>
    
  </ul>
  </div>
  <p class="nf-intro"><span>小米公司版权所有-京ICP备10046444-<a class="beianlink beian-record-link" target="_blank" href=""><span><img src="<?php echo e(asset('homes/forme/ghs.png')); ?>"></span>京公网安备11010802020134号</a>-京ICP证110507号</span></p>
</div>



<style type="text/css">

</style>
<div id="img_cache" style="visibility:hidden;"></div>


</body></html>
